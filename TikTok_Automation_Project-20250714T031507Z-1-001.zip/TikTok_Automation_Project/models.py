# Data models for TikTok Automation Project

from dataclasses import dataclass, field
from typing import Optional, List

@dataclass
class TikTokUser:
    """Represents a TikTok user."""
    id: str
    unique_id: str
    nickname: str
    signature: Optional[str] = None
    follower_count: Optional[int] = None
    following_count: Optional[int] = None
    heart_count: Optional[int] = None
    video_count: Optional[int] = None
    # Add more fields as needed based on API response

@dataclass
class TikTokVideo:
    """Represents a TikTok video."""
    id: str
    desc: str
    create_time: int
    author: TikTokUser
    play_count: Optional[int] = None
    comment_count: Optional[int] = None
    share_count: Optional[int] = None
    collect_count: Optional[int] = None
    music_id: Optional[str] = None
    # Add more fields as needed based on API response

print("models.py created.")
