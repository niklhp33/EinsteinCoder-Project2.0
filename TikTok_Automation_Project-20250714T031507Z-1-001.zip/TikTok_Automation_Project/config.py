# Configuration for TikTok Automation Project

import os
import logging

# --- Project Directories (relative to the script's execution, but we'll use absolute paths in main_pipeline) ---
# These paths will be constructed using the DRIVE_PROJECT_ROOT in the main pipeline
# For config.py itself, we define them as relative paths for modularity,
# but the main script will resolve them to the correct Google Drive location.
OUTPUT_DIR_NAME = "output"
TEMP_FILES_DIR_NAME = "temp_files"
VIDEO_DOWNLOADS_DIR_NAME = "video_downloads"
IMAGES_DIR_NAME = "images"
MEDIA_PROCESSING_DIR_NAME = "media_processing"
LOGS_DIR_NAME = "logs"

# --- Logging Configuration ---
# LOG_FILE will be constructed dynamically in utils.py based on the project root
LOG_LEVEL = logging.INFO # DEBUG, INFO, WARNING, ERROR, CRITICAL

# --- API and Browser Automation Configuration ---
# IMPORTANT: Replace "YOUR_TIKTOK_MS_TOKEN_HERE" with your actual TikTok ms_token.
# You can get this from your browser cookies when logged into tiktok.com.
# It's crucial for some unofficial APIs like TikTokApi for better stability. [1]
# Example: TIKTOK_MS_TOKEN = "your_actual_ms_token_value"
TIKTOK_MS_TOKEN = os.getenv("TIKTOK_MS_TOKEN", "YOUR_TIKTOK_MS_TOKEN_HERE")

# Browser to use for Playwright (chromium, firefox, webkit) [1]
TIKTOK_BROWSER = os.getenv("TIKTOK_BROWSER", "chromium")

# --- Proxy Configuration (Optional but Recommended for Stability) ---
# List of proxies. Format: "http://user:pass@ip:port" or "http://ip:port" [4]
# For residential proxies, consider paid services for reliability. Free proxies are often unreliable. [2]
PROXY_LIST = [
    # "http://user:pass@your.proxy.com:8080",
    # "http://another.proxy.com:8081",
]

# --- User Agent Configuration ---
# A diverse list of realistic user agents helps mimic human behavior. [5]
USER_AGENTS =

print("config.py created.")
