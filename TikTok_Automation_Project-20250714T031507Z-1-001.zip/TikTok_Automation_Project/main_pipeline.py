# Main orchestration pipeline for TikTok Automation Project

import asyncio
import logging
import json
import os
import sys
from datetime import datetime

# Add the project root to the Python path so modules can be imported
# This is crucial for Colab to find your custom modules
# The DRIVE_PROJECT_ROOT variable is passed from the Colab environment
# via the execution context.
try:
    DRIVE_PROJECT_ROOT = os.environ
    if DRIVE_PROJECT_ROOT not in sys.path:
        sys.path.insert(0, DRIVE_PROJECT_ROOT)
except KeyError:
    print("Error: DRIVE_PROJECT_ROOT environment variable not set. Please run Cell 1 and 2 first.")
    sys.exit(1)

# Import configuration, utilities, API client, and data models
from config import OUTPUT_DIR_NAME, LOGS_DIR_NAME
from utils import setup_logging
from api_client import TikTokAPIClient
from models import TikTokVideo, TikTokUser
from dataclasses import asdict # For converting dataclasses to dicts for JSON

logger = logging.getLogger(__name__)

async def run_main_pipeline():
    """
    Main function to run the TikTok automation pipeline.
    This function will:
    1. Set up logging.
    2. Initialize the TikTok API client.
    3. Fetch trending videos.
    4. Process the fetched data into structured models.
    5. Save the processed data to a JSON file in the 'output' directory within Google Drive.
    """
    # Setup logging with the correct project root
    setup_logging(DRIVE_PROJECT_ROOT)
    logger.info("Starting TikTok Automation Main Pipeline.")

    # Define absolute paths for output and logs
    output_dir_abs = os.path.join(DRIVE_PROJECT_ROOT, OUTPUT_DIR_NAME)
    logs_dir_abs = os.path.join(DRIVE_PROJECT_ROOT, LOGS_DIR_NAME)

    # Ensure directories exist (redundant if Cell 2 ran, but good for standalone execution)
    os.makedirs(output_dir_abs, exist_ok=True)
    os.makedirs(logs_dir_abs, exist_ok=True)

    try:
        # Use the TikTokAPIClient as an asynchronous context manager
        async with TikTokAPIClient() as client:
            # Fetch trending videos (e.g., 20 videos)
            trending_videos_data = await client.get_trending_videos(count=20)

            if trending_videos_data:
                processed_videos =
                for video_data in trending_videos_data:
                    try:
                        # Basic parsing and mapping to TikTokVideo and TikTokUser models
                        author_data = video_data.get('author', {})
                        author = TikTokUser(
                            id=author_data.get('id', 'N/A'),
                            unique_id=author_data.get('uniqueId', 'N/A'),
                            nickname=author_data.get('nickname', 'N/A'),
                            signature=author_data.get('signature'),
                            follower_count=author_data.get('followerCount'),
                            following_count=author_data.get('followingCount'),
                            heart_count=author_data.get('heartCount'),
                            video_count=author_data.get('videoCount')
                        )
                        video = TikTokVideo(
                            id=video_data.get('id', 'N/A'),
                            desc=video_data.get('desc', 'No description'),
                            create_time=video_data.get('createTime'),
                            author=author,
                            play_count=video_data.get('stats', {}).get('playCount'),
                            comment_count=video_data.get('stats', {}).get('commentCount'),
                            share_count=video_data.get('stats', {}).get('shareCount'),
                            collect_count=video_data.get('stats', {}).get('collectCount'),
                            music_id=video_data.get('music', {}).get('id')
                        )
                        processed_videos.append(video)
                        logger.info(f"Processed video: '{video.desc[:50]}...' by {video.author.unique_id}")
                    except Exception as e:
                        logger.error(f"Error processing video data (ID: {video_data.get('id', 'N/A')}): {e}", exc_info=True)
                        continue

                # Save processed data to a JSON file in the 'output' directory
                output_filename = os.path.join(output_dir_abs, f"trending_videos_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
                with open(output_filename, 'w', encoding='utf-8') as f:
                    # Convert dataclass objects to dictionaries for JSON serialization
                    json.dump([asdict(v) for v in processed_videos], f, ensure_ascii=False, indent=4)
                logger.info(f"Saved {len(processed_videos)} processed videos to {output_filename}")

            else:
                logger.info("No trending videos fetched or an error occurred during fetching.")

    except Exception as e:
        logger.critical(f"Critical error in main pipeline execution: {e}", exc_info=True)

    logger.info("TikTok Automation Main Pipeline finished.")

if __name__ == "__main__":
    # Set the DRIVE_PROJECT_ROOT as an environment variable for the subprocess
    # This is how the main_pipeline.py script will know its root in Colab
    os.environ = DRIVE_PROJECT_ROOT
    asyncio.run(run_main_pipeline())

print("main_pipeline.py created.")
