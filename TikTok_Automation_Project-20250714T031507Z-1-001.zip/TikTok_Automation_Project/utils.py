# Utility functions for TikTok Automation Project

import logging
import random
import time
import os
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type
from requests.exceptions import RequestException

# Import configuration from config.py
from config import LOGS_DIR_NAME, LOG_LEVEL, USER_AGENTS, PROXY_LIST

def setup_logging(project_root: str):
    """Configures the logging for the application."""
    log_file_path = os.path.join(project_root, LOGS_DIR_NAME, "automation.log")
    logging.basicConfig(
        level=LOG_LEVEL,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file_path), # Log to file [6]
            logging.StreamHandler() # Log to console [6]
    )
    # Suppress verbose logging from external libraries
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('httpcore').setLevel(logging.WARNING)
    logging.getLogger('TikTokApi').setLevel(logging.INFO) # Adjust as needed for TikTokApi verbosity
    logging.info(f"Logging configured. Log file: {log_file_path}") [6]

@retry(
    wait=wait_exponential(multiplier=1, min=4, max=10), # Exponential backoff with jitter [7, 8]
    stop=stop_after_attempt(5), # Stop after 5 attempts [7]
    retry=retry_if_exception_type(RequestException) # Retry on network-related exceptions [8]
)
def retry_on_exception(func):
    """
    Decorator to apply retry logic to functions that might encounter transient errors.
    Uses exponential backoff with jitter. [7, 8]
    """
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

def get_random_user_agent():
    """Returns a random user agent string from the configured list."""
    return random.choice(USER_AGENTS) [5]

def get_random_proxy():
    """Returns a random proxy from the configured list, or None if list is empty."""
    if PROXY_LIST:
        return random.choice(PROXY_LIST) [4]
    return None

# Placeholder for Circuit Breaker (PyBreaker) - more complex to integrate directly in a simple example
# from pybreaker import CircuitBreaker [9]
# db_breaker = CircuitBreaker(fail_max=5, reset_timeout=60) [9]

print("utils.py created.")
