# API client for TikTok interactions

import asyncio
import logging
import os
from TikTokApi import TikTokApi # Unofficial API wrapper [1]
from TikTokApi.exceptions import EmptyResponseException # Specific exception for TikTokApi [1]

# Import configuration and utilities
from config import TIKTOK_MS_TOKEN, TIKTOK_BROWSER, PROXY_LIST
from utils import retry_on_exception, get_random_user_agent, get_random_proxy

logger = logging.getLogger(__name__)

class TikTokAPIClient:
    """
    Client for interacting with TikTok, primarily using the unofficial TikTokApi library.
    This client handles session management, proxies, and retries.
    """
    def __init__(self):
        self.ms_token = TIKTOK_MS_TOKEN
        self.browser_type = TIKTOK_BROWSER
        self.proxy = get_random_proxy() # Get a random proxy if available [4]
        self.api = None # Will be initialized asynchronously

        if self.ms_token == "YOUR_TIKTOK_MS_TOKEN_HERE":
            logger.warning("TIKTOK_MS_TOKEN is not set. Some API functionalities may be limited or blocked. "
                           "Please obtain your ms_token from TikTok.com cookies for better stability. [1]")
        if self.proxy:
            logger.info(f"Using proxy: {self.proxy}")
        else:
            logger.info("No proxy configured. Proceeding without proxy.")

    async def __aenter__(self):
        """Asynchronous context manager entry point for TikTokApi."""
        logger.info("Initializing TikTokApi session...")
        try:
            self.api = TikTokApi()
            # create_sessions requires ms_token and browser for robust interaction [1]
            await self.api.create_sessions(
                ms_tokens=[self.ms_token] if self.ms_token!= "YOUR_TIKTOK_MS_TOKEN_HERE" else None,
                num_sessions=1,
                sleep_after=3, # Recommended sleep after session creation [1]
                browser=self.browser_type,
                proxy=self.proxy # Pass proxy to Playwright [1]
            )
            logger.info("TikTokApi session created successfully.")
        except Exception as e:
            logger.error(f"Failed to create TikTokApi session: {e}")
            raise
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Asynchronous context manager exit point."""
        if self.api:
            logger.info("Closing TikTokApi session...")
            await self.api.close_sessions()
            logger.info("TikTokApi session closed.")

    @retry_on_exception
    async def get_trending_videos(self, count: int = 10):
        """
        Fetches trending videos from TikTok.
        Uses retry logic from utils.py.
        """
        if not self.api:
            logger.error("TikTokAPIClient not initialized. Call within an async with block.")
            return

        logger.info(f"Attempting to fetch {count} trending videos...")
        videos_data =
        try:
            # The TikTokApi library uses async iterators for trending videos [1]
            async for video in self.api.trending.videos(count=count):
                videos_data.append(video.as_dict) # Get raw dictionary [1]
                logger.debug(f"Fetched video: {video.desc[:50]}...")
            logger.info(f"Successfully fetched {len(videos_data)} trending videos.")
            return videos_data
        except EmptyResponseException as e:
            logger.warning(f"TikTok blocked the request (EmptyResponseException). This often means anti-bot detection. Consider checking ms_token or proxies: {e} [1]")
            return
        except Exception as e:
            logger.exception(f"An unexpected error occurred while fetching trending videos: {e}")
            return

    # You can add more methods here for other TikTok interactions, e.g.:
    # @retry_on_exception
    # async def get_user_info(self, username: str):
    #     """Fetches information for a specific TikTok user."""
    #     if not self.api:
    #         logger.error("TikTokAPIClient not initialized.")
    #         return None
    #     logger.info(f"Fetching info for user: {username}")
    #     try:
    #         user = await self.api.user(username=username)
    #         return user.as_dict
    #     except Exception as e:
    #         logger.error(f"Error fetching user info for {username}: {e}")
    #         return None

print("api_client.py created.")
