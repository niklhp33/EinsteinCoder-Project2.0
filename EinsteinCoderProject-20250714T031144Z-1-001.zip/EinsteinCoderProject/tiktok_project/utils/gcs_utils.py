import os
import logging
from google.cloud import storage
from google.api_core.exceptions import GoogleAPIError

# Initialize logging
logger = logging.getLogger(__name__)

def check_gcs_access(bucket_name: str, service_account_key_path: str) -> bool:
    """
    Checks if the Google Cloud Storage bucket is accessible with the provided credentials.

    Args:
        bucket_name (str): The name of the GCS bucket.
        service_account_key_path (str): Path to the GCP service account key JSON file.

    Returns:
        bool: True if the bucket is accessible, False otherwise.
    """
    logger.info(f"Checking GCS access for bucket: {bucket_name} using key: {service_account_key_path}")
    if not os.path.exists(service_account_key_path):
        logger.error(f"Service account key file not found at: {service_account_key_path}")
        return False
    try:
        # Authenticate using the service account key
        client = storage.Client.from_service_account_json(service_account_key_path)
        bucket = client.get_bucket(bucket_name)
        # Attempt to list a few blobs to confirm read access (no need to actually list all)
        list(bucket.list_blobs(max_results=1))
        logger.info(f"Successfully connected to GCS bucket: {bucket_name}")
        return True
    except GoogleAPIError as e:
        logger.error(f"Google Cloud API error during GCS access check for bucket '{bucket_name}': {e}")
        logger.error("Please ensure the bucket name is correct, billing is enabled, and the service account has 'Storage Admin' or 'Storage Object Admin' roles.")
        return False
    except Exception as e:
        logger.error(f"An unexpected error occurred during GCS access check for bucket '{bucket_name}': {e}")
        return False

def upload_to_gcs(bucket_name: str, source_file_name: str, destination_blob_name: str, service_account_key_path: str) -> bool:
    """
    Uploads a file to a Google Cloud Storage bucket.

    Args:
        bucket_name (str): The name of the GCS bucket.
        source_file_name (str): The path to the file to upload.
        destination_blob_name (str): The path/name for the file in the GCS bucket.
        service_account_key_path (str): Path to the GCP service account key JSON file.

    Returns:
        bool: True if the file was uploaded successfully, False otherwise.
    """
    logger.info(f"Attempting to upload '{source_file_name}' to GCS bucket '{bucket_name}' as '{destination_blob_name}'")

    if not os.path.exists(source_file_name):
        logger.error(f"Source file for GCS upload not found: {source_file_name}")
        return False
    if not os.path.exists(service_account_key_path):
        logger.error(f"Service account key file not found at: {service_account_key_path}")
        return False

    try:
        client = storage.Client.from_service_account_json(service_account_key_path)
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(destination_blob_name)

        blob.upload_from_filename(source_file_name)

        logger.info(f"File {source_file_name} uploaded to {destination_blob_name} in bucket {bucket_name}.")
        return True
    except GoogleAPIError as e:
        logger.error(f"Google Cloud API error during upload of '{source_file_name}' to GCS: {e}")
        logger.error("Please check your GCS bucket name, service account permissions, and network connectivity.")
        return False
    except Exception as e:
        logger.error(f"An unexpected error occurred during GCS upload of '{source_file_name}': {e}")
        return False

def download_from_gcs(bucket_name: str, source_blob_name: str, destination_file_name: str, service_account_key_path: str) -> bool:
    """
    Downloads a blob from a Google Cloud Storage bucket to a local file.

    Args:
        bucket_name (str): The name of the GCS bucket.
        source_blob_name (str): The path/name of the blob in the GCS bucket.
        destination_file_name (str): The local path to save the downloaded file.
        service_account_key_path (str): Path to the GCP service account key JSON file.

    Returns:
        bool: True if the file was downloaded successfully, False otherwise.
    """
    logger.info(f"Attempting to download '{source_blob_name}' from GCS bucket '{bucket_name}' to '{destination_file_name}'")

    if not os.path.exists(service_account_key_path):
        logger.error(f"Service account key file not found at: {service_account_key_path}")
        return False

    try:
        client = storage.Client.from_service_account_json(service_account_key_path)
        bucket = client.bucket(bucket_name)
        blob = bucket.blob(source_blob_name)

        # Ensure the destination directory exists
        os.makedirs(os.path.dirname(destination_file_name), exist_ok=True)
        
        blob.download_to_filename(destination_file_name)

        logger.info(f"Blob {source_blob_name} downloaded to {destination_file_name}.")
        return True
    except GoogleAPIError as e:
        logger.error(f"Google Cloud API error during download of '{source_blob_name}' from GCS: {e}")
        logger.error("Please check your GCS bucket name, service account permissions, and network connectivity.")
        return False
    except Exception as e:
        logger.error(f"An unexpected error occurred during GCS download of '{source_blob_name}': {e}")
        return False
