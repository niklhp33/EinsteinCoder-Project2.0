import logging
import os
import shlex
import re
from typing import List, Tuple, Dict, Any
import shutil # Import shutil for copyfile

from .shell_utils import run_shell_command
from ..models import SubtitleEntry, VideoAspect, VideoTransitionMode, SubtitlePosition

logger = logging.getLogger(__name__)

def escape_ffmpeg_text(text: str) -> str:
    """
    Escapes special characters in a string for FFmpeg's drawtext filter.
    Special characters that need escaping: \ ' : , [ ] ;
    """
    # Order matters: escape backslash first!
    text = text.replace('\\', '\\\\')
    
    # Escape single quotes within the text. FFmpeg drawtext expects text in single quotes
    # and internal single quotes need to be replaced with '\''
    text = text.replace("'", "'\\''") # This is the standard FFmpeg way to escape a single quote inside a single-quoted string
    
    # Escape other FFmpeg special characters for filter graph compatibility
    text = text.replace(':', '\\:')
    text = text.replace(',', '\\,')
    text = text.replace('[', '\\[')
    text = text.replace(']', '\\]')
    text = text.replace(';', '\\;') # Semicolons can break filter chains

    return text

def run_ffmpeg_command(command_args: List[str], check_error: bool = True, timeout: int = 600) -> Tuple[str, str, int]:
    """
    Wrapper for running FFmpeg commands.
    Args:
        command_args: A list of strings representing FFmpeg command arguments.
        check_error: If True, logs an error if FFmpeg returns a non-zero exit code.
        timeout: Timeout for the FFmpeg command in seconds.
    Returns:
        A tuple of (stdout, stderr, returncode).
    """
    # IMPORTANT: The shlex.quote is done INSIDE run_shell_command,
    # so command_args here should be raw arguments.
    # The filter_complex string itself should be passed as one string element.
    full_command = ['ffmpeg', '-y'] + command_args 
    return run_shell_command(full_command, check_error=check_error, timeout=timeout)

def get_video_dimensions(video_path: str) -> Tuple[int, int]:
    """
    Gets the width and height of a video using ffprobe.
    Returns:
        A tuple (width, height). Raises ValueError if dimensions cannot be found.
    """
    cmd = [
        'ffprobe', '-v', 'error', '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height', '-of', 'csv=p=0:s=x',
        shlex.quote(video_path) # Quote input path
    ]
    stdout, stderr, returncode = run_shell_command(cmd, check_error=True)
    if returncode != 0:
        logger.error(f"Failed to get video dimensions for {video_path}: {stderr}")
        raise ValueError(f"Could not get video dimensions for {video_path}")
    
    try:
        dimensions = stdout.strip().split('x')
        width = int(dimensions[0])
        height = int(dimensions[1])
        logger.info(f"Video dimensions for {video_path}: {width}x{height}")
        return width, height
    except (IndexError, ValueError) as e:
        logger.error(f"Error parsing video dimensions from ffprobe output: {stdout}. Error: {e}")
        raise ValueError(f"Could not parse video dimensions for {video_path} from output: {stdout}")

def concatenate_videos(
    input_video_paths: List[str],
    output_path: str,
    target_aspect_ratio: VideoAspect,
    transition_mode: VideoTransitionMode = VideoTransitionMode.FADE,
    transition_duration: float = 0.5,
    max_duration_s: Optional[int] = None
) -> bool:
    """
    Concatenates a list of video clips into a single video, applying a consistent aspect ratio
    and optionally transitions.
    Args:
        input_video_paths: List of paths to input video files.
        output_path: Path for the output concatenated video file.
        target_aspect_ratio: The desired final aspect ratio (e.g., Portrait 9:16).
        transition_mode: Type of transition to use between clips.
        transition_duration: Duration of the transition in seconds.
        max_duration_s: If provided, the output video will be trimmed to this maximum duration.
    Returns:
        True if concatenation is successful, False otherwise.
    """
    if not input_video_paths:
        logger.error("No input video paths provided for concatenation.")
        return False
    if len(input_video_paths) == 1:
        logger.info(f"Only one video provided, copying to output: {input_video_paths[0]} to {output_path}")
        try:
            shutil.copyfile(input_video_paths[0], output_path)
            # Ensure FFmpeg reports correct duration for single file copy
            if max_duration_s is not None:
                # If a single clip is being copied and needs trimming, do it explicitly.
                # The simple copy won't trim. This is an edge case.
                duration_of_single_clip = get_video_duration(input_video_paths[0])
                if duration_of_single_clip and duration_of_single_clip > max_duration_s:
                    temp_trimmed_path = output_path + ".trimmed.mp4"
                    trim_cmd = [
                        '-i', shlex.quote(input_video_paths[0]),
                        '-ss', '0',
                        '-t', str(max_duration_s),
                        '-c', 'copy',
                        shlex.quote(temp_trimmed_path)
                    ]
                    stdout, stderr, returncode = run_ffmpeg_command(trim_cmd, check_error=True)
                    if returncode == 0:
                        shutil.move(temp_trimmed_path, output_path)
                        logger.info(f"Single clip trimmed to {max_duration_s}s and saved to {output_path}")
                    else:
                        logger.error(f"Failed to trim single clip: {stderr}")
            return True
        except Exception as e:
            logger.error(f"Error copying single video file: {e}")
            return False

    logger.info(f"Concatenating {len(input_video_paths)} videos with {transition_mode.value} transitions to {output_path}")

    # Determine target dimensions based on aspect ratio
    target_width, target_height = 0, 0
    if target_aspect_ratio == VideoAspect.PORTRAIT_9_16:
        target_width, target_height = 1080, 1920
    elif target_aspect_ratio == VideoAspect.LANDSCAPE_16_9:
        target_width, target_height = 1920, 1080
    elif target_aspect_ratio == VideoAspect.SQUARE_1_1:
        target_width, target_height = 1080, 1080
    else:
        logger.error(f"Unsupported aspect ratio: {target_aspect_ratio}")
        return False

    # Get durations and dimensions first
    video_info = []
    for i, path in enumerate(input_video_paths):
        try:
            width, height = get_video_dimensions(path)
            cmd_duration = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', shlex.quote(path)]
            stdout_dur, _, rc_dur = run_shell_command(cmd_duration, check_error=True)
            if rc_dur != 0:
                raise ValueError(f"Could not get duration for {path}")
            duration = float(stdout_dur.strip())
            video_info.append({'path': path, 'width': width, 'height': height, 'duration': duration})
        except Exception as e:
            logger.warning(f"Skipping video {path} due to error getting info: {e}")
            continue

    if not video_info:
        logger.error("No valid video information found for concatenation.")
        return False

    ffmpeg_inputs = []
    filter_complex_graph = []

    # First, scale/pad and format each video/audio stream
    for i, info in enumerate(video_info):
        ffmpeg_inputs.extend(['-i', shlex.quote(info['path'])])

        vf = f"scale='min({target_width},iw*min({target_width}/iw,{target_height}/ih)):min({target_height},ih*min({target_width}/iw,{target_height}/ih))'," \
             f"pad={target_width}:{target_height}:(ow-iw)/2:(oh-ih)/2:black"
        
        filter_complex_graph.append(f"[{i}:v] {vf},setsar=1,fps=25 [v{i}];") # Standardize frame rate to 25fps
        filter_complex_graph.append(f"[{i}:a] aformat=channel_layouts=stereo:sample_rates=48000,aresample=async=1000 [a{i}];")

    num_videos = len(video_info)
    if num_videos > 1:
        # Chain for video transitions
        current_video_stream = f"[v0]"
        current_audio_stream = f"[a0]"
        cumulative_duration_v = video_info[0]['duration']
        
        for i in range(num_videos - 1):
            next_video_input = f"[v{i+1}]"
            next_audio_input = f"[a{i+1}]"

            # Ensure actual transition duration is less than the current clip's duration
            actual_transition_duration = min(transition_duration, video_info[i]['duration'] - 0.1)
            if actual_transition_duration < 0.1: actual_transition_duration = 0.1
            
            # Video xfade
            filter_complex_graph.append(
                f"{current_video_stream}{next_video_input}xfade=transition={transition_mode.value.lower()}:"
                f"duration={actual_transition_duration}:"
                f"offset={cumulative_duration_v - actual_transition_duration}[v_chained{i}];"
            )
            # Audio transition (acrossfade)
            filter_complex_graph.append(
                f"{current_audio_stream}{next_audio_input}acrossfade=d={actual_transition_duration}[a_chained{i}];"
            )
            current_video_stream = f"[v_chained{i}]"
            current_audio_stream = f"[a_chained{i}]"
            
            cumulative_duration_v += video_info[i+1]['duration'] - actual_transition_duration

        final_video_output_stream = current_video_stream
        final_audio_output_stream = current_audio_stream
    else: # Only one video
        final_video_output_stream = f"[v0]"
        final_audio_output_stream = f"[a0]"
        cumulative_duration_v = video_info[0]['duration']

    # Add trim filter if max_duration_s is specified
    if max_duration_s is not None and cumulative_duration_v > max_duration_s:
        filter_complex_graph.append(f"{final_video_output_stream}trim=duration={max_duration_s},setpts=PTS-STARTPTS[final_trimmed_v];")
        filter_complex_graph.append(f"{final_audio_output_stream}atrim=duration={max_duration_s},asetpts=PTS-STARTPTS[final_trimmed_a];")
        final_video_output_stream = "[final_trimmed_v]"
        final_audio_output_stream = "[final_trimmed_a]"

    full_filter_complex_str = "".join(filter_complex_graph)

    # Arguments that compose the command, but will be quoted by run_ffmpeg_command
    cmd_args = [
        '-filter_complex', full_filter_complex_str, # This is a single string that FFmpeg parses internally
        '-map', final_video_output_stream,
        '-map', final_audio_output_stream,
        '-c:v', 'libx264', '-preset', 'medium', '-crf', '23',
        '-pix_fmt', 'yuv420p',
        '-movflags', '+faststart',
        '-c:a', 'aac', '-b:a', '192k',
        shlex.quote(output_path) # Only the output path needs quoting here directly
    ]
    
    # Prepend input paths (which are already shlex.quoted)
    full_cmd_args_for_run = ffmpeg_inputs + cmd_args
    
    logger.info(f"FFmpeg Concatenation Command Args (for logging): {' '.join(full_cmd_args_for_run)}")
    stdout, stderr, returncode = run_ffmpeg_command(full_cmd_args_for_run, check_error=True, timeout=timeout)
    if returncode != 0:
        logger.error(f"Failed to concatenate videos with transitions: {stderr}")
        return False
    return True

def add_audio_to_video(video_path: str, audio_path: str, output_path: str, start_offset_s: int = 0, audio_volume_db: int = 0) -> bool:
    """
    Adds (or replaces) audio in a video file.
    Args:
        video_path: Path to the input video file.
        audio_path: Path to the input audio file.
        output_path: Path for the output video file with new audio.
        start_offset_s: Start the audio from this second in the video.
        audio_volume_db: Volume adjustment for the audio in decibels (e.g., -10 for softer, 5 for louder).
    Returns:
        True if successful, False otherwise.
    """
    logger.info(f"Adding audio '{audio_path}' to video '{video_path}' to '{output_path}' with offset {start_offset_s}s and volume {audio_volume_db}dB.")
    
    # Check if audio file exists
    if not os.path.exists(audio_path):
        logger.error(f"Audio file not found: {audio_path}")
        return False

    # Get video duration to correctly trim audio if necessary
    try:
        cmd_duration = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', shlex.quote(video_path)]
        stdout_vid_dur, _, rc_vid_dur = run_shell_command(cmd_duration, check_error=True)
        if rc_vid_dur != 0:
            raise ValueError(f"Could not get video duration for {video_path}")
        video_duration = float(stdout_vid_dur.strip())
        logger.debug(f"Video duration: {video_duration}s")
    except Exception as e:
        logger.error(f"Failed to get video duration: {e}")
        return False

    # Filter for audio volume and trimming
    audio_filter = f"volume={audio_volume_db}dB"
    if start_offset_s > 0:
        audio_filter = f"adelay={start_offset_s * 1000}|{start_offset_s * 1000},{audio_filter}"
    
    audio_filter += f",atrim=end={video_duration + 1},asetpts=PTS-STARTPTS" # Add a small buffer, reset timestamps

    cmd_args = [
        '-i', shlex.quote(video_path),
        '-i', shlex.quote(audio_path),
        '-filter_complex', f"[1:a]{audio_filter}[aout]",
        '-map', '0:v',
        '-map', '[aout]',
        '-c:v', 'copy',
        '-c:a', 'aac', '-b:a', '192k',
        '-shortest',
        shlex.quote(output_path)
    ]
    
    logger.info(f"FFmpeg Add Audio Command: {' '.join(shlex.quote(arg) for arg in cmd_args)}")
    stdout, stderr, returncode = run_ffmpeg_command(cmd_args, check_error=True)
    
    if returncode != 0:
        logger.error(f"Failed to add audio to video: {stderr}")
        return False
    logger.info(f"Audio successfully added to {output_path}.")
    return True

def add_subtitles_to_video(
    video_path: str,
    subtitle_entries: List[SubtitleEntry],
    output_path: str,
    font_path: str,
    font_size: int = 50,
    font_color: str = 'white',
    outline_color: str = 'black',
    outline_width: int = 2,
    position: SubtitlePosition = SubtitlePosition.BOTTOM_CENTER
) -> bool:
    """
    Adds burned-in subtitles to a video using FFmpeg's drawtext filter.
    Args:
        video_path: Path to the input video file.
        subtitle_entries: List of SubtitleEntry objects containing text and timestamps.
        output_path: Path for the output video file with subtitles.
        font_path: Full path to the .ttf or .otf font file to use.
        font_size: Size of the subtitle font.
        font_color: Color of the subtitle text (e.g., 'white', '#FFFFFF').
        outline_color: Color of the subtitle outline.
        outline_width: Width of the subtitle outline.
        position: Position of the subtitles on the screen.
    Returns:
        True if successful, False otherwise.
    """
    logger.info(f"Adding {len(subtitle_entries)} subtitles to {video_path} to {output_path}.")
    
    if not os.path.exists(font_path):
        logger.error(f"Font file not found: {font_path}. Cannot add subtitles.")
        return False

    # Determine x and y coordinates based on position
    x_pos = "(w-text_w)/2" # Default to center
    y_pos = "(h-text_h)/2" # Default to middle
    
    if position == SubtitlePosition.BOTTOM_CENTER:
        y_pos = "h-text_h-20" # 20 pixels from bottom
    elif position == SubtitlePosition.TOP_CENTER:
        y_pos = "20" # 20 pixels from top
    elif position == SubtitlePosition.MIDDLE_CENTER:
        y_pos = "(h-text_h)/2"
    elif position == SubtitlePosition.BOTTOM_LEFT:
        x_pos = "20"
        y_pos = "h-text_h-20"
    elif position == SubtitlePosition.BOTTOM_RIGHT:
        x_pos = "w-text_w-20"
        y_pos = "h-text_h-20"

    drawtext_chain = []
    input_stream = "0:v" # Start with the raw video input stream

    for i, entry in enumerate(subtitle_entries):
        # Apply robust escaping to the subtitle text
        escaped_text = escape_ffmpeg_text(entry.text)
        
        current_drawtext_filter = (
            f"drawtext=fontfile='{escape_ffmpeg_text(font_path)}':"
            f"text='{escaped_text}':" # The text must be correctly quoted and internal quotes escaped
            f"x={x_pos}:y={y_pos}:"
            f"fontsize={font_size}:fontcolor={font_color}:"
            f"bordercolor={outline_color}:borderw={outline_width}:"
            f"enable='between(t,{entry.start_time},{entry.end_time})'"
        )
        
        output_stream = f"v_sub{i+1}"
        drawtext_chain.append(f"[{input_stream}]{current_drawtext_filter}[{output_stream}]")
        input_stream = output_stream # Next filter uses this as input

    final_video_output_stream_name = input_stream # The last output stream from the chain

    cmd_args = [
        '-i', shlex.quote(video_path),
        '-filter_complex', ";".join(drawtext_chain), # This is a single string that FFmpeg parses internally
        '-map', final_video_output_stream_name,
        '-map', '0:a?', # Map audio stream from first input (if exists)
        '-c:v', 'libx264', '-preset', 'medium', '-crf', '23', # Re-encode video
        '-pix_fmt', 'yuv420p',
        '-movflags', '+faststart',
        '-c:a', 'copy', # Copy audio stream without re-encoding
        shlex.quote(output_path)
    ]
    
    logger.info(f"FFmpeg Add Subtitles Command: {' '.join(shlex.quote(arg) for arg in cmd_args)}")
    stdout, stderr, returncode = run_ffmpeg_command(cmd_args, check_error=True)

    if returncode != 0:
        logger.error(f"Failed to add subtitles to video: {stderr}")
        return False
    logger.info(f"Subtitles successfully added to {output_path}.")
    return True
