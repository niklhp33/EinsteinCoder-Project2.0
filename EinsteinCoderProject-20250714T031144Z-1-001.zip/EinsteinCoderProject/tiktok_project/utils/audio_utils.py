import os
import requests
import logging
import random
import shlex # Added shlex for quoting paths
from typing import Optional, Tuple

from moviepy.editor import AudioFileClip
from ..config import GLOBAL_CONFIG
from .shell_utils import run_shell_command
from .cleanup import AUDIO_DIR, TEMP_FILES_DIR

logger = logging.getLogger(__name__)

def download_background_music(query: str, output_dir: str, duration_s: int, retries: int = 3) -> Optional[str]:
    """
    Downloads royalty-free background music using Pixabay API.
    Args:
        query: Search query for music (e.g., "upbeat cinematic").
        output_dir: Directory to save the downloaded audio.
        duration_s: Target duration of the music in seconds.
        retries: Number of retries for the API request.
    Returns:
        Path to the downloaded audio file if successful, None otherwise.
    """
    api_key = GLOBAL_CONFIG['api_keys']['pixabay_api_key']
    if not api_key or api_key == 'YOUR_PIXABAY_API_KEY_PLACEHOLDER':
        logger.error("Pixabay API key is not configured. Cannot download background music.")
        return None

    # Use the /api/videos/ endpoint with video_type="music"
    url = "https://pixabay.com/api/videos/" 
    params = {
        "key": api_key,
        "q": query,
        "video_type": "music", # Specify music
        "min_duration": max(1, duration_s - 30), # Look for music at least 1s or target_s - 30s
        "max_duration": duration_s + 60, # Up to target_s + 60s
        "per_page": 40 # Fetch more to have options
    }

    for attempt in range(retries):
        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()

            hits = data.get('hits', [])
            suitable_music = [
                hit for hit in hits
                if 'videos' in hit and 'medium' in hit['videos'] # Ensure medium quality is available
            ]

            if not suitable_music:
                logger.warning(f"No suitable music found for query '{query}'. Attempt {attempt + 1}/{retries}.")
                if attempt < retries - 1:
                    import time
                    time.sleep(2 ** attempt) # Exponential backoff
                continue
            
            selected_music = random.choice(suitable_music)
            music_url = selected_music['videos']['medium']['url'] # Using medium quality

            file_name = f"background_music_{random.randint(10000, 99999)}.mp3"
            output_path = os.path.join(output_dir, file_name)

            logger.info(f"Downloading background music from: {music_url}")
            music_response = requests.get(music_url, stream=True, timeout=30)
            music_response.raise_for_status()

            with open(output_path, 'wb') as f:
                for chunk in music_response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            logger.info(f"Successfully downloaded background music to: {output_path}")
            return output_path

        except requests.exceptions.RequestException as e:
            logger.error(f"Error downloading background music (attempt {attempt + 1}/{retries}): {e}")
            if attempt < retries - 1:
                import time
                time.sleep(2 ** attempt) # Exponential backoff
        except Exception as e:
            logger.error(f"An unexpected error occurred during music download: {e}", exc_info=True)
            return None
    return None

def adjust_audio_volume(input_audio_path: str, output_audio_path: str, volume_db: int) -> bool:
    """
    Adjusts the volume of an audio file using FFmpeg.
    Args:
        input_audio_path: Path to the input audio file.
        output_audio_path: Path for the output audio file with adjusted volume.
        volume_db: Volume adjustment in decibels (e.g., -10 for softer, 5 for louder).
    Returns:
        True if successful, False otherwise.
    """
    logger.info(f"Adjusting volume of {input_audio_path} to {volume_db}dB.")
    cmd = [
        'ffmpeg', '-y',
        '-i', shlex.quote(input_audio_path),
        '-filter:a', f'volume={volume_db}dB',
        '-c:a', 'aac',
        '-b:a', '192k',
        shlex.quote(output_audio_path)
    ]
    stdout, stderr, returncode = run_shell_command(cmd, check_error=True)
    if returncode != 0:
        logger.error(f"Failed to adjust audio volume: {stderr}")
        return False
    logger.info(f"Volume adjusted for {input_audio_path} to {output_audio_path}.")
    return True

def combine_audio_tracks(narration_path: str, background_music_path: Optional[str], output_path: str, background_music_volume_db: int = -15) -> bool:
    """
    Combines narration audio with background music.
    Args:
        narration_path: Path to the narration audio file.
        background_music_path: Optional path to the background music file.
        output_path: Path for the combined audio file.
        background_music_volume_db: Volume adjustment for background music in dB.
    Returns:
        True if successful, False otherwise.
    """
    logger.info(f"Combining narration audio '{narration_path}' with background music (if provided) to '{output_path}'.")

    if not os.path.exists(narration_path):
        logger.error(f"Narration audio file not found: {narration_path}")
        return False

    if background_music_path and not os.path.exists(background_music_path):
        logger.warning(f"Background music file not found: {background_music_path}. Proceeding with narration only.")
        background_music_path = None

    if background_music_path:
        # Get duration of narration using ffprobe directly for robustness
        narration_duration = None
        try:
            narration_duration = get_audio_duration_ffprobe(narration_path)
        except Exception as e:
            logger.error(f"Could not get narration duration using ffprobe: {e}")

        if narration_duration is None:
            logger.error("Could not determine narration duration. Aborting audio combine.")
            return False

        filter_complex = (
            f"[0:a]aformat=channel_layouts=stereo:sample_rates=48000[narration_resampled];"
            f"[1:a]volume={background_music_volume_db}dB,"
            f"aresample=async=1000,aformat=channel_layouts=stereo:sample_rates=48000,"
            f"atrim=duration={narration_duration + 5},asetpts=PTS-STARTPTS[bg_music_trimmed];"
            f"[narration_resampled][bg_music_trimmed]amix=inputs=2:duration=longest:dropout_transition=0,normalize[aout]"
        )
        
        cmd = [
            'ffmpeg', '-y',
            '-i', shlex.quote(narration_path),
            '-i', shlex.quote(background_music_path),
            '-filter_complex', filter_complex,
            '-map', '[aout]',
            '-c:a', 'aac', '-b:a', '192k',
            shlex.quote(output_path)
        ]
        
        logger.info(f"FFmpeg Combine Audio Command: {' '.join(shlex.quote(arg) for arg in cmd)}")
        stdout, stderr, returncode = run_shell_command(cmd, check_error=True)

        if returncode != 0:
            logger.error(f"Failed to combine audio tracks: {stderr}")
            return False
        logger.info(f"Narration and background music combined to {output_path}.")
        return True
    else:
        logger.info("No background music path provided. Copying narration directly.")
        cmd = ['ffmpeg', '-y', '-i', shlex.quote(narration_path), '-c:a', 'copy', shlex.quote(output_path)]
        stdout, stderr, returncode = run_shell_command(cmd, check_error=True)
        if returncode != 0:
            logger.error(f"Failed to copy narration audio: {stderr}")
            return False
        logger.info(f"Narration audio copied to {output_path}.")
        return True

# Helper function to get audio duration via ffprobe, moved here for direct use
# (This might be a duplicate if it exists in speech_synthesis.py, but safe to include for direct use)
def get_audio_duration_ffprobe(audio_path: str) -> Optional[float]:
    """
    Gets the duration of an audio file in seconds using ffprobe.
    """
    if not os.path.exists(audio_path):
        logger.error(f"Audio file not found for duration check: {audio_path}")
        return None

    cmd = [
        'ffprobe', '-v', 'error', '-show_entries', 'format=duration',
        '-of', 'default=noprint_wrappers=1:nokey=1', shlex.quote(audio_path)
    ]
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False)
    
    if returncode != 0 or not stdout.strip():
        logger.error(f"Failed to get audio duration for {audio_path}: {stderr}")
        return None
    try:
        return float(stdout.strip())
    except ValueError:
        logger.error(f"Could not parse audio duration from ffprobe output: {stdout}")
        return None
