import os
import shutil
import logging
from config import GLOBAL_CONFIG # Import GLOBAL_CONFIG from your config.py

logger = logging.getLogger(__name__)

# Define paths relative to GLOBAL_CONFIG['paths']['base_dir']
# These paths refer to the runtime directories, not necessarily Drive directories
VIDEO_DOWNLOADS_DIR = GLOBAL_CONFIG['paths']['video_downloads_dir']
AUDIO_DIR = GLOBAL_CONFIG['paths']['audio_dir']
IMAGES_DIR = GLOBAL_CONFIG['paths']['images_dir']
OUTPUT_DIR = GLOBAL_CONFIG['paths']['output_dir'] # This is the final output folder
TEMP_FILES_DIR = GLOBAL_CONFIG['paths']['temp_files_dir']
LOGS_DIR = GLOBAL_CONFIG['paths']['logs_dir'] # For logs written by pipeline functions

def setup_directories():
    """
    Ensures all necessary runtime directories exist. This should be called at the start of a pipeline run.
    """
    base_dir = GLOBAL_CONFIG['paths']['base_dir']
    
    # List all directory keys from GLOBAL_CONFIG['paths']
    dir_keys = [k for k in GLOBAL_CONFIG['paths'].keys() if k.endswith('_dir')]
    
    logger.info(f"Setting up runtime directories under base: {base_dir}")
    os.makedirs(base_dir, exist_ok=True) # Ensure the base directory itself exists

    for key in dir_keys:
        # Construct the full path for the runtime directory
        full_path = os.path.join(base_dir, GLOBAL_CONFIG['paths'][key])
        os.makedirs(full_path, exist_ok=True)
        logger.debug(f"Ensured directory exists: {full_path}")

def clean_up_temp_files():
    """
    Cleans up temporary files and directories created during the pipeline execution.
    This should be called at the end of a pipeline run.
    """
    base_dir = GLOBAL_CONFIG['paths']['base_dir']
    
    logger.info(f"Initiating cleanup of temporary runtime files under: {base_dir}")

    # Define directories to clean (excluding the logs_dir AND OUTPUT_DIR if you want to retain final videos)
    dirs_to_clean = [
        os.path.join(base_dir, VIDEO_DOWNLOADS_DIR),
        os.path.join(base_dir, AUDIO_DIR),
        os.path.join(base_dir, IMAGES_DIR),
        os.path.join(base_dir, TEMP_FILES_DIR),
        # os.path.join(base_dir, OUTPUT_DIR) # DO NOT UNCOMMENT THIS if you want to keep final videos!
    ]

    for d in dirs_to_clean:
        if os.path.exists(d):
            try:
                shutil.rmtree(d)
                logger.info(f"Cleaned up directory: {d}")
            except Exception as e:
                logger.error(f"Error cleaning up directory {d}: {e}")
        else:
            logger.debug(f"Directory not found for cleanup (skipped): {d}")
    
    # Optionally, remove temporary files in the base_dir itself (e.g., intermediate FFmpeg lists)
    for item in os.listdir(base_dir):
        item_path = os.path.join(base_dir, item)
        if os.path.isfile(item_path) and ("temp" in item or "list" in item):
             try:
                 os.remove(item_path)
                 logger.debug(f"Removed temporary file: {item_path}")
             except Exception as e:
                 logger.warning(f"Could not remove temp file {item_path}: {e}")

    logger.info("Temporary file cleanup complete.")
