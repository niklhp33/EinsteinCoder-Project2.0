import subprocess
import shlex
import logging
import re
from typing import List, Tuple, Optional

# Initialize logging
logger = logging.getLogger(__name__)

def run_shell_command(command: List[str], check_error: bool = True, timeout: Optional[int] = 300) -> Tuple[str, str, int]:
    """
    Executes a shell command and captures its stdout and stderr.
    Args:
        command: A list of strings representing the command and its arguments.
        check_error: If True, logs an error if the command returns a non-zero exit code.
        timeout: Optional timeout in seconds for the command. Defaults to 300 seconds (5 minutes).
    Returns:
        A tuple of (stdout, stderr, returncode).
    Raises:
        subprocess.TimeoutExpired: If the command times out.
        Exception: For other unexpected errors during command execution.
    """
    command_str = shlex.join(command)
    logger.info(f"Executing command: {command_str}")
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=False, # We handle check manually to return stderr regardless
            encoding='utf-8',
            errors='replace', # Replace un-decodable characters
            timeout=timeout
        )
        stdout = result.stdout
        stderr = result.stderr
        returncode = result.returncode

        if check_error and returncode != 0:
            logger.error(f"Command failed with exit code {returncode}: {command_str}")
            logger.error(f"Stderr: {stderr}") # Log stderr here for clarity
            
        logger.info(f"Command executed successfully (exit code {returncode}): {command_str}")
        return stdout, stderr, returncode

    except subprocess.TimeoutExpired as e:
        logger.error(f"Command timed out after {e.timeout} seconds: {command_str}")
        logger.error(f"Stdout (partial): {e.stdout}")
        logger.error(f"Stderr (partial): {e.stderr}")
        raise # Re-raise the exception after logging details
    except Exception as e:
        logger.error(f"An unexpected error occurred while running command '{command_str}': {e}", exc_info=True)
        # Return empty strings and a non-zero code to indicate failure to the caller
        return "", str(e), -1


def sanitize_filename(filename: str, replace_char: str = "_") -> str:
    """
    Sanitizes a string to be safe for use as a filename.
    Removes invalid characters and replaces spaces.
    """
    # Remove any character that is not a letter, number, underscore, hyphen, or dot
    s = re.sub(r'[^\w.-]', replace_char, filename)
    # Replace spaces with the specified character
    s = s.replace(" ", replace_char)
    # Remove leading/trailing spaces/underscores
    s = s.strip(replace_char)
    return s
