# main_pipeline.py (This file orchestrates the video generation pipeline)

# Section 1: Core Imports and Setup
import os
import logging
import json
import uuid
import time
import sys
from typing import Optional, List # Added List import
import re # Added re import
import ast # Added ast import

# Initialize logging for this module
logger = logging.getLogger(__name__)

# --- IMPORTANT: Add the project root to sys.path for module imports ---
# This allows Python to find your custom modules like 'config', 'models', 'utils', etc.
try:
    _temp_project_root = '/content/drive/MyDrive/EinsteinCoderProject/tiktok_project'
    if _temp_project_root not in sys.path:
        sys.path.append(_temp_project_root)
        logger.info(f"Added {_temp_project_root} to sys.path.")
except NameError:
    logger.warning("WARNING: PROJECT_ROOT_DIR not defined. Please ensure Colab Cell 1 was run.")
    sys.exit(1)


# Import from your new modular components
try:
    from config import GLOBAL_CONFIG
    from models import VideoParams, VideoSourceType, VideoConcatMode, VideoTransitionMode, VideoAspect
    from utils.shell_utils import sanitize_filename
    from utils.gcs_utils import upload_to_gcs, check_gcs_access
    from utils.cleanup import setup_directories, clean_up_temp_files, VIDEO_DOWNLOADS_DIR, AUDIO_DIR, IMAGES_DIR, OUTPUT_DIR, TEMP_FILES_DIR
    from media_processing.video_ops import (
        get_video_duration, download_multiple_videos,
        concatenate_videos_with_transitions_ffmpeg,
        create_video_from_images_with_ken_burns, re_encode_video_for_gemini
    )
    from media_processing.audio_ops import (
        search_and_download_background_music, generate_narration_audio, get_tts_client, mix_audio_with_ffmpeg
    )
    from media_processing.overlay_ops import add_overlays_and_combine
    from ai_integration.gemini_ops import analyze_video_with_gemini, generate_images_from_prompt, generate_text_content
    
    import google.generativeai as genai
    import google.generativeai.types as genai_types
    genai.configure(api_key=GLOBAL_CONFIG['api_keys']['google_api_key'])
    
except ImportError as e:
    logger.error(f"FATAL ERROR: Could not load modular pipeline components. Please ensure all .py files were written correctly to {os.path.join(_temp_project_root, '')} and that sys.path is set. Error: {e}")
    sys.exit(1)


# --- Logging Setup (remains in main for direct execution feedback) ---
LOGS_DIR = os.path.join(GLOBAL_CONFIG['paths']['base_dir'], GLOBAL_CONFIG['paths']['logs_dir'])
os.makedirs(LOGS_DIR, exist_ok=True)
LOG_FILE_PATH = os.path.join(LOGS_DIR, f"pipeline_log_{time.strftime('%Y%m%d_%H%M%S')}.txt")

if not logging.getLogger().handlers:
    file_handler = logging.FileHandler(LOG_FILE_PATH)
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    stream_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(stream_handler)
    logger.info("Root logging configured.")


# --- Main Pipeline Orchestration Function ---
def run_video_generation_pipeline(params: VideoParams) -> Optional[str]:
    """
    Orchestrates the entire video generation pipeline.

    Args:
        params (VideoParams): An object containing all user-defined parameters for video generation.

    Returns:
        Optional[str]: The path to the final generated video file, or None if an error occurred.
    """
    logger.info(f"--- Starting Video Generation Pipeline for subject: '{params.video_subject}' ---")
    logger.info(f"Pipeline Parameters: {params.model_dump_json(indent=2)}")

    final_output_video_path = None

    try:
        # 1. Setup Runtime Directories
        setup_directories()
        logger.info(f"Step 1/9: Runtime directories set up under {GLOBAL_CONFIG['paths']['base_dir']}")

        # 2. Generate Video Script/Narration Text
        script_prompt = (
            f"Generate a short (approx. {params.final_video_duration_s} seconds) engaging video script about '{params.video_subject}'. "
            f"Include a captivating hook, 3-5 key points with concise explanations, and a clear call to action. "
            f"**Format it strictly as a JSON array of strings, where each string is a short sentence or phrase, ideally less than 15 words.** "
            f"**Do NOT include any comments or visual cues (e.g., '//Visual:') within the JSON or as separate lines.** "
            f"Example: [\"Sentence 1.\", \"Sentence 2.\", \"Sentence 3.\"]" # Use double quotes for JSON
        )
        logger.info(f"Step 2/9: Generating video script from Gemini for subject '{params.video_subject}'...")
        video_script_raw = generate_text_content(script_prompt, GLOBAL_CONFIG['gemini_settings']['text_generation_model'])
        
        if not video_script_raw:
            logger.error("Failed to generate video script.")
            return None
        
        # Parse script into sentences/segments for narration and subtitles
        video_script_segments: List[str] = []
        try:
            # Attempt strict JSON parsing first
            parsed_json = json.loads(video_script_raw)
            if isinstance(parsed_json, list) and all(isinstance(s, str) for s in parsed_json):
                video_script_segments = parsed_json
                logger.info(f"Script generated with {len(video_script_segments)} segments (JSON parse).")
            else:
                raise ValueError("Parsed JSON is not a list of strings.")
        except (json.JSONDecodeError, ValueError) as e:
            logger.warning(f"Could not parse script as strict JSON list ({e}). Attempting robust fallback: extracting sentences. Raw script: {video_script_raw}")
            
            # Robust fallback: Use regex to find text segments that look like sentences
            # This regex aims to capture text that is likely a script segment, avoiding comments or visual cues.
            # It looks for text enclosed in quotes, or unquoted text that's part of a sentence.
            # It specifically ignores parts starting with '(' or '//' if they are on their own line.
            
            # Remove leading/trailing brackets if present (from Gemini's list-like string output)
            cleaned_raw_script = video_script_raw.strip()
            if cleaned_raw_script.startswith("['") and cleaned_raw_script.endswith("']"):
                cleaned_raw_script = cleaned_raw_script[2:-2] # Remove outer [' and ']
            elif cleaned_raw_script.startswith('["') and cleaned_raw_script.endswith('"]'):
                cleaned_raw_script = cleaned_raw_script[2:-2] # Remove outer [" and "]

            # Split by common separators that indicate end of a segment
            # This handles comma-space, period-space, or newline as separators
            potential_segments = re.split(r"'\s*,\s*'|\"\s*,\s*\"|(?<=[.!?])\s*\n?", cleaned_raw_script)
            
            video_script_segments = []
            for s in potential_segments:
                stripped_s = s.strip(" '\"\t\r\n") # Strip various whitespace and quotes
                # Further filter out lines that are clearly visual cues or empty after stripping
                if stripped_s and not stripped_s.startswith('(') and not stripped_s.startswith('//'):
                    video_script_segments.append(stripped_s)
            
            # If after all efforts, only one segment remains and it's a long string,
            # try splitting by common sentence-ending punctuation.
            if len(video_script_segments) == 1 and len(video_script_segments[0].split()) > 10: # If it's a long single segment
                split_by_punc = re.split(r'(?<=[.!?])\s+', video_script_segments[0])
                # Filter out empty strings from split and re-strip
                video_script_segments = [s.strip(" '\".,") for s in split_by_punc if s.strip(" '\".,")]


            logger.info(f"Script generated with {len(video_script_segments)} segments (fallback parse).")
            if not video_script_segments:
                logger.error("Fallback script parsing yielded no valid segments.")
                return None


        # 3. Generate Narration Audio
        full_narration_text = " ".join(video_script_segments) # Narrate the correctly parsed segments
        narration_audio_path = os.path.join(GLOBAL_CONFIG['paths']['base_dir'], AUDIO_DIR, f"narration_{uuid.uuid4().hex}.mp3")
        logger.info(f"Step 3/9: Generating narration audio using {params.speech_synthesis_voice.value} voice...")
        if not generate_narration_audio(full_narration_text, narration_audio_path, params.speech_synthesis_voice.value):
            logger.error("Failed to generate narration audio.")
            return None
        
        narration_duration = get_video_duration(narration_audio_path)
        if not narration_duration:
            logger.warning("Could not determine narration audio duration. Proceeding without exact duration matching.")
            narration_duration = params.final_video_duration_s
        logger.info(f"Narration audio generated with duration: {narration_duration:.2f}s")


        # 4. Search/Generate Visuals (Videos or Images)
        visual_source_paths: List[str] = []
        if params.video_source_type == VideoSourceType.STOCK_FOOTAGE:
            logger.info(f"Step 4/9: Sourcing {params.num_videos_to_source_or_generate} stock videos for '{params.video_subject}'...")
            visual_source_paths = download_multiple_videos(
                search_query=params.video_subject,
                video_source_type=params.video_source_type.value,
                num_videos=params.num_videos_to_source_or_generate,
                max_clip_duration=params.max_clip_duration_s,
                aspect_ratio=params.video_aspect_ratio
            )
        elif params.video_source_type == VideoSourceType.AI_GENERATED_IMAGES:
            logger.info(f"Step 4/9: Generating {params.num_videos_to_source_or_generate} AI images for '{params.video_subject}'...")
            image_prompt = params.video_subject
            if params.image_prompt_suffix:
                image_prompt += f", {params.image_prompt_suffix}"
            visual_source_paths = generate_images_from_prompt(
                image_prompt=image_prompt,
                num_images=params.num_videos_to_source_or_generate
            )
        
        if not visual_source_paths:
            logger.error("Failed to source or generate any visual content.")
            return None
        logger.info(f"Successfully sourced/generated {len(visual_source_paths)} visual assets.")


        # 5. Concatenate Visuals into a Base Video
        base_video_path = os.path.join(GLOBAL_CONFIG['paths']['base_dir'], GLOBAL_CONFIG['paths']['output_dir'], f"base_video_{uuid.uuid4().hex}.mp4")
        
        if params.video_source_type == VideoSourceType.STOCK_FOOTAGE:
            logger.info("Step 5/9: Concatenating video clips with transitions...")
            base_video_path = concatenate_videos_with_transitions_ffmpeg(
                video_paths=visual_source_paths,
                output_path=base_video_path,
                target_duration=narration_duration,
                aspect_ratio=params.video_aspect_ratio,
                transition_mode=params.video_transition_mode
            )
        elif params.video_source_type == VideoSourceType.AI_GENERATED_IMAGES:
            logger.info("Step 5/9: Creating video from generated images with Ken Burns effect...")
            base_video_path = create_video_from_images_with_ken_burns(
                image_paths=visual_source_paths,
                output_path=base_video_path,
                target_duration=narration_duration,
                aspect_ratio=params.video_aspect_ratio
            )
        
        if not base_video_path:
            logger.error("Failed to create base video from visual assets.")
            return None
        logger.info(f"Base video created: {base_video_path}")


        # 6. Generate Subtitle Data (if enabled)
        subtitles_data = None
        if params.enable_subtitles:
            logger.info("Step 6/9: Generating subtitle data from narration audio...")
            
            # Divide narration duration by number of segments for estimated subtitle display time
            # Ensure video_script_segments is correctly populated before this step
            if not video_script_segments:
                logger.warning("No script segments available for subtitle generation.")
                subtitles_data = [] # Ensure it's an empty list to avoid errors later
            else:
                estimated_segment_duration = narration_duration / len(video_script_segments) 
                
                subtitles_data = []
                current_time_ms = 0
                for segment in video_script_segments:
                    # Estimate segment duration based on word count (rough estimate, can be improved with real TTS timings)
                    words_per_second = 2.5 # Average speaking rate
                    segment_word_count = len(segment.split())
                    segment_duration_s = segment_word_count / words_per_second
                    
                    # Ensure a minimum duration and cap to avoid excessively long subtitles
                    segment_duration_ms = max(500, int(segment_duration_s * 1000))
                    segment_duration_ms = min(segment_duration_ms, 5000) # Max 5 seconds per subtitle
                    
                    subtitles_data.append({
                        "start": current_time_ms,
                        "end": current_time_ms + segment_duration_ms,
                        "text": segment
                    })
                    current_time_ms += segment_duration_ms
            logger.info(f"Generated {len(subtitles_data)} subtitle entries.")


        # 7. Search and Mix Background Music
        mixed_audio_path = narration_audio_path
        
        logger.info("Step 7/9: Searching for background music...")
        background_music_path = search_and_download_background_music(
            query=GLOBAL_CONFIG['audio_settings']['default_background_music_query'],
            target_duration_s=narration_duration,
            output_filepath=os.path.join(GLOBAL_CONFIG['paths']['base_dir'], AUDIO_DIR, f"bg_music_{uuid.uuid4().hex}.mp3")
        )
        
        if background_music_path:
            logger.info("Mixing narration and background music...")
            mixed_audio_path = mix_audio_with_ffmpeg(
                narration_path=narration_audio_path,
                music_path=background_music_path,
                output_path=os.path.join(GLOBAL_CONFIG['paths']['base_dir'], AUDIO_DIR, f"final_audio_{uuid.uuid4().hex}.mp3"),
                music_volume_db=GLOBAL_CONFIG['audio_settings']['default_background_music_volume']
            )
            if not mixed_audio_path:
                logger.warning("Failed to mix audio. Proceeding with narration only.")
                mixed_audio_path = narration_audio_path
        else:
            logger.info("No background music found or downloaded. Proceeding with narration only.")


        # 8. Add Overlays (Subtitles) and Combine Video/Audio
        final_video_name = sanitize_filename(f"output_video_{params.video_subject[:50]}.mp4")
        final_output_video_path = os.path.join(GLOBAL_CONFIG['paths']['base_dir'], OUTPUT_DIR, final_video_name)
        
        logger.info(f"Step 8/9: Combining video, final audio, and subtitles to: {final_output_video_path}")
        final_video_path = add_overlays_and_combine(
            video_path=base_video_path,
            audio_path=mixed_audio_path,
            output_path=final_output_video_path,
            subtitles_data=subtitles_data if params.enable_subtitles else None,
            subtitle_font=params.subtitle_font,
            subtitle_position=params.subtitle_position,
            subtitle_font_size=params.subtitle_font_size,
            subtitle_color=params.subtitle_color,
            subtitle_outline_color=params.subtitle_outline_color,
            subtitle_outline_width=params.subtitle_outline_width,
            aspect_ratio=params.video_aspect_ratio
        )

        if not final_video_path:
            logger.error("Failed to produce final video.")
            return None
        logger.info(f"Final video successfully generated locally: {final_video_path}")


        # 9. (Optional) Upload final video to GCS
        gcs_bucket = GLOBAL_CONFIG['gcp']['gcs_bucket_name']
        gcs_dest_blob = f"video_production/{final_video_name}" # UPLOAD TO THE NEW FOLDER!
        
        if gcs_bucket and gcs_bucket != 'YOUR_GCS_BUCKET_NAME': # Ensure bucket name is set and not placeholder
            logger.info(f"Step 9/9: Uploading final video to GCS bucket: {gcs_bucket}/{gcs_dest_blob}")
            if check_gcs_access(gcs_bucket, GLOBAL_CONFIG['gcp']['service_account_key_path']):
                if upload_to_gcs(
                    gcs_bucket,
                    final_video_path,
                    gcs_dest_blob,
                    GLOBAL_CONFIG['gcp']['service_account_key_path']
                ):
                    logger.info(f"Final video uploaded to GCS successfully: gs://{gcs_bucket}/{gcs_dest_blob}")
                else:
                    logger.warning("Failed to upload final video to GCS.")
            else:
                logger.error("GCS access check failed. Skipping upload.")
        else:
            logger.warning("GCS bucket name not configured or is placeholder. Skipping GCS upload.")


        return final_video_path

    except Exception as e:
        logger.error(f"An unexpected error occurred during pipeline execution: {e}", exc_info=True)
        return None
    finally:
        # 10. Clean up temporary files
        # Temporarily commented out for debugging
        # clean_up_temp_files()
        logger.info("Pipeline execution complete. Temporary files are retained in /tmp/tiktok_project_runtime for inspection.")
