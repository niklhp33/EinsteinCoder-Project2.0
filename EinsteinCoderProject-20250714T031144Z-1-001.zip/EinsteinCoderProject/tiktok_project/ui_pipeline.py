import ipywidgets as widgets
from IPython.display import display # Keep IPython.display.display for top-level display
import logging
import os
from typing import Dict, Any

# Ensure project root is in sys.path if this script is run directly
import sys
try:
    if 'PROJECT_ROOT_DIR' not in globals():
        # Fallback if PROJECT_ROOT_DIR not defined by previous cells
        PROJECT_ROOT_DIR = '/content/drive/MyDrive/EinsteinCoderProject/tiktok_project'
        print(f"UI Script: PROJECT_ROOT_DIR not found, using fallback: {PROJECT_ROOT_DIR}")
    if PROJECT_ROOT_DIR not in sys.path:
        sys.path.append(PROJECT_ROOT_DIR)
        print(f"UI Script: Added {PROJECT_ROOT_DIR} to sys.path.")
except NameError:
    print("UI Script: PROJECT_ROOT_DIR is not defined. Ensure Colab Cell 1 was run.")
    PROJECT_ROOT_DIR = '/content/drive/MyDrive/EinsteinCoderProject/tiktok_project' # Define it for subsequent code
    if PROJECT_ROOT_DIR not in sys.path:
        sys.path.append(PROJECT_ROOT_DIR)

# Import necessary modules from your project structure
# These imports will only succeed if the .py files are correctly written to Drive
# and PROJECT_ROOT_DIR is in sys.path
try:
    from config import GLOBAL_CONFIG
    from models import VideoParams, VideoSourceType, VideoConcatMode, VideoTransitionMode, VideoAspect, \
                       SpeechSynthesisVoice, SubtitleFont, SubtitlePosition, VideoLanguage
    from main_pipeline import run_video_generation_pipeline # The core pipeline function
    from utils.cleanup import LOGS_DIR # Assuming LOGS_DIR is correctly defined for cleanup
except ImportError as e:
    # Corrected: Removed extra ')' and ensured it's displayed as a widget.
    display(widgets.HTML(f"<div style='color: red; font-weight: bold;'>ERROR: Failed to load pipeline modules.<br>Please ensure all Python files are correctly written to Google Drive and try again.<br>Details: {e}</div>"))
    # The print statement below is for internal Colab logs, not meant for direct user display.
    print(f"UI Script: FATAL ERROR: Could not load backend modules. Please ensure all Python files are correctly written to Google Drive and try again. Details: {e}")
    # sys.exit(1) # Do not exit, just inform user in UI

# Initialize logging for UI feedback
logger = logging.getLogger() # Get the root logger
# If logging handlers are not already set up (e.g., from main_pipeline.py), add a stream handler
if not logger.handlers:
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setLevel(logging.INFO)
    stream_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
    logger.addHandler(stream_handler)
    logger.setLevel(logging.INFO) # Set default level if not set

logger.info("UI Script: Imported all necessary modules. Setting up UI.")


# --- Global UI Elements & Output Areas ---
output_area = widgets.Output() # For displaying logs and results
download_link_output = widgets.Output() # For displaying the download link

# --- Parameter Storage (for retaining values between runs or updates) ---
# Initialize VideoParams with default values
video_params = VideoParams()
# Store the last run parameters to detect changes and for re-runs
_last_run_params_hash = None

# --- UI Widgets ---

# Video Script Settings
video_subject_input = widgets.Text(
    description="Video Subject:",
    placeholder="e.g., Deep Sea Exploration",
    value=video_params.video_subject,
    layout=widgets.Layout(width='auto')
)
video_language_dropdown = widgets.Dropdown(
    options=[(lang.name, lang) for lang in VideoLanguage],
    value=video_params.video_language,
    description="Language:",
    layout=widgets.Layout(width='auto')
)

# Video Settings
video_source_type_dropdown = widgets.Dropdown(
    options=[(source.value, source) for source in VideoSourceType],
    value=video_params.video_source_type,
    description="Video Source:",
    layout=widgets.Layout(width='auto')
)
image_prompt_suffix_input = widgets.Text(
    description="Image Prompt Suffix:",
    placeholder="e.g., photorealistic, stunning details",
    value=video_params.image_prompt_suffix,
    layout=widgets.Layout(width='auto'),
    disabled=(video_params.video_source_type != VideoSourceType.AI_GENERATED_IMAGES)
)
video_concat_mode_dropdown = widgets.Dropdown(
    options=[(mode.value, mode) for mode in VideoConcatMode],
    value=video_params.video_concat_mode,
    description="Concatenation:",
    layout=widgets.Layout(width='auto')
)
video_transition_mode_dropdown = widgets.Dropdown(
    options=[(mode.value, mode) for mode in VideoTransitionMode],
    value=video_params.video_transition_mode,
    description="Transition:",
    layout=widgets.Layout(width='auto')
)
video_aspect_ratio_dropdown = widgets.Dropdown(
    options=[(aspect.value, aspect) for aspect in VideoAspect],
    value=video_params.video_aspect_ratio,
    description="Aspect Ratio:",
    layout=widgets.Layout(width='auto')
)
max_clip_duration_input = widgets.IntSlider(
    value=video_params.max_clip_duration_s,
    min=1, max=30, step=1,
    description="Max Clip Duration (s):",
    orientation='horizontal',
    readout=True,
    readout_format='d',
    layout=widgets.Layout(width='auto')
)
num_videos_to_source_input = widgets.IntSlider(
    value=video_params.num_videos_to_source_or_generate,
    min=1, max=20, step=1,
    description="# Clips/Images:",
    orientation='horizontal',
    readout=True,
    readout_format='d',
    layout=widgets.Layout(width='auto')
)
final_video_duration_input = widgets.IntSlider(
    value=video_params.final_video_duration_s,
    min=15, max=180, step=5,
    description="Final Video Duration (s):",
    orientation='horizontal',
    readout=True,
    readout_format='d',
    layout=widgets.Layout(width='auto')
)

# Audio Settings
speech_synthesis_voice_dropdown = widgets.Dropdown(
    options=[(voice.value, voice) for voice in SpeechSynthesisVoice],
    value=video_params.speech_synthesis_voice,
    description="Voice:",
    layout=widgets.Layout(width='auto')
)

# Subtitle Settings
enable_subtitles_checkbox = widgets.Checkbox(
    value=video_params.enable_subtitles,
    description="Enable Subtitles",
    indent=False,
    layout=widgets.Layout(width='auto')
)
subtitle_font_dropdown = widgets.Dropdown(
    options=[(font.value, font) for font in SubtitleFont],
    value=video_params.subtitle_font,
    description="Font:",
    layout=widgets.Layout(width='auto'),
    disabled=not video_params.enable_subtitles
)
subtitle_position_dropdown = widgets.Dropdown(
    options=[(pos.value, pos) for pos in SubtitlePosition],
    value=video_params.subtitle_position,
    description="Position:",
    layout=widgets.Layout(width='auto'),
    disabled=not video_params.enable_subtitles
)
subtitle_font_size_slider = widgets.IntSlider(
    value=video_params.subtitle_font_size,
    min=10, max=100, step=1,
    description="Size:",
    orientation='horizontal',
    readout=True,
    readout_format='d',
    layout=widgets.Layout(width='auto'),
    disabled=not video_params.enable_subtitles
)
subtitle_color_text = widgets.Text(
    value=video_params.subtitle_color,
    description="Color:",
    layout=widgets.Layout(width='auto'),
    disabled=not video_params.enable_subtitles
)
subtitle_outline_color_text = widgets.Text(
    value=video_params.subtitle_outline_color,
    description="Outline Color:",
    layout=widgets.Layout(width='auto'),
    disabled=not video_params.enable_subtitles
)
subtitle_outline_width_slider = widgets.IntSlider(
    value=video_params.subtitle_outline_width,
    min=0, max=10, step=1,
    description="Outline Width:",
    orientation='horizontal',
    readout=True,
    readout_format='d',
    layout=widgets.Layout(width='auto'),
    disabled=not video_params.enable_subtitles
)

# --- Button ---
generate_video_button = widgets.Button(
    description="Generate Video",
    button_style="success",
    icon="play",
    layout=widgets.Layout(width='auto')
)

# --- UI Callbacks ---

def update_params_from_ui():
    """Updates the global video_params object with current UI values."""
    video_params.video_subject = video_subject_input.value
    video_params.video_language = video_language_dropdown.value
    video_params.video_source_type = video_source_type_dropdown.value
    video_params.image_prompt_suffix = image_prompt_suffix_input.value if video_params.video_source_type == VideoSourceType.AI_GENERATED_IMAGES else None
    video_params.video_concat_mode = video_concat_mode_dropdown.value
    video_params.video_transition_mode = video_transition_mode_dropdown.value
    video_params.video_aspect_ratio = video_aspect_ratio_dropdown.value
    video_params.max_clip_duration_s = max_clip_duration_input.value
    video_params.num_videos_to_source_or_generate = num_videos_to_source_input.value
    video_params.final_video_duration_s = final_video_duration_input.value
    video_params.speech_synthesis_voice = speech_synthesis_voice_dropdown.value
    video_params.enable_subtitles = enable_subtitles_checkbox.value
    video_params.subtitle_font = subtitle_font_dropdown.value
    video_params.subtitle_position = subtitle_position_dropdown.value
    video_params.subtitle_font_size = subtitle_font_size_slider.value
    video_params.subtitle_color = subtitle_color_text.value
    video_params.subtitle_outline_color = subtitle_outline_color_text.value
    video_params.subtitle_outline_width = subtitle_outline_width_slider.value

    # Update disabled states based on enable_subtitles
    subtitle_font_dropdown.disabled = not video_params.enable_subtitles
    subtitle_position_dropdown.disabled = not video_params.enable_subtitles
    subtitle_font_size_slider.disabled = not video_params.enable_subtitles
    subtitle_color_text.disabled = not video_params.enable_subtitles
    subtitle_outline_color_text.disabled = not video_params.enable_subtitles
    subtitle_outline_width_slider.disabled = not video_params.enable_subtitles

    # Update disabled state of image_prompt_suffix
    image_prompt_suffix_input.disabled = (video_params.video_source_type != VideoSourceType.AI_GENERATED_IMAGES)


def on_generate_video_button_clicked(b):
    with output_area:
        output_area.clear_output(wait=True) # Clear previous logs
        download_link_output.clear_output() # Clear previous download link
        logger.info("--- Starting Video Generation Pipeline ---")
        
        # Update params from UI before running
        update_params_from_ui()

        # Check if Google Cloud service account key is set
        service_account_key_path = GLOBAL_CONFIG['gcp']['service_account_key_path']
        if not os.path.exists(service_account_key_path):
            logger.error(f"ERROR: GCP Service Account Key not found at {service_account_key_path}.")
            logger.error("Please ensure you have uploaded your service account JSON key to Colab and updated config.py with the correct path.")
            display(widgets.HTML("<div style='color: red; font-weight: bold;'>ERROR: GCP Service Account Key Missing! Please check logs above.</div>"))
            return
        
        # Run the main pipeline function
        final_video_path = run_video_generation_pipeline(video_params)

        if final_video_path:
            logger.info("Video Generation Pipeline Completed! 🎉")
            # Create a download link for the generated video
            display_download_link(final_video_path)
        else:
            logger.error("Video Generation Pipeline Failed. Check logs for errors.")
            display(widgets.HTML("<div style='color: red; font-weight: bold;'>Video Generation Failed! Please check logs above for details.</div>"))

def display_download_link(file_path):
    """Generates and displays a download link for the given file path."""
    with download_link_output:
        download_link_output.clear_output()
        if os.path.exists(file_path):
            file_name = os.path.basename(file_path)
            # Use FileLink to provide a download link in Colab
            from IPython.display import FileLink
            display(widgets.HTML(f"<h3>Download Generated Video:</h3>")) # Changed to widgets.HTML
            display(FileLink(file_path, result_html_template='<a href="{link}" download="{link_name}" target="_blank">{link_text}</a>'))
            logger.info(f"Download link generated for {file_name}")
        else:
            logger.error(f"Cannot create download link: File not found at {file_path}")


# Event Handlers
generate_video_button.on_click(on_generate_video_button_clicked)

# Observe changes for dynamic UI elements
video_source_type_dropdown.observe(lambda change: update_params_from_ui(), names='value')
enable_subtitles_checkbox.observe(lambda change: update_params_from_ui(), names='value')

# --- Layout UI ---

# Basic Settings Section
basic_settings_children = [
    widgets.VBox([video_subject_input, video_language_dropdown]),
    widgets.VBox([video_source_type_dropdown, image_prompt_suffix_input]),
    widgets.VBox([video_concat_mode_dropdown, video_transition_mode_dropdown, video_aspect_ratio_dropdown]),
    widgets.VBox([max_clip_duration_input, num_videos_to_source_input, final_video_duration_input]),
]
# Use GridBox for a more structured layout
basic_settings_grid = widgets.GridBox(
    children=basic_settings_children,
    layout=widgets.Layout(
        width='100%',
        grid_template_columns='repeat(auto-fit, minmax(300px, 1fr))',
        grid_gap='10px'
    )
)
basic_settings_accordion = widgets.Accordion(children=[basic_settings_grid])
basic_settings_accordion.set_title(0, 'Video Script & Source Settings')

# Audio Settings Section
audio_settings_children = [
    widgets.VBox([speech_synthesis_voice_dropdown]),
]
audio_settings_grid = widgets.GridBox(
    children=audio_settings_children,
    layout=widgets.Layout(
        width='100%',
        grid_template_columns='repeat(auto-fit, minmax(300px, 1fr))',
        grid_gap='10px'
    )
)
audio_settings_accordion = widgets.Accordion(children=[audio_settings_grid])
audio_settings_accordion.set_title(0, 'Audio Settings')


# Subtitle Settings Section
subtitle_settings_children = [
    widgets.VBox([enable_subtitles_checkbox]),
    widgets.VBox([subtitle_font_dropdown, subtitle_position_dropdown]),
    widgets.VBox([subtitle_font_size_slider]),
    widgets.VBox([subtitle_color_text, subtitle_outline_color_text, subtitle_outline_width_slider]),
]
subtitle_settings_grid = widgets.GridBox(
    children=subtitle_settings_children,
    layout=widgets.Layout(
        width='100%',
        grid_template_columns='repeat(auto-fit, minmax(300px, 1fr))',
        grid_gap='10px'
    )
)
subtitle_settings_accordion = widgets.Accordion(children=[subtitle_settings_grid])
subtitle_settings_accordion.set_title(0, 'Subtitle Settings')


# Main UI display
main_ui = widgets.VBox([
    widgets.HTML("<h2>Einstein Coder: TikTok Video Generation Pipeline</h2>"), # Changed from IPython.display.HTML
    widgets.HTML("<p>Configure your video parameters below and click 'Generate Video'!</p>"), # Changed from IPython.display.HTML
    basic_settings_accordion,
    audio_settings_accordion,
    subtitle_settings_accordion,
    widgets.VBox([
        generate_video_button,
        download_link_output, # For the download link after generation
        widgets.HTML("<h3>Pipeline Logs:</h3>"), # Changed from IPython.display.HTML
        output_area # For real-time logs
    ], layout=widgets.Layout(padding='10px', border='1px solid lightgray', border_radius='5px'))
])

# Removed display(main_ui) from here. It's explicitly called in Cell 17
# Initial update to set correct disabled states
# This function call is moved to the end of Colab Cell 17 after display(ui_pipeline.main_ui)
# update_params_from_ui()

logger.info("UI Script: User Interface elements defined.") # Changed log message
