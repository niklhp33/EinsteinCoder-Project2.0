import google.generativeai as genai
import google.generativeai.types as genai_types
import logging
import os
import uuid
import time # For time.sleep
from typing import List, Dict, Any, Optional

from config import GLOBAL_CONFIG
from utils.gcs_utils import download_from_gcs, upload_to_gcs # Use modular GCS functions
from utils.shell_utils import run_shell_command # For ffprobe/ffmpeg if needed for analysis
from utils.cleanup import TEMP_FILES_DIR # For temporary files during analysis

# Initialize logging
logger = logging.getLogger(__name__)

# Base directory for runtime files (e.g., temp files)
BASE_DIR = GLOBAL_CONFIG['paths']['base_dir']

# Configure Gemini API key globally (ideally done in main_pipeline.py or config setup)
genai.configure(api_key=GLOBAL_CONFIG['api_keys']['google_api_key'])

# Initialize the Gemini model for content generation (e.g., script, image prompts)
gemini_script_model = genai.GenerativeModel('gemini-1.5-pro-latest') # Or gemini-1.5-flash-latest

# Initialize the Gemini model for video analysis (requires specific capabilities)
# For video analysis, gemini-1.5-pro-latest is often recommended
gemini_video_analysis_model = genai.GenerativeModel('gemini-1.5-pro-latest')


def generate_text_content(prompt: str, model_name: str = 'gemini-1.5-pro-latest') -> Optional[str]:
    """
    Generates text content using the specified Gemini model.
    """
    logger.info(f"Generating text content with model {model_name} for prompt: {prompt[:100]}...")
    try:
        model = genai.GenerativeModel(model_name)
        response = model.generate_content(prompt)
        if response and response.text:
            logger.info("Text content generated successfully.")
            return response.text.strip()
        else:
            logger.warning(f"No text content generated for prompt: {prompt}. Response: {response}")
            return None
    except Exception as e:
        logger.error(f"Error generating text content with Gemini: {e}")
        return None

def generate_images_from_prompt(image_prompt: str, num_images: int = 1) -> List[str]:
    """
    Generates images using a suitable AI model (like Gemini/Imagen if available and configured).
    Currently, this will return placeholder paths or use a basic approach.
    For actual image generation, you'd integrate a service like Imagen, DALL-E, etc.
    If Gemini 1.5 Pro's image generation capabilities are robust, it can be used.
    
    For now, this function will simulate image generation or rely on a simple text-to-image API if available.
    As Gemini 1.5 Pro's image generation is primarily through an API call, we'll return placeholder
    paths and log a note that a proper image gen API needs to be integrated here.
    """
    logger.warning("AI Image generation is a placeholder. Real integration for DALL-E/Imagen/etc. required.")
    logger.info(f"Simulating AI image generation for prompt: '{image_prompt}' (x{num_images})")
    
    # In a real scenario, you'd call an image generation API here.
    # Example for a hypothetical direct Gemini image gen if available and robust:
    # try:
    #     images = gemini_script_model.generate_content(image_prompt, generation_config={'response_mime_type': 'image/jpeg'})
    #     # Process and save images here
    # except Exception as e:
    #     logger.error(f"Error generating images with Gemini: {e}")

    # For now, return dummy paths and log a warning
    image_paths = []
    images_dir = os.path.join(BASE_DIR, GLOBAL_CONFIG['paths']['images_dir'])
    os.makedirs(images_dir, exist_ok=True)

    for i in range(num_images):
        dummy_image_path = os.path.join(images_dir, f"ai_gen_image_{uuid.uuid4().hex}.png")
        # Create a dummy file to simulate generation
        with open(dummy_image_path, 'w') as f:
            f.write("dummy image content")
        image_paths.append(dummy_image_path)
        logger.info(f"Generated dummy image: {dummy_image_path}")

    return image_paths


def analyze_video_with_gemini(
    gcs_video_uri: str,
    prompt: str,
    output_temp_dir: str,
    service_account_key_path: str,
    gcs_bucket_name: str
) -> Optional[str]:
    """
    Analyzes a video stored in GCS using Gemini 1.5 Pro's video understanding capabilities.
    Downloads the video temporarily, feeds it to Gemini, and returns the analysis.
    """
    logger.info(f"Analyzing video from GCS URI: {gcs_video_uri} with Gemini.")

    temp_files_path = os.path.join(BASE_DIR, TEMP_FILES_DIR)
    os.makedirs(temp_files_path, exist_ok=True)

    local_video_path = os.path.join(temp_files_path, f"temp_video_{uuid.uuid4().hex}.mp4")
    
    # Extract blob name from GCS URI (e.g., gs://your-bucket/path/to/video.mp4 -> path/to/video.mp4)
    blob_name = gcs_video_uri.replace(f"gs://{gcs_bucket_name}/", "")
    if not blob_name:
        logger.error(f"Invalid GCS video URI or bucket name: {gcs_video_uri}, {gcs_bucket_name}")
        return None

    # Download video from GCS
    if not download_from_gcs(gcs_bucket_name, blob_name, local_video_path, service_account_key_path):
        logger.error(f"Failed to download video {gcs_video_uri} for Gemini analysis.")
        return None
    
    # Ensure video is compatible with Gemini (e.g., file size, format)
    # The re_encode_video_for_gemini function (from video_ops) can be used here.
    # For now, we'll assume it's compatible or handle basic re-encoding if needed.
    # For very large files, consider stream analysis or more advanced methods.
    
    # For demo purposes, we will treat the local video path directly.
    # In a production setup with very large files, it might involve GCS FUSE or streaming.

    try:
        # Create a File instance from the local video path
        video_file = genai.upload_file(path=local_video_path)
        logger.info(f"Uploaded {local_video_path} as File object for Gemini analysis.")

        # Wait for the file to be processed by Gemini (async operation)
        while video_file.state.name == "PROCESSING":
            logger.info("Gemini file processing...")
            time.sleep(5)
            video_file = genai.get_file(video_file.name)
        
        if video_file.state.name == "FAILED":
            logger.error(f"Gemini failed to process video file: {video_file.name}. Reason: {video_file.reason}")
            return None

        # Send video and prompt to Gemini
        contents = [
            video_file,
            prompt
        ]
        
        response = gemini_video_analysis_model.generate_content(contents, request_options={"timeout": 600}) # 10 min timeout

        # Delete the uploaded file from Gemini's storage
        genai.delete_file(video_file.name)
        logger.info(f"Deleted temporary Gemini file: {video_file.name}")

        if response and response.text:
            logger.info("Video analysis completed successfully.")
            return response.text.strip()
        else:
            logger.warning(f"No analysis text generated for video: {gcs_video_uri}. Response: {response}")
            return None
    except Exception as e:
        logger.error(f"Error during Gemini video analysis for {gcs_video_uri}: {e}")
        return None
    finally:
        # Clean up local temporary video file
        if os.path.exists(local_video_path):
            os.remove(local_video_path)
            logger.info(f"Cleaned up local temporary video file: {local_video_path}")
