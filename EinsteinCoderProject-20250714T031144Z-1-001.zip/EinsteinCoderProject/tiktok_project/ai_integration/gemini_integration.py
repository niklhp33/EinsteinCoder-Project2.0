import os
import logging
import google.generativeai as genai
import json
import re
from typing import Optional, List, Dict, Any, Tuple

from google.generativeai.types import HarmCategory, HarmBlockThreshold
from google.api_core.exceptions import GoogleAPIError, RetryError
from PIL import Image # For opening image files if needed by Gemini
from moviepy.editor import VideoFileClip # For getting video frames if needed by Gemini

from ..config import GLOBAL_CONFIG
from ..utils.shell_utils import run_shell_command
from ..utils.cleanup import TEMP_FILES_DIR

logger = logging.getLogger(__name__)

# --- Gemini API Configuration ---
def _configure_gemini_api():
    api_key = GLOBAL_CONFIG['api_keys']['google_api_key']
    if not api_key or api_key == 'YOUR_GOOGLE_API_KEY_PLACEHOLDER':
        logger.error("Google API key (GOOGLE_API_KEY) is not configured in Colab Secrets. Gemini API calls will fail.")
        return False
    genai.configure(api_key=api_key)
    logger.info("Google Gemini API configured.")
    return True

_configure_gemini_api() # Configure API on module import

# --- Safety Settings for Gemini ---
_safety_settings = {
    HarmCategory.HARM_CATEGORY_HARASSMENT: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_HATE_SPEECH: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: HarmBlockThreshold.BLOCK_NONE,
    HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: HarmBlockThreshold.BLOCK_NONE,
}

# --- Core Text Generation Function ---
def generate_text_content(prompt: str, model_name: str = 'gemini-1.5-pro-latest') -> Optional[str]:
    """
    Generates text content using a specified Gemini model.
    Args:
        prompt: The text prompt for generation.
        model_name: The Gemini model to use (e.g., 'gemini-1.5-pro-latest').
    Returns:
        The generated text content as a string, or None on failure.
    """
    if not _configure_gemini_api(): # Re-check configuration before each call
        return None
    
    logger.info(f"Generating text content with model {model_name} for prompt: {prompt[:100]}...")
    try:
        model = genai.GenerativeModel(model_name=model_name, safety_settings=_safety_settings)
        response = model.generate_content(prompt)
        
        if response.parts:
            generated_text = response.text
            logger.info("Text content generated successfully.")
            return generated_text
        elif response.candidates:
            # Handle cases where `response.text` might be empty but candidates exist
            for candidate in response.candidates:
                if candidate.content and candidate.content.parts:
                    generated_text = "".join([p.text for p in candidate.content.parts])
                    logger.info("Text content generated successfully (from candidate parts).")
                    return generated_text
        
        logger.warning(f"Gemini text generation returned no content. Prompt: {prompt[:200]}")
        logger.warning(f"Response: {response}")
        return None

    except GoogleAPIError as e:
        logger.error(f"Google API error during text generation: {e}")
        return None
    except RetryError as e:
        logger.error(f"Retry error during text generation (likely a temporary network issue or rate limit): {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred during text generation: {e}", exc_info=True)
        return None

# --- Video Script Generation ---
def generate_video_script(subject: str, language: str = "English", duration_s: int = 60) -> List[str]:
    """
    Generates a video script about a given subject using Gemini, formatted as a list of sentences.
    Args:
        subject: The main topic/subject of the video.
        language: The desired language for the script.
        duration_s: Target duration of the video in seconds.
    Returns:
        A list of script segments (sentences/short phrases). Returns an empty list on failure.
    """
    prompt = (
        f"Generate a short (approx. {duration_s} seconds) engaging video script about '{subject}' in {language}. "
        f"Include a captivating hook, a few key points, and a clear call to action. "
        f"The script should be returned as a strict JSON list of strings, where each string is a sentence or a very short phrase. "
        f"For example: [\"This is the hook.\", \"First key point.\", \"Second key point.\", \"Call to action.\"]"
        f"Ensure there are at least 10 sentences for good content segmentation."
    )
    
    script_json_str = generate_text_content(prompt, model_name=GLOBAL_CONFIG['gemini_settings']['text_generation_model'])
    
    if not script_json_str:
        logger.error("Failed to generate raw script text from Gemini.")
        return []

    # Attempt to parse as strict JSON list
    try:
        script_list = json.loads(script_json_str)
        if isinstance(script_list, list) and all(isinstance(s, str) for s in script_list):
            logger.info("Script parsed successfully as strict JSON list.")
            return script_list
        else:
            logger.warning(f"Parsed JSON is not a list of strings. Raw: {script_json_str}")
            # Fallback to robust parsing
            return _robust_script_parse(script_json_str)
    except json.JSONDecodeError as e:
        logger.warning(f"Could not parse script as strict JSON list ({e}). Attempting robust fallback. Raw script: {script_json_str}")
        return _robust_script_parse(script_json_str)
    except Exception as e:
        logger.error(f"An unexpected error occurred during script parsing: {e}", exc_info=True)
        return []

def _robust_script_parse(text: str) -> List[str]:
    """
    Attempts to robustly parse a string into a list of sentences,
    handling cases where strict JSON parsing might fail but the text
    still resembles a list or natural language sentences.
    This version is more aggressive in stripping JSON artifacts.
    """
    # Remove common JSON wrappers and markdown fences if present
    text = text.strip()
    if text.startswith('```json') and text.endswith('```'):
        text = text[len('```json'):-len('```')].strip() # Remove ```json\n and \n```
    if text.startswith('[') and text.endswith(']'):
        text = text[1:-1].strip() # Remove outer brackets

    # Split by comma followed by potential space, or by newline, then clean.
    # Also, handle sentences that end with punctuation and are followed by a quote.
    segments = re.split(r'(?<=[.!?])\s*(?=["\'\]])?|\s*,\s*|\n', text)
    
    processed_segments = []
    for segment in segments:
        segment = segment.strip().strip('"').strip("'") # Remove leading/trailing whitespace and quotes
        if segment:
            # Further clean up any leftover JSON string artifacts like ']' at the end
            segment = segment.replace('\n', ' ').strip() # Remove newlines within segments
            if segment.startswith('\\"') and segment.endswith('\\"'): # Handle escaped quotes
                segment = segment[2:-2]
            
            # Remove any remaining markdown/JSON artifacts that could still be present
            segment = re.sub(r'^[\[\]`"\'\s]+|[\[\]`"\'\s]+$', '', segment)
            
            if segment: # Only add if not empty after aggressive cleaning
                processed_segments.append(segment)
    
    if not processed_segments:
        # Final fallback: split by common sentence endings if no other structure found
        logger.warning("Fallback parse yielded no segments. Attempting sentence splitting as last resort.")
        processed_segments = re.split(r'(?<=[.!?])\s+', text)
        processed_segments = [s.strip() for s in processed_segments if s.strip()]
        if not processed_segments and text.strip(): # If still empty, just take the whole text as one segment
             processed_segments = [text.strip()]


    logger.info(f"Script generated with {len(processed_segments)} segments (robust fallback parse).")
    return processed_segments

# --- Video Analysis (Multi-modal) ---
def analyze_video_content(video_path: str, prompt: str, model_name: str = 'gemini-1.5-pro-latest') -> Optional[str]:
    """
    Analyzes video content using a multi-modal Gemini model.
    Args:
        video_path: Path to the video file.
        prompt: The prompt for video analysis.
        model_name: The Gemini model to use (e.g., 'gemini-1.5-pro-latest').
    Returns:
        The analysis result as a string, or None on failure.
    """
    if not os.path.exists(video_path):
        logger.error(f"Video file not found for analysis: {video_path}")
        return None
    
    file_size_mb = os.path.getsize(video_path) / (1024 * 1024)
    max_file_size_mb = GLOBAL_CONFIG['gemini_settings']['video_analysis_max_file_size_mb']
    if file_size_mb > max_file_size_mb:
        logger.error(f"Video file size ({file_size_mb:.2f}MB) exceeds Gemini's current limit ({max_file_size_mb}MB). Cannot analyze.")
        logger.error("Consider reducing video duration or resolution for analysis, or using a local ASR model for transcription.")
        return None

    mime_type = "video/mp4" # Assuming MP4 for now
    
    logger.info(f"Analyzing video content for {video_path} with prompt: {prompt[:100]}...")
    try:
        video_file_data = genai.upload_file(video_path, mime_type=mime_type)
        logger.info(f"Uploaded video to Gemini: {video_file_data.uri}")
        
        model = genai.GenerativeModel(model_name=model_name, safety_settings=_safety_settings)
        
        contents = [
            prompt,
            video_file_data
        ]

        response = model.generate_content(contents)
        
        genai.delete_file(video_file_data.name)
        logger.info(f"Deleted temporary video file from Gemini storage: {video_file_data.uri}")

        if response.parts:
            analysis_result = response.text
            logger.info("Video analysis successful.")
            return analysis_result
        elif response.candidates:
            for candidate in response.candidates:
                if candidate.content and candidate.content.parts:
                    analysis_result = "".join([p.text for p in candidate.content.parts])
                    logger.info("Video analysis successful (from candidate parts).")
                    return analysis_result
        
        logger.warning(f"Gemini video analysis returned no content. Prompt: {prompt[:200]}")
        logger.warning(f"Response: {response}")
        return None

    except GoogleAPIError as e:
        logger.error(f"Google API error during video analysis: {e}")
        return None
    except RetryError as e:
        logger.error(f"Retry error during video analysis (likely network issue or rate limit): {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred during video analysis: {e}", exc_info=True)
        return None
