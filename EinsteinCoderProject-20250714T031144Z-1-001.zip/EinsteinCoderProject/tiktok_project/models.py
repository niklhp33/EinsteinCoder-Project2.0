from enum import Enum
from pydantic import BaseModel, Field, PrivateAttr
from typing import Optional, List, Dict, Any

# --- Enums ---

class VideoSourceType(str, Enum):
    STOCK_FOOTAGE = "Stock Footage (Pexels/Pixabay)"
    AI_GENERATED_IMAGES = "AI Generated Images"

class VideoConcatMode(str, Enum):
    RANDOM = "Random Concatenation (Recommended)"
    SEQUENTIAL = "Sequential Concatenation (By Download Order)"

class VideoTransitionMode(str, Enum):
    NONE = "None"
    FADE = "Fade"
    CROSS_DISSOLVE = "crossfade" # Corrected for FFmpeg xfade filter
    # Add more as needed, e.g., "slide_left", "slide_right" etc.

class VideoAspect(str, Enum):
    PORTRAIT_9_16 = "Portrait 9:16 (TikTok/Reels)"
    LANDSCAPE_16_9 = "Landscape 16:9 (YouTube/Traditional)"
    SQUARE_1_1 = "Square 1:1 (Instagram/Generic)"

class SpeechSynthesisVoice(str, Enum):
    # Google TTS voices
    EN_US_WAVENET_A = "en-US-Wavenet-A"
    EN_US_WAVENET_B = "en-US-Wavenet-B"
    EN_US_WAVENET_C = "en-US-Wavenet-C"
    EN_US_WAVENET_D = "en-US-Wavenet-D"
    EN_US_WAVENET_E = "en-US-WAVENET-E"
    EN_US_WAVENET_F = "en-US-WAVENET-F"
    EN_US_WAVENET_G = "en-US-WAVENET-G"
    EN_US_WAVENET_H = "en-US-WAVENET-H"
    EN_US_WAVENET_I = "en-US-WAVENET-I"
    EN_US_WAVENET_J = "en-US-WAVENET-J"
    EN_US_WAVENET_K = "en-US-WAVENET-K"
    EN_US_WAVENET_L = "en-US-WAVENET-L"
    EN_US_WAVENET_M = "en-US-WAVENET-M"
    EN_US_WAVENET_N = "en-US-WAVENET-N"
    
    # Add Azure TTS voices if configured
    AZURE_EN_US_CHRISTOPHER = "en-US-ChristopherNeural (Azure)"
    AZURE_EN_US_SARA = "en-US-SaraNeural (Azure)"
    # ... potentially more Azure voices

class SubtitleFont(str, Enum):
    ROBOTO = "Roboto"
    OPENSANS = "OpenSans"
    MONTSERRAT = "Montserrat"
    ARIAL = "Arial" # Generic, often system default
    # Add more if specific font files are provided/installed

class SubtitlePosition(str, Enum):
    BOTTOM_CENTER = "Bottom Center"
    TOP_CENTER = "Top Center"
    MIDDLE_CENTER = "Middle Center"
    BOTTOM_LEFT = "Bottom Left"
    BOTTOM_RIGHT = "Bottom Right"

class VideoLanguage(str, Enum):
    ENGLISH = "English"
    SPANISH = "Spanish"
    FRENCH = "French"
    GERMAN = "German"
    ITALIAN = "Italian"
    # Add more languages as needed

# --- Pydantic Models ---

class VideoParams(BaseModel):
    """
    Defines all parameters for video generation.
    """
    # Video Script Settings
    # Changed from Field(..., ...) to Field("", ...) to provide a default empty string
    video_subject: str = Field("", description="The main topic/subject of the video.")
    video_language: VideoLanguage = Field(VideoLanguage.ENGLISH, description="Language for video script and narration.")

    # Video Source Settings
    video_source_type: VideoSourceType = Field(VideoSourceType.STOCK_FOOTAGE, description="Source of video clips (stock or AI generated images).")
    image_prompt_suffix: Optional[str] = Field(None, description="Suffix to add to image generation prompts if AI generated images are selected.")
    
    # Video Composition Settings
    video_concat_mode: VideoConcatMode = Field(VideoConcatMode.RANDOM, description="How to concatenate video clips.")
    video_transition_mode: VideoTransitionMode = Field(VideoTransitionMode.FADE, description="Type of visual transition between clips.")
    video_aspect_ratio: VideoAspect = Field(VideoAspect.PORTRAIT_9_16, description="Aspect ratio of the final video.")
    max_clip_duration_s: int = Field(10, ge=1, description="Maximum duration (in seconds) for individual source video clips.")
    num_videos_to_source_or_generate: int = Field(5, ge=1, description="Number of source videos to download or images to generate.")
    final_video_duration_s: int = Field(60, ge=15, description="Target duration of the final combined video in seconds.")

    # Audio Settings
    speech_synthesis_voice: SpeechSynthesisVoice = Field(SpeechSynthesisVoice.EN_US_WAVENET_C, description="Voice to use for narration.")

    # Subtitle Settings
    enable_subtitles: bool = Field(True, description="Whether to include burned-in subtitles.")
    subtitle_font: SubtitleFont = Field(SubtitleFont.ROBOTO, description="Font for subtitles.")
    subtitle_position: SubtitlePosition = Field(SubtitlePosition.BOTTOM_CENTER, description="Position of subtitles on the screen.")
    subtitle_font_size: int = Field(50, ge=10, le=100, description="Font size for subtitles.")
    subtitle_color: str = Field("white", description="Color of subtitle text (e.g., 'white', 'yellow', '#RRGGBB').")
    subtitle_outline_color: str = Field("black", description="Color of subtitle outline (e.g., 'black', 'blue').")
    subtitle_outline_width: int = Field(2, ge=0, le=10, description="Width of subtitle outline.")

    # Internal tracking for UI state (not part of the core pipeline logic)
    _last_run_params: Dict[str, Any] = PrivateAttr(default_factory=dict)
