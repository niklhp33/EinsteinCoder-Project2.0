# __init__.py for the new_features package
# This file marks the directory as a Python package.

# You can import and export modules from here as new features are developed
from .dynamic_visual_cues import integrate_visual_cues_from_script
from .intro_outro_templates import apply_intro_outro_template
from .advanced_tts_controls import synthesize_speech_advanced
from .integrated_music_library import search_music_by_mood
from .multilingual_support import translate_script
from .long_form_adaptation import optimize_for_long_form_video
from .niche_content_specialization import get_niche_prompts
from .interactive_content_generation import add_interactive_elements
from .cost_analyzer import CostAnalyzer # NEW IMPORT

__all__ = [
    "integrate_visual_cues_from_script",
    "apply_intro_outro_template",
    "synthesize_speech_advanced",
    "search_music_by_mood",
    "translate_script",
    "optimize_for_long_form_video",
    "get_niche_prompts",
    "add_interactive_elements",
    "CostAnalyzer" # NEW EXPORT
]
