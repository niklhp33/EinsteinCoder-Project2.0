import os
import logging
import uuid
import random
import shutil
from typing import List, Optional, Tuple, Dict, Any

from moviepy.editor import VideoFileClip, AudioFileClip

from ..config import GLOBAL_CONFIG
from ..models import VideoAspect, VideoTransitionMode, SubtitleEntry, SpeechSynthesisVoice, SubtitleFont, SubtitlePosition, VideoSourceType
from ..utils.ffmpeg_utils import (
    concatenate_videos,
    add_audio_to_video,
    add_subtitles_to_video,
    get_video_dimensions,
    run_ffmpeg_command
)
from ..utils.video_utils import (
    search_pexels_videos,
    search_pixabay_videos,
    download_video_clip,
    inject_silent_audio_if_needed,
    get_video_duration
)
from ..utils.audio_utils import (
    download_background_music,
    adjust_audio_volume,
    combine_audio_tracks
)
from ..utils.cleanup import (
    VIDEO_DOWNLOADS_DIR,
    AUDIO_DIR,
    IMAGES_DIR,
    OUTPUT_DIR, # Import OUTPUT_DIR for clear path definition
    TEMP_FILES_DIR,
    LOGS_DIR
)
from ..ai_integration.speech_synthesis import get_audio_duration_ffprobe
from ..ai_integration.image_video_generation import generate_image_from_text, generate_video_from_text, convert_image_to_video

logger = logging.getLogger(__name__)

def generate_unique_filename(prefix: str, extension: str, directory: str) -> str:
    """Generates a unique filename within a specified directory."""
    unique_id = uuid.uuid4().hex
    return os.path.join(directory, f"{prefix}_{unique_id}.{extension}")

class VideoEditor:
    def __init__(self, output_base_dir: str):
        self.output_base_dir = output_base_dir
        self.video_downloads_dir = os.path.join(self.output_base_dir, GLOBAL_CONFIG['paths']['video_downloads_dir'])
        self.audio_dir = os.path.join(self.output_base_dir, GLOBAL_CONFIG['paths']['audio_dir'])
        self.images_dir = os.path.join(self.output_base_dir, GLOBAL_CONFIG['paths']['images_dir'])
        self.output_videos_dir = os.path.join(self.output_base_dir, GLOBAL_CONFIG['paths']['output_dir']) # Use OUTPUT_DIR
        self.temp_files_dir = os.path.join(self.output_base_dir, GLOBAL_CONFIG['paths']['temp_files_dir'])
        self.log_dir = os.path.join(self.output_base_dir, GLOBAL_CONFIG['paths']['logs_dir'])

        # Ensure all working directories exist upon editor instantiation
        os.makedirs(self.video_downloads_dir, exist_ok=True)
        os.makedirs(self.audio_dir, exist_ok=True)
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.output_videos_dir, exist_ok=True) # Ensure this is created
        os.makedirs(self.temp_files_dir, exist_ok=True)
        os.makedirs(self.log_dir, exist_ok=True)
        logger.info(f"VideoEditor initialized. Working directories under: {self.output_base_dir}")

    def source_visual_assets(
        self,
        query: str,
        video_source_type: VideoSourceType,
        num_assets: int,
        max_clip_duration_s: int,
        target_aspect_ratio: VideoAspect,
        image_prompt_suffix: Optional[str] = None
    ) -> List[str]:
        """
        Sources video clips or generates images/videos based on the specified type.
        """
        logger.info(f"Sourcing {num_assets} visual assets for '{query}' from {video_source_type.value}.")
        sourced_asset_paths = []
        
        pexels_orientation = 'portrait'
        pixabay_orientation = 'vertical'
        target_img_res = "1024x1792"
        if target_aspect_ratio == VideoAspect.LANDSCAPE_16_9:
            pexels_orientation = 'landscape'
            pixabay_orientation = 'horizontal'
            target_img_res = "1792x1024"
        elif target_aspect_ratio == VideoAspect.SQUARE_1_1:
            pexels_orientation = 'square'
            pixabay_orientation = 'all'
            target_img_res = "1024x1024"

        if video_source_type == VideoSourceType.STOCK_FOOTAGE:
            pexels_videos = search_pexels_videos(
                query=query,
                orientation=pexels_orientation,
                per_page=num_assets * 2,
                min_duration_s=5,
                max_duration_s=max_clip_duration_s
            )
            pixabay_videos = search_pixabay_videos(
                query=query,
                orientation=pixabay_orientation,
                per_page=num_assets * 2,
                min_duration_s=5,
                max_duration_s=max_clip_duration_s
            )
            
            all_found_videos = pexels_videos + pixabay_videos
            random.shuffle(all_found_videos)
            
            downloaded_count = 0
            for video_info in all_found_videos:
                if downloaded_count >= num_assets:
                    break
                
                download_link = video_info.get('download_link')
                if download_link:
                    downloaded_clip_path = download_video_clip(download_link, self.video_downloads_dir, "downloaded_clip")
                    
                    if downloaded_clip_path:
                        duration = get_video_duration(downloaded_clip_path)
                        if duration is None:
                            logger.warning(f"Could not get duration for downloaded clip: {downloaded_clip_path}. Skipping.")
                            os.remove(downloaded_clip_path)
                            continue

                        if duration > max_clip_duration_s + 2:
                            logger.info(f"Trimming clip {os.path.basename(downloaded_clip_path)} from {duration:.2f}s to {max_clip_duration_s}s.")
                            trimmed_path = generate_unique_filename("trimmed_clip", "mp4", self.temp_files_dir)
                            trim_cmd = [
                                '-i', downloaded_clip_path,
                                '-ss', '0',
                                '-t', str(max_clip_duration_s),
                                '-c', 'copy',
                                trimmed_path
                            ]
                            stdout, stderr, returncode = run_ffmpeg_command(trim_cmd, check_error=False, timeout=60)
                            if returncode != 0:
                                logger.error(f"Failed to trim video {downloaded_clip_path}: {stderr}. Using original clip.")
                                trimmed_path = downloaded_clip_path
                            else:
                                os.remove(downloaded_clip_path)
                                downloaded_clip_path = trimmed_path
                                duration = get_video_duration(downloaded_clip_path)

                        clip_with_audio_path = generate_unique_filename("clip_with_audio", "mp4", self.temp_files_dir)
                        final_clip_path = inject_silent_audio_if_needed(downloaded_clip_path, clip_with_audio_path, duration)
                        
                        if final_clip_path:
                            if final_clip_path != downloaded_clip_path and os.path.exists(downloaded_clip_path):
                                os.remove(downloaded_clip_path)
                            sourced_asset_paths.append(final_clip_path)
                            downloaded_count += 1
                        else:
                            logger.warning(f"Failed to ensure audio for clip: {downloaded_clip_path}. Skipping.")
                            if os.path.exists(downloaded_clip_path):
                                os.remove(downloaded_clip_path)
                else:
                    logger.warning(f"No download link found for a video entry from search.")

            if downloaded_count < num_assets:
                logger.warning(f"Only sourced {downloaded_count} out of {num_assets} requested videos from stock. "
                               "Consider broadening your search query or increasing 'max_clip_duration_s'.")

        elif video_source_type == VideoSourceType.AI_GENERATED_IMAGES:
            logger.info("Generating images using AI...")
            combined_prompt = f"{query}. {image_prompt_suffix if image_prompt_suffix else ''}".strip()
            
            generated_images = generate_image_from_text(
                prompt=combined_prompt,
                output_dir=self.images_dir,
                image_size=target_img_res,
                num_images=num_assets
            )
            
            if generated_images:
                for img_path in generated_images:
                    video_from_image_path = generate_unique_filename("img_to_video", "mp4", self.temp_files_dir)
                    clip_duration = min(max_clip_duration_s, GLOBAL_CONFIG['video_settings']['default_max_clip_duration_s']) 
                    
                    converted_video_path = convert_image_to_video(
                        img_path, video_from_image_path, duration_s=clip_duration
                    )
                    if converted_video_path:
                        final_clip_path_with_audio = generate_unique_filename("img_vid_with_audio", "mp4", self.temp_files_dir)
                        final_converted_path = inject_silent_audio_if_needed(converted_video_path, final_clip_path_with_audio, clip_duration)
                        if final_converted_path:
                            sourced_asset_paths.append(final_converted_path)
                            if os.path.exists(converted_video_path):
                                os.remove(converted_video_path)
                            if final_converted_path != video_from_image_path and os.path.exists(video_from_image_path):
                                os.remove(video_from_image_path)
                        else:
                             logger.warning(f"Failed to add silent audio to generated image video: {converted_video_path}. Skipping.")
                             if os.path.exists(converted_video_path): os.remove(converted_video_path)

            if not sourced_asset_paths:
                logger.warning(f"No AI generated images successfully converted to videos for query: {query}")

        elif video_source_type == VideoSourceType.AI_GENERATED_VIDEOS:
            logger.info("Generating videos using AI (Text-to-Video)...")
            combined_prompt = f"{query}. {image_prompt_suffix if image_prompt_suffix else ''}".strip()
            
            generated_videos = generate_video_from_text(
                prompt=combined_prompt,
                output_dir=self.video_downloads_dir,
                duration_s=max_clip_duration_s,
                resolution=target_img_res
            )

            if generated_videos:
                for video_path in generated_videos:
                    duration = get_video_duration(video_path)
                    if duration is None:
                        logger.warning(f"Could not get duration for generated video: {video_path}. Skipping.")
                        os.remove(video_path)
                        continue
                    
                    final_clip_path_with_audio = generate_unique_filename("gen_vid_with_audio", "mp4", self.temp_files_dir)
                    final_generated_path = inject_silent_audio_if_needed(video_path, final_clip_path_with_audio, duration)
                    if final_generated_path:
                        sourced_asset_paths.append(final_generated_path)
                        if final_generated_path != video_path and os.path.exists(video_path):
                            os.remove(video_path)
                    else:
                        logger.warning(f"Failed to ensure audio for generated video: {video_path}. Skipping.")
                        if os.path.exists(video_path): os.remove(video_path)
            
            if not sourced_asset_paths:
                logger.warning(f"No AI generated videos successfully sourced for query: {query}")

        else:
            logger.error(f"Unknown video source type: {video_source_type.value}")
        
        logger.info(f"Successfully sourced/generated {len(sourced_asset_paths)} visual assets.")
        return sourced_asset_paths

    def assemble_base_video(
        self,
        video_clip_paths: List[str],
        final_video_duration_s: int,
        target_aspect_ratio: VideoAspect,
        concat_mode: VideoConcatMode,
        transition_mode: VideoTransitionMode,
        transition_duration: float = 0.5
    ) -> Optional[str]:
        """
        Assembles a base video from individual clips, applying concatenation logic and transitions.
        """
        if not video_clip_paths:
            logger.error("No video clips provided for assembly.")
            return None

        logger.info(f"Assembling base video from {len(video_clip_paths)} clips.")
        
        clips_to_use = list(video_clip_paths)

        if concat_mode == VideoConcatMode.RANDOM:
            random.shuffle(clips_to_use)
            logger.info("Randomizing clip order for concatenation.")
        
        # Use temp_files_dir for base video as it's an intermediate step
        output_base_video_path = generate_unique_filename("base_video", "mp4", self.temp_files_dir) 
        
        success = concatenate_videos(
            input_video_paths=clips_to_use,
            output_path=output_base_video_path,
            target_aspect_ratio=target_aspect_ratio,
            transition_mode=transition_mode,
            transition_duration=transition_duration,
            max_duration_s=final_video_duration_s
        )

        if not success:
            logger.error("Failed to assemble base video.")
            return None

        logger.info(f"Base video assembled: {output_base_video_path}")
        return output_base_video_path

    def add_narration_and_music(
        self,
        base_video_path: str,
        narration_audio_path: str,
        background_music_query: str = GLOBAL_CONFIG['audio_settings']['default_background_music_query'],
        background_music_volume_db: int = GLOBAL_CONFIG['audio_settings']['default_background_music_volume']
    ) -> Optional[str]:
        """
        Adds narration and background music to the base video.
        """
        logger.info(f"Adding narration and music to video: {base_video_path}")

        if not os.path.exists(base_video_path):
            logger.error(f"Base video file not found: {base_video_path}")
            return None
        if not os.path.exists(narration_audio_path):
            logger.error(f"Narration audio file not found: {narration_audio_path}")
            return None

        narration_duration_estimate = get_audio_duration_ffprobe(narration_audio_path)
        if narration_duration_estimate is None:
            logger.warning("Could not get exact narration duration, using default 60s for background music sourcing.")
            narration_duration_estimate = 60

        background_music_path = download_background_music(
            query=background_music_query,
            output_dir=self.audio_dir,
            duration_s=int(narration_duration_estimate) + 10
        )
        
        combined_audio_path = generate_unique_filename("combined_audio", "mp3", self.temp_files_dir)
        
        audio_combined_success = combine_audio_tracks(
            narration_path=narration_audio_path,
            background_music_path=background_music_path,
            output_path=combined_audio_path,
            background_music_volume_db=background_music_volume_db
        )

        if not audio_combined_success:
            logger.error("Failed to combine narration and background music.")
            return None

        # This will be the output from this step, still in temp_files for further processing
        output_video_with_audio_path = generate_unique_filename("video_with_audio", "mp4", self.temp_files_dir)

        video_audio_merge_success = add_audio_to_video(
            video_path=base_video_path,
            audio_path=combined_audio_path,
            output_path=output_video_with_audio_path,
            start_offset_s=0,
            audio_volume_db=0
        )

        if not video_audio_merge_success:
            logger.error("Failed to merge combined audio into video.")
            return None

        logger.info(f"Narration and music added. Video with audio at: {output_video_with_audio_path}")
        
        if os.path.exists(combined_audio_path):
            os.remove(combined_audio_path)

        return output_video_with_audio_path

    def add_subtitles(
        self,
        video_path: str,
        subtitle_entries: List[SubtitleEntry],
        font_path: str,
        font_size: int,
        font_color: str,
        outline_color: str,
        outline_width: int,
        position: SubtitlePosition
    ) -> Optional[str]:
        """
        Adds burned-in subtitles to the video.
        """
        if not subtitle_entries:
            logger.info("No subtitle entries provided. Skipping subtitle addition.")
            return video_path

        logger.info(f"Adding subtitles to video: {video_path}")
        # Output to temp_files_dir as it's an intermediate step
        output_video_with_subtitles_path = generate_unique_filename("video_with_subtitles", "mp4", self.temp_files_dir)
        
        success = add_subtitles_to_video(
            video_path=video_path,
            subtitle_entries=subtitle_entries,
            output_path=output_video_with_subtitles_path,
            font_path=font_path,
            font_size=font_size,
            font_color=font_color,
            outline_color=outline_color,
            outline_width=outline_width,
            position=position
        )

        if not success:
            logger.error("Failed to add subtitles to video.")
            return None
        
        logger.info(f"Subtitles added: {output_video_with_subtitles_path}")
        return output_video_with_subtitles_path

    def finalize_video(self, input_video_path: str, output_filename: str) -> Optional[str]:
        """
        Copies the final processed video from the temporary directory to the
        main output directory.
        """
        final_output_path = os.path.join(self.output_videos_dir, output_filename) # Use output_videos_dir
        logger.info(f"Attempting to finalize video: Copying from '{input_video_path}' to '{final_output_path}'")
        
        if not os.path.exists(input_video_path):
            logger.error(f"Input video for finalization not found: {input_video_path}. Cannot finalize.")
            return None

        try:
            # Ensure target directory exists (redundant with __init__ but safe)
            os.makedirs(os.path.dirname(final_output_path), exist_ok=True)
            
            shutil.copyfile(input_video_path, final_output_path)
            
            if os.path.exists(final_output_path):
                logger.info(f"Video finalized and saved to: {final_output_path}")
                logger.info(f"Size of final video: {os.path.getsize(final_output_path) / (1024*1024):.2f} MB")
                return final_output_path
            else:
                logger.error(f"Final video file not found at expected path after copy: {final_output_path}")
                return None
        except Exception as e:
            logger.error(f"Error finalizing video to {final_output_path}: {e}", exc_info=True)
            return None
