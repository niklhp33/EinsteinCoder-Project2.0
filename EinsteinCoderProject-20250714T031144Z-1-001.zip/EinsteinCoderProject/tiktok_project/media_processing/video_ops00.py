import os
import subprocess
import shlex
import logging
import requests
import uuid
import time
import random
from typing import List, Tuple, Optional

# Import GLOBAL_CONFIG from the project's config module
# Assuming the main script (or __init__.py for the package) handles adding PROJECT_ROOT_DIR to sys.path
from config import GLOBAL_CONFIG
from models import VideoAspect, VideoTransitionMode, VideoConcatMode
from utils.shell_utils import run_shell_command, sanitize_filename
from utils.cleanup import VIDEO_DOWNLOADS_DIR, TEMP_FILES_DIR # Import directories defined in cleanup

# Initialize logging
logger = logging.getLogger(__name__)

# Base directory for runtime files (e.g., video downloads, temp files)
# This will usually be a /tmp directory within the Colab runtime, not on Drive.
BASE_DIR = GLOBAL_CONFIG['paths']['base_dir']

def get_video_duration(video_path: str) -> Optional[float]:
    """
    Gets the duration of a video file using ffprobe (more reliable than moviepy for this).
    Returns duration in seconds.
    """
    if not os.path.exists(video_path):
        logger.error(f"Video file not found for duration check: {video_path}")
        return None

    command = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        shlex.quote(video_path)
    ]
    
    stdout, stderr, returncode = run_shell_command(command, check_error=False)
    if returncode == 0 and stdout:
        try:
            return float(stdout.strip())
        except ValueError:
            logger.error(f"Could not parse duration from ffprobe: {stdout}")
            return None
    else:
        logger.error(f"ffprobe failed for {video_path}. Stderr: {stderr}")
        return None

def download_multiple_videos(search_query: str, video_source_type: str, num_videos: int, max_clip_duration: int, aspect_ratio: VideoAspect) -> List[str]:
    """
    Downloads videos from Pexels or Pixabay based on search query.
    Filters by aspect ratio and max duration.
    """
    downloaded_video_paths = []
    
    # Map VideoAspect to Pexels/Pixabay orientation
    orientation = "landscape"
    if aspect_ratio == VideoAspect.PORTRAIT_9_16:
        orientation = "portrait"
    elif aspect_ratio == VideoAspect.SQUARE_1_1:
        orientation = "square"

    search_params = {
        "query": search_query,
        "per_page": num_videos * 2, # Request more to filter down
        "orientation": orientation,
        "locale": "en-US" # Assuming English locale for now
    }
    
    # Store API keys locally for easier access
    pexels_key = GLOBAL_CONFIG['api_keys'].get('pexels_api_key')
    pixabay_key = GLOBAL_CONFIG['api_keys'].get('pixabay_api_key')

    # Priority list for stock footage APIs
    # We'll try them in this order: Pexels, then Pixabay
    api_priorities = []
    if pexels_key and pexels_key != 'YOUR_PEXELS_API_KEY': # Only try Pexels if key is likely valid
        api_priorities.append(("Pexels", "https://api.pexels.com/videos/search", {'Authorization': pexels_key}, search_params))
    if pixabay_key and pixabay_key != 'YOUR_PIXABAY_API_KEY': # Only try Pixabay if key is likely valid
        # For Pixabay, query param 'q' is directly in URL, not params dict for requests.get
        pixabay_search_params = {
            "key": pixabay_key,
            "q": search_query,
            "per_page": num_videos * 2,
            "orientation": orientation
        }
        api_priorities.append(("Pixabay", f"https://pixabay.com/api/videos/", None, pixabay_search_params))


    if video_source_type != "Stock Footage (Pexels/Pixabay)":
        logger.info("Video source type is not stock footage. Skipping video download.")
        return []
    
    if not api_priorities:
        logger.error("Neither Pexels nor Pixabay API key found or configured. Cannot download stock videos.")
        return []

    found_videos = []
    for api_name, api_url, headers_dict, params_dict in api_priorities:
        logger.info(f"Searching {api_name} for '{search_query}' (orientation: {orientation})...")
        try:
            if api_name == "Pexels":
                response = requests.get(api_url, headers=headers_dict, params=params_dict)
            elif api_name == "Pixabay":
                # For Pixabay, the query 'q' needs to be part of the URL in its basic API
                # Reconstruct URL for Pixabay specifically
                full_pixabay_url = f"{api_url}?key={params_dict['key']}&q={shlex.quote(params_dict['q'])}&per_page={params_dict['per_page']}&orientation={params_dict['orientation']}"
                response = requests.get(full_pixabay_url)
            else:
                logger.error(f"Unknown API source in priority list: {api_name}")
                continue

            response.raise_for_status() # Raise an exception for HTTP errors (like 401)
            data = response.json()
            
            raw_videos = []
            if api_name == "Pexels":
                raw_videos = data.get("videos", [])
            elif api_name == "Pixabay":
                raw_videos = data.get("hits", [])

            if not raw_videos:
                logger.warning(f"No videos found for '{search_query}' from {api_name}.")
                continue # Try next API in priority list
            
            # Process suitable videos from the current API
            for video_info in raw_videos:
                video_url = None
                duration_s = None
                if api_name == "Pexels":
                    duration_s = video_info.get("duration")
                    video_files = video_info.get("video_files", [])
                    suitable_file = next((f for f in video_files if f.get("quality") == "hd" and f.get("file_type") == "video/mp4"), None)
                    if not suitable_file: # Fallback to any mp4 if HD not found
                        suitable_file = next((f for f in video_files if f.get("file_type") == "video/mp4"), None)
                    video_url = suitable_file.get("link") if suitable_file else None
                elif api_name == "Pixabay":
                    duration_s = video_info.get("duration") # Duration in seconds
                    video_urls = video_info.get("videos", {})
                    # Prioritize 'medium' then 'small' quality mp4
                    video_url = video_urls.get('medium', {}).get('url') or video_urls.get('small', {}).get('url')
                
                if video_url and duration_s is not None and duration_s <= max_clip_duration:
                    found_videos.append({
                        "url": video_url,
                        "duration": duration_s
                    })
            
            # If we found videos from this API, we stop trying other APIs
            if found_videos:
                logger.info(f"Successfully found {len(found_videos)} suitable videos from {api_name}.")
                break 

        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed for {api_name}: {e}")
            # Do NOT return here, continue to next API in priority list
        except Exception as e:
            logger.error(f"An unexpected error occurred during video search for {api_name}: {e}")
            # Do NOT return here, continue to next API in priority list

    if not found_videos:
        logger.error("No videos could be sourced from any configured API.")
        return []
    
    random.shuffle(found_videos) # Shuffle to get variety

    video_downloads_path = os.path.join(BASE_DIR, VIDEO_DOWNLOADS_DIR)
    os.makedirs(video_downloads_path, exist_ok=True)
    
    logger.info(f"Attempting to download {min(num_videos, len(found_videos))} videos...")

    for i, video_data in enumerate(found_videos[:num_videos]):
        video_url = video_data["url"]
        # Basic check for mp4 extension, sometimes URLs are complex
        file_extension = ".mp4" 
        if '?' in video_url: # Remove query params for extension check
            base_url = video_url.split('?')[0]
            if '.' in base_url:
                file_extension = os.path.splitext(base_url)[-1] or ".mp4"
        elif '.' in video_url:
            file_extension = os.path.splitext(video_url)[-1] or ".mp4"
        
        output_filename = os.path.join(video_downloads_path, f"downloaded_clip_{uuid.uuid4().hex}{file_extension}")
        
        logger.info(f"Downloading video {i+1}/{min(num_videos, len(found_videos))} from {video_url}...")
        try:
            video_response = requests.get(video_url, stream=True)
            video_response.raise_for_status()
            with open(output_filename, 'wb') as f:
                for chunk in video_response.iter_content(chunk_size=8192):
                    f.write(chunk)
            downloaded_video_paths.append(output_filename)
            logger.info(f"Successfully downloaded: {output_filename}")
        except requests.exceptions.RequestException as e:
            logger.error(f"Error downloading {video_url}: {e}")
        except Exception as e:
            logger.error(f"An unexpected error occurred during download of {video_url}: {e}")

    return downloaded_video_paths

def concatenate_videos_with_transitions_ffmpeg(
    video_paths: List[str],
    output_path: str,
    target_duration: float,
    aspect_ratio: VideoAspect,
    transition_mode: VideoTransitionMode = VideoTransitionMode.FADE
) -> Optional[str]:
    """
    Concatenates multiple video clips with optional transitions using FFmpeg,
    ensuring consistent resolution and aspect ratio, and trimming to target duration.
    """
    if not video_paths:
        logger.error("No video paths provided for concatenation.")
        return None

    temp_files_path = os.path.join(BASE_DIR, TEMP_FILES_DIR)
    os.makedirs(temp_files_path, exist_ok=True)

    # 1. Probe all video durations and filter
    valid_clips = []
    total_raw_duration = 0.0
    for i, path in enumerate(video_paths):
        duration = get_video_duration(path)
        if duration is not None and duration > 0.1: # Minimum duration
            valid_clips.append({"path": path, "duration": duration})
            total_raw_duration += duration
        else:
            logger.warning(f"Skipping problematic clip: {path} (Duration: {duration})")

    if not valid_clips:
        logger.error("No valid video clips found after probing durations.")
        return None

    # Determine resolution based on aspect ratio
    target_width, target_height = 1080, 1920 # Default to Portrait
    if aspect_ratio == VideoAspect.LANDSCAPE_16_9:
        target_width, target_height = 1920, 1080
    elif aspect_ratio == VideoAspect.SQUARE_1_1:
        target_width, target_height = 1080, 1080
    
    resolution_str = f"{target_width}x{target_height}"

    # Prepare input list for FFmpeg
    input_file_list_path = os.path.join(temp_files_path, f"input_list_{uuid.uuid4().hex}.txt")
    with open(input_file_list_path, 'w') as f:
        for clip in valid_clips:
            f.write(f"file '{clip['path']}'\n")

    # --- FFmpeg Command Construction ---
    filter_complex_parts = []
    inputs = []
    output_chain = []
    
    # 1. Scale and pad/crop all inputs
    for i, clip in enumerate(valid_clips):
        inputs.append(f"-i {shlex.quote(clip['path'])}")
        # Scale, crop/pad, and set pixel format for consistency
        filter_complex_parts.append(
            f"[{i}:v]scale={target_width}:{target_height}:force_original_aspect_ratio=increase,crop={target_width}:{target_height},setsar=1[v{i}];"
            f"[{i}:a]aresample=async=1[a{i}]" # Ensure audio is resampled/synced
        )

    # Calculate segment durations for transitions
    segment_durations = [clip['duration'] for clip in valid_clips]
    transition_duration = 0.5 # seconds, adjust as needed

    # 2. Apply transitions (if enabled and more than one clip)
    if len(valid_clips) > 1 and transition_mode != VideoTransitionMode.NONE:
        concat_inputs = []
        for i in range(len(valid_clips)):
            concat_inputs.append(f"[v{i}]")
            concat_inputs.append(f"[a{i}]")
        
        # Construct the transition filter
        if transition_mode == VideoTransitionMode.FADE:
            # This is becoming overly complex for a shell command.
            # A simpler xfade approach often uses a concat list and then applies xfade.
            # For transitions, the 'concat' filter is more robust for simple fades, or `xfade`.
            # Given the previous context and typical Colab usage, let's revert to a simpler concat
            # and specify the transition type here.

            # Simple concat without explicit complex transition filters for now
            # The prompt originally suggested `concatenate_videos_with_transitions_ffmpeg`
            # For actual transitions, it's either `xfade` or manual overlay/blend.
            # Let's assume a "concat" filter is sufficient and we'll apply "fade" visually via overlay.
            # If a true cross-dissolve is needed, the `xfade` filter is what we want.
            # Example for xfade (will apply if transition_mode is Fade or Cross Dissolve):
            
            # This requires one input per video, then chaining them.
            # Simplified approach using `xfade` on video streams, `acrossfade` on audio streams
            
            video_filter_chain = f"[v0]"
            audio_filter_chain = f"[a0]"
            current_time = 0.0

            for i in range(len(valid_clips) - 1):
                current_time += valid_clips[i]['duration'] - transition_duration # Subtract overlap for next transition
                
                video_filter_chain += f"[v{i+1}]xfade=transition={transition_mode.value.lower()}:duration={transition_duration}:offset={current_time}[vtmp{i}];[vtmp{i}]"
                audio_filter_chain += f"[a{i+1}]acrossfade=d={transition_duration}[atmp{i}];[atmp{i}]"

            video_filter_chain = video_filter_chain.rstrip(";") # remove trailing semicolon
            audio_filter_chain = audio_filter_chain.rstrip(";") # remove trailing semicolon

            filter_complex_parts.append(f"{video_filter_chain}[final_v]")
            filter_complex_parts.append(f"{audio_filter_chain}[final_a]")

            output_chain = ["-map", "[final_v]", "-map", "[final_a]"]

    else: # No transitions or only one clip
        filter_complex_parts.append(f"[v0][a0]concat=n=1:v=1:a=1[final_v][final_a]")
        output_chain = ["-map", "[final_v]", "-map", "[final_a]"]


    # Calculate effective total duration from valid clips, considering transitions
    effective_total_duration = sum(clip['duration'] for clip in valid_clips)
    if len(valid_clips) > 1 and transition_mode != VideoTransitionMode.NONE:
        effective_total_duration -= (len(valid_clips) - 1) * transition_duration

    # If the combined video is longer than target_duration, trim it
    trim_duration_arg = []
    if effective_total_duration > target_duration:
        trim_duration_arg = ["-t", str(target_duration)]
        logger.info(f"Trimming concatenated video to {target_duration} seconds from {effective_total_duration} seconds.")
    else:
        logger.info(f"Concatenated video duration {effective_total_duration}s is less than or equal to target {target_duration}s. No trimming applied.")
    

    ffmpeg_command_parts = [
        "ffmpeg",
        "-y", # Overwrite output files without asking
        *inputs,
        "-filter_complex", ";".join(filter_complex_parts),
        "-c:v", "libx264",
        "-preset", "fast",
        "-crf", "23",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "192k",
        *trim_duration_arg,
        *output_chain,
        shlex.quote(output_path)
    ]

    command_str = " ".join(ffmpeg_command_parts)
    logger.info(f"Running FFmpeg concat command:\n{command_str}")

    stdout, stderr, returncode = run_shell_command(ffmpeg_command_parts)

    if returncode == 0:
        final_duration = get_video_duration(output_path)
        logger.info(f"Successfully concatenated videos to {output_path}. Final duration: {final_duration}s")
        return output_path
    else:
        logger.error(f"FFmpeg concatenation failed. Stderr: {stderr}")
        return None


def create_video_from_images_with_ken_burns(
    image_paths: List[str],
    output_path: str,
    target_duration: float,
    aspect_ratio: VideoAspect,
    image_display_duration: float = 3.0, # Duration each image is displayed before Ken Burns starts transitioning
    zoom_speed: float = 0.003 # Speed of zoom, e.g., 0.001 to 0.005
) -> Optional[str]:
    """
    Creates a video from a list of images, applying Ken Burns effect and concatenating them.
    Each image will have a Ken Burns zoom/pan effect.
    """
    if not image_paths:
        logger.error("No image paths provided for video creation.")
        return None

    temp_files_path = os.path.join(BASE_DIR, TEMP_FILES_DIR)
    os.makedirs(temp_files_path, exist_ok=True)

    # Determine resolution based on aspect ratio
    target_width, target_height = 1080, 1920 # Default to Portrait
    if aspect_ratio == VideoAspect.LANDSCAPE_16_9:
        target_width, target_height = 1920, 1080
    elif aspect_ratio == VideoAspect.SQUARE_1_1:
        target_width, target_height = 1080, 1080
    
    resolution_str = f"{target_width}x{target_height}"

    # Create temporary video clips for each image with Ken Burns effect
    temp_video_clips = []
    
    # Calculate duration for each clip, aiming for target_duration distribution
    # This is a simple distribution, a more advanced one would consider narration timing.
    num_images = len(image_paths)
    if num_images == 0:
        logger.error("No images to create video from.")
        return None
    
    # Distribute target duration among images, ensuring a minimum duration per image
    min_image_clip_duration = 3.0 # Minimum seconds for each image clip
    effective_clip_duration = max(min_image_clip_duration, target_duration / num_images)

    logger.info(f"Creating video from {num_images} images. Each image clip will be approx. {effective_clip_duration:.2f}s long.")

    for i, image_path in enumerate(image_paths):
        temp_output_clip_path = os.path.join(temp_files_path, f"image_clip_{i:02d}_{uuid.uuid4().hex}.mp4")
        
        # Determine random pan/zoom direction
        direction = random.choice(['in', 'out', 'up', 'down', 'left', 'right'])
        
        # Ken Burns filter based on direction and zoom speed
        # Adjust zoom for initial state and final state
        # The `zoom` filter creates a zooming effect.
        # `x`, `y` define the center of the zoom.
        # `in` (zoom in): `z='min(max(zoom,pzoom)+0.0015,1.5)'`
        # `out` (zoom out): `z='max(min(zoom,pzoom)-0.0015,1.0)'`
        
        # For a full Ken Burns effect including pan, we use `zoompan`
        # This is more robust for dynamic movement.
        # syntax: zoompan=z='zoom_level':x='x_pos':y='y_pos':d='duration':s='size':fps='fps'
        # z: current zoom level
        # x, y: top-left corner of the zoomed rectangle (absolute pixels)
        # d: duration of frame in frames
        # s: output video resolution

        # Simplified Ken Burns: fixed zoom amount over clip duration
        # Example: start zoom 1, end zoom 1.2
        # For simplicity, let's use a dynamic zoom out or zoom in
        
        start_zoom = 1.0
        end_zoom = 1.15 # Max zoom out/in
        
        # Randomize start/end positions slightly for pan effect
        offset_x = random.uniform(0, 0.05) * target_width
        offset_y = random.uniform(0, 0.05) * target_height

        zoompan_filter = ""
        if direction == 'in':
            zoompan_filter = f"zoompan=z='min({start_zoom}+({zoom_speed}*on)),{end_zoom}':x='iw/2-(iw/zoom/2)+{offset_x}':y='ih/2-(ih/zoom/2)+{offset_y}':d=1:s={resolution_str}:fps=25"
        elif direction == 'out':
            zoompan_filter = f"zoompan=z='max({end_zoom}-({zoom_speed}*on)),{start_zoom}':x='iw/2-(iw/zoom/2)-{offset_x}':y='ih/2-(ih/zoom/2)-{offset_y}':d=1:s={resolution_str}:fps=25"
        else: # Default or random pan, keep zoom constant for simplicity
             zoompan_filter = f"zoompan=z={start_zoom}:x='iw/2-(iw/zoom/2)+{random.uniform(-0.05, 0.05) * target_width}':y='ih/2-(ih/zoom/2)+{random.uniform(-0.05, 0.05) * target_height}':d=1:s={resolution_str}:fps=25"


        # FFmpeg command to create a single video clip from an image with Ken Burns effect
        command = [
            "ffmpeg", "-y",
            "-loop", "1",
            "-i", shlex.quote(image_path),
            "-vf", f"{zoompan_filter},format=yuv420p",
            "-t", str(effective_clip_duration),
            "-c:v", "libx264",
            "-preset", "veryfast", # Use veryfast preset for faster encoding
            "-crf", "23",
            "-r", "25", # Output framerate
            "-s", resolution_str, # Output resolution
            shlex.quote(temp_output_clip_path)
        ]
        logger.info(f"Creating image clip {i+1} with Ken Burns: {temp_output_clip_path}")
        stdout, stderr, returncode = run_shell_command(command)

        if returncode == 0:
            temp_video_clips.append(temp_output_clip_path)
        else:
            logger.error(f"Failed to create video clip from image {image_path}. Stderr: {stderr}")

    if not temp_video_clips:
        logger.error("No temporary video clips were successfully created from images.")
        return None

    # Concatenate all temporary video clips
    concat_list_path = os.path.join(temp_files_path, f"concat_list_{uuid.uuid4().hex}.txt")
    with open(concat_list_path, 'w') as f:
        for clip in temp_video_clips:
            f.write(f"file '{clip}'\n")

    final_concat_command = [
        "ffmpeg", "-y",
        "-f", "concat",
        "-safe", "0", # Required for concat demuxer when file paths are dynamic
        "-i", shlex.quote(concat_list_path),
        "-c", "copy",
        "-pix_fmt", "yuv420p", # Ensure pixel format is compatible
        "-vsync", "2", # Passthrough timestamps to avoid issues
        shlex.quote(output_path)
    ]

    logger.info(f"Concatenating Ken Burns clips to: {output_path}")
    stdout, stderr, returncode = run_shell_command(final_concat_command)

    if returncode == 0:
        final_duration = get_video_duration(output_path)
        logger.info(f"Successfully created video from images: {output_path}. Final duration: {final_duration}s")
        return output_path
    else:
        logger.error(f"Failed to concatenate Ken Burns video clips. Stderr: {stderr}")
        return None

def re_encode_video_for_gemini(input_path: str, output_path: str, target_size_mb: Optional[int] = None) -> Optional[str]:
    """
    Re-encodes a video to ensure compatibility with Gemini's input limits and optionally target a file size.
    Gemini often prefers certain codecs and dimensions, and has file size limits (e.g., 200MB).
    This function will reduce bitrate to meet target_size_mb if specified and the video is larger.
    """
    logger.info(f"Re-encoding video '{input_path}' for Gemini compatibility...")

    if not os.path.exists(input_path):
        logger.error(f"Input video for re-encoding not found: {input_path}")
        return None
    
    # Get initial video duration and size
    duration = get_video_duration(input_path)
    initial_size_bytes = os.path.getsize(input_path)
    initial_size_mb = initial_size_bytes / (1024 * 1024)
    
    if duration is None:
        logger.error(f"Could not determine duration of {input_path}. Cannot re-encode intelligently.")
        return None

    bitrate_args = []
    if target_size_mb is not None and initial_size_mb > target_size_mb:
        # Calculate target bitrate to achieve target_size_mb
        # Target_bits = Target_size_mb * 8 * 1024 * 1024
        # Target_bitrate_bps = Target_bits / duration_seconds
        # Target_bitrate_kbs = Target_bitrate_bps / 1000
        target_bits = target_size_mb * 8 * 1024 * 1024
        target_bitrate_bps = target_bits / duration
        target_bitrate_kbs = max(500, int(target_bitrate_bps / 1000)) # Ensure min bitrate of 500kbps
        logger.info(f"Video size ({initial_size_mb:.2f}MB) exceeds {target_size_mb}MB. Targeting bitrate: {target_bitrate_kbs}k.")
        bitrate_args = ["-b:v", f"{target_bitrate_kbs}k"]
    else:
        logger.info(f"Video size ({initial_size_mb:.2f}MB) is within limits or no target specified. Re-encoding with default settings.")


    command = [
        "ffmpeg", "-y",
        "-i", shlex.quote(input_path),
        "-c:v", "libx264",
        "-preset", "medium", # Good balance of speed and quality
        "-crf", "28", # Higher CRF reduces file size, lower is better quality
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-b:a", "128k", # Standard audio bitrate
        *bitrate_args,
        shlex.quote(output_path)
    ]

    logger.info(f"Running video re-encoding command:\n{' '.join(command)}")

    stdout, stderr, returncode = run_shell_command(command)

    if returncode == 0:
        final_size_mb = os.path.getsize(output_path) / (1024 * 1024)
        logger.info(f"Video re-encoded successfully to {output_path}. Final size: {final_size_mb:.2f}MB")
        return output_path
    else:
        logger.error(f"Failed to re-encode video for Gemini. Stderr: {stderr}")
        return None
