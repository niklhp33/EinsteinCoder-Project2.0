import os
import subprocess
import logging
import shlex
import requests
import uuid
import time
import random
from typing import List, Optional, Dict, Any

# Import GLOBAL_CONFIG from the project's config module
from config import GLOBAL_CONFIG
from models import VideoAspect, VideoTransitionMode # Import necessary Enums
from utils.shell_utils import run_shell_command, sanitize_filename # Import utilities
from utils.cleanup import VIDEO_DOWNLOADS_DIR, TEMP_FILES_DIR # Import directories defined in cleanup

# Initialize logging
logger = logging.getLogger(__name__)

# Base directory for runtime files (e.g., temp files)
BASE_DIR = GLOBAL_CONFIG['paths']['base_dir']


def get_video_duration(video_path: str) -> Optional[float]:
    """
    Gets video duration using ffprobe (more reliable than moviepy for this).
    """
    command = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1",
        shlex.quote(video_path)
    ]
    stdout, stderr, returncode = run_shell_command(command, check_error=False)
    if returncode == 0:
        try:
            return float(stdout.strip())
        except ValueError:
            logger.error(f"Could not parse duration from ffprobe: {stdout}")
            return None
    else:
        logger.error(f"ffprobe failed for {video_path}. Stderr: {stderr}")
        return None

def _has_audio_stream(video_path: str) -> bool:
    """
    Checks if a video file has an audio stream using ffprobe.
    """
    if not os.path.exists(video_path):
        logger.warning(f"Video file not found for audio stream check: {video_path}")
        return False
    
    command = [
        "ffprobe",
        "-v", "error",
        "-select_streams", "a:0", # Select the first audio stream
        "-show_entries", "stream=codec_name",
        "-of", "default=noprint_wrappers=1:nokey=1",
        shlex.quote(video_path)
    ]
    # Corrected variable names here: stdout, stderr
    stdout, stderr, returncode = run_shell_command(command, check_error=False)
    
    if returncode == 0 and stdout.strip(): # Used stdout here
        # Check if stdout contains a valid audio codec name. ffprobe outputs codec_name directly.
        if stdout.strip().lower() in ['aac', 'mp3', 'ac3', 'pcm_s16le', 'flac', 'opus', 'vorbis']:
             return True
        else:
             logger.warning(f"ffprobe found stream but no recognized audio codec: '{stdout.strip()}' for {video_path}")
             return False # Treat as no audio if codec not recognized
    else:
        logger.debug(f"Video {video_path} has no audio stream or ffprobe failed: {stderr}")
        return False


def download_multiple_videos(search_query: str, video_source_type: str, num_videos: int, max_clip_duration: int, aspect_ratio: VideoAspect) -> List[str]:
    """
    Searches for and downloads multiple videos from Pexels or Pixabay.
    """
    downloaded_video_paths: List[str] = []
    headers = {"Authorization": GLOBAL_CONFIG['api_keys']['pexels_api_key']}
    pexels_url = "https://api.pexels.com/videos/search"
    pixabay_api_key = GLOBAL_CONFIG['api_keys']['pixabay_api_key']
    pixabay_url = "https://pixabay.com/api/videos/"

    # Determine orientation for API calls
    orientation = "portrait"
    if aspect_ratio == VideoAspect.LANDSCAPE_16_9:
        orientation = "landscape"
    elif aspect_ratio == VideoAspect.SQUARE_1_1:
        orientation = "square" # Pixabay supports "all", Pexels supports "landscape", "portrait", "square"

    if video_source_type == "Stock Footage (Pexels/Pixabay)":
        logger.info(f"Searching Pexels for '{search_query}' (orientation: {orientation})...")
        params = {
            "query": search_query,
            "orientation": orientation,
            "per_page": num_videos * 3, # Request more to filter by duration later
        }
        try:
            response = requests.get(pexels_url, headers=headers, params=params, timeout=10)
            response.raise_for_status() # Raise HTTPError for bad responses (4xx or 5xx)
            data = response.json()
            
            suitable_videos = []
            if data and 'videos' in data:
                for video in data['videos']:
                    # Filter by duration and check for suitable resolution
                    if video['duration'] <= max_clip_duration:
                        # Find a suitable resolution (e.g., hd, sd, or a specific resolution matching aspect ratio)
                        best_file = None
                        target_width = 1080
                        target_height = 1920
                        if aspect_ratio == VideoAspect.LANDSCAPE_16_9:
                            target_width = 1920
                            target_height = 1080
                        elif aspect_ratio == VideoAspect.SQUARE_1_1:
                            target_width = 1080
                            target_height = 1080

                        for file in video['video_files']:
                            if file['quality'] in ['hd', 'sd'] or (file['width'] == target_width and file['height'] == target_height):
                                best_file = file
                                break
                        
                        if best_file:
                            suitable_videos.append(best_file['link']) # Add the direct download link
            
            # Fallback to Pixabay if Pexels doesn't yield enough
            if not suitable_videos or len(suitable_videos) < num_videos:
                logger.info(f"Pexels did not yield enough videos ({len(suitable_videos)}). Searching Pixabay...")
                pixabay_params = {
                    "key": pixabay_api_key,
                    "q": search_query,
                    "video_type": "all", # Pixabay's video type (all, animation, film)
                    "per_page": num_videos * 3,
                    "min_duration": 1,
                    "max_duration": max_clip_duration
                }
                # Pixabay's 'orientation' parameter is not standard for videos, usually handled by width/height filters if available.
                # For now, let's omit orientation from Pixabay or assume 'all' which is default for videos.

                pixabay_response = requests.get(pixabay_url, params=pixabay_params, timeout=10)
                pixabay_response.raise_for_status()
                pixabay_data = pixabay_response.json()

                if pixabay_data and 'hits' in pixabay_data:
                    for hit in pixabay_data['hits']:
                        # Pixabay video URLs are nested under 'videos' object, then by quality (large, medium, small, tiny)
                        # Let's try to get the 'large' or 'medium' quality URL
                        if 'videos' in hit:
                            if 'large' in hit['videos'] and hit['videos']['large']['url']:
                                suitable_videos.append(hit['videos']['large']['url'])
                            elif 'medium' in hit['videos'] and hit['videos']['medium']['url']:
                                suitable_videos.append(hit['videos']['medium']['url'])

            if not suitable_videos:
                logger.warning(f"No suitable videos found for '{search_query}' from Pexels or Pixabay.")
                return []

            # Shuffle and take the desired number of videos
            random.shuffle(suitable_videos)
            final_video_urls = suitable_videos[:num_videos]
            logger.info(f"Successfully found {len(final_video_urls)} suitable videos from Pexels/Pixabay.")

            logger.info(f"Attempting to download {len(final_video_urls)} videos...")
            for i, video_url in enumerate(final_video_urls):
                try:
                    local_filename = os.path.join(BASE_DIR, VIDEO_DOWNLOADS_DIR, f"downloaded_clip_{uuid.uuid4().hex}.mp4")
                    with requests.get(video_url, stream=True, timeout=30) as r:
                        r.raise_for_status()
                        with open(local_filename, 'wb') as f:
                            for chunk in r.iter_content(chunk_size=8192):
                                f.write(chunk)
                    downloaded_video_paths.append(local_filename)
                    logger.info(f"Successfully downloaded: {local_filename}")
                except requests.exceptions.RequestException as e:
                    logger.error(f"Error downloading video from {video_url}: {e}")
                except Exception as e:
                    logger.error(f"An unexpected error occurred during download of {video_url}: {e}")

        except requests.exceptions.RequestException as e:
            logger.error(f"API request failed for Pexels or Pixabay: {e}")
            return []
        except Exception as e:
            logger.error(f"An unexpected error occurred during video sourcing: {e}")
            return []
    
    return downloaded_video_paths


def concatenate_videos_with_transitions_ffmpeg(
    video_paths: List[str],
    output_path: str,
    target_duration: float,
    aspect_ratio: VideoAspect,
    transition_mode: VideoTransitionMode = VideoTransitionMode.FADE
) -> Optional[str]:
    """
    Concatenates multiple video clips with optional transitions using FFmpeg,
    ensuring consistent resolution and aspect ratio, and trimming to target duration.
    """
    if not video_paths:
        logger.error("No video paths provided for concatenation.")
        return None

    temp_files_path = os.path.join(BASE_DIR, TEMP_FILES_DIR)
    os.makedirs(temp_files_path, exist_ok=True)

    # 1. Probe all video durations and filter valid clips
    valid_clips_with_audio_info = [] # Store original clips with their audio stream status
    total_raw_duration = 0.0
    for i, path in enumerate(video_paths):
        duration = get_video_duration(path)
        if duration is not None and duration > 0.1: # Minimum duration
            has_audio = _has_audio_stream(path) # Determine if clip has audio
            valid_clips_with_audio_info.append({"path": path, "duration": duration, "has_audio": has_audio})
            total_raw_duration += duration
        else:
            logger.warning(f"Skipping problematic clip: {path} (duration: {duration})")

    if not valid_clips_with_audio_info:
        logger.error("No valid video clips found after probing durations.")
        return None
    
    # Calculate effective clip durations considering transitions
    transition_duration = 0.5 # seconds
    if transition_mode == VideoTransitionMode.NONE:
        transition_duration = 0.0
    
    effective_durations = []
    for i, clip in enumerate(valid_clips_with_audio_info):
        if i < len(valid_clips_with_audio_info) - 1 and transition_mode != VideoTransitionMode.NONE:
            effective_durations.append(clip['duration'] - transition_duration)
        else:
            effective_durations.append(clip['duration'])
    
    # If total duration (after transitions) is less than target, re-adjust clip durations
    current_total_effective_duration = sum(effective_durations)
    if current_total_effective_duration < target_duration:
        remaining_duration = target_duration - current_total_effective_duration
        if len(effective_durations) > 0:
            duration_per_clip_add = remaining_duration / len(effective_durations)
            effective_durations = [d + duration_per_clip_add for d in effective_durations]
            logger.info(f"Adjusted clip durations to meet target duration {target_duration:.2f}s.")
        else:
            logger.warning("Cannot adjust clip durations: no effective durations calculated.")

    # Build FFmpeg complex filtergraph
    filter_complex_parts = []
    ffmpeg_inputs = [] # This will store the -i and path for FFmpeg directly
    video_stream_labels = [] # Stores internal labels like [v0], [v1]
    audio_stream_labels = [] # Stores internal labels like [a0], [a0_silent] etc. and maps to current clip 'i'

    # Determine target resolution for scaling based on aspect ratio
    target_res_str = ""
    if aspect_ratio == VideoAspect.PORTRAIT_9_16:
        target_res_str = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
    elif aspect_ratio == VideoAspect.LANDSCAPE_16_9:
        target_res_str = "scale=1920:1080:force_original_aspect_ratio=increase,crop=1920:1080"
    elif aspect_ratio == VideoAspect.SQUARE_1_1:
        target_res_str = "scale=1080:1080:force_original_aspect_ratio=increase,crop=1080:1080"

    # Process each video clip to prepare FFmpeg inputs and stream labels
    current_ffmpeg_input_idx = 0 # This index increments for every -i input file (video or silent audio)
    for i, clip_info in enumerate(valid_clips_with_audio_info): # 'i' is the logical clip index (0 to N-1)
        # Add the original video clip as an FFmpeg input
        ffmpeg_inputs.extend(["-i", shlex.quote(clip_info['path'])])
        
        # Define the video stream label using its current FFmpeg input index
        filter_complex_parts.append(
            f"[{current_ffmpeg_input_idx}:v]{target_res_str},setsar=1,fps=25[v{i}]"
        )
        video_stream_labels.append(f"[v{i}]") # Use internal label for subsequent filters
        
        # Increment FFmpeg input index for the next item (could be audio or next video)
        current_ffmpeg_input_idx += 1

        # Handle audio: if clip has no audio, generate silent audio and add it as a separate input
        if clip_info['has_audio']:
            # If audio exists in the original clip, its stream is from the same input index
            filter_complex_parts.append(f"[{current_ffmpeg_input_idx-1}:a]aresample=async=1[a{i}]") # -1 because we just incremented
            audio_stream_labels.append(f"[a{i}]") # Use internal label for subsequent filters
        else:
            # Generate silent audio for the duration of the clip
            silent_audio_path = os.path.join(temp_files_path, f"silent_audio_{uuid.uuid4().hex}.mp3")
            gen_silent_cmd = [
                "ffmpeg", "-y", "-f", "lavfi", "-i", f"anullsrc=r=48000:cl=stereo,aresample=48000",
                "-t", str(clip_info['duration']), # Use clip_info['duration']
                "-acodec", "libmp3lame", # Ensure MP3 format
                silent_audio_path
            ]
            gen_silent_stdout, gen_silent_stderr, gen_silent_returncode = run_shell_command(gen_silent_cmd)
            if gen_silent_returncode != 0:
                logger.error(f"Failed to generate silent audio for {clip_info['path']}. Stderr: {gen_silent_stderr}")
                return None # Fatal error if silent audio cannot be generated

            # Add the silent audio file as a new FFmpeg input
            ffmpeg_inputs.extend(["-i", shlex.quote(silent_audio_path)])
            
            # Map the silent audio from its new input index (current_ffmpeg_input_idx) to the current clip's internal audio label
            filter_complex_parts.append(f"[{current_ffmpeg_input_idx}:a]aresample=async=1[a{i}]") 
            audio_stream_labels.append(f"[a{i}]")
            logger.info(f"Injected silent audio for clip {clip_info['path']} at FFmpeg input index {current_ffmpeg_input_idx}.")
            
            current_ffmpeg_input_idx += 1 # Increment FFmpeg input index for the silent audio file itself


    # Build xfade and acrossfade filters using the generated internal labels ([v0], [a0] etc.)
    filter_chain_elements = []
    
    current_video_stream = video_stream_labels[0] # First video stream is v0
    current_audio_stream = audio_stream_labels[0] # First audio stream is a0
    
    # Loop for transitions starting from the second clip
    for i in range(len(valid_clips_with_audio_info) - 1): 
        offset = sum(effective_durations[:i+1]) # Cumulative duration up to current clip (i)
        
        # Get the next video and audio streams for the transition
        next_video_stream = video_stream_labels[i+1]
        next_audio_stream = audio_stream_labels[i+1]

        output_v_stream_name = f"v_out{i}"
        output_a_stream_name = f"a_out{i}"

        # Video transition (xfade)
        if transition_mode != VideoTransitionMode.NONE:
            # Use internal stream labels directly without adding extra brackets
            filter_chain_elements.append(
                f"{current_video_stream}{next_video_stream}" # Inputs are current output and next raw stream
                f"xfade=transition={transition_mode.value.lower()}:duration={transition_duration}:offset={offset}"
                f"[{output_v_stream_name}]"
            )
            current_video_stream = f"[{output_v_stream_name}]" # Output of this xfade is input to next
        else:
            # If no transition, just assume simple concat/chaining without xfade filter needed
            # The ffmpeg concat demuxer handles this. For filter_complex, we effectively just pass through.
            pass # current_video_stream remains unchanged if no xfade filter is added

        # Audio transition (acrossfade)
        filter_chain_elements.append(
            f"{current_audio_stream}{next_audio_stream}"
            f"acrossfade=d={transition_duration}"
            f"[{output_a_stream_name}]"
        )
        current_audio_stream = f"[{output_a_stream_name}]" # Output of this acrossfade is input to next
            
    filter_complex_parts.extend(filter_chain_elements)

    # Construct the final FFmpeg command
    ffmpeg_command = [
        "ffmpeg", "-y", # Overwrite output file if it exists
    ]
    ffmpeg_command.extend(ffmpeg_inputs) # Add all input files (original videos + silent audios)

    # Add the filter complex
    ffmpeg_command.extend([
        "-filter_complex",
        ";".join(filter_complex_parts)
    ])

    # Map the output streams
    final_video_output_stream = current_video_stream
    final_audio_output_stream = current_audio_stream

    ffmpeg_command.extend([
        "-c:v", "libx264",         # Video codec
        "-preset", "fast",         # Encoding preset (e.g., ultrafast, superfast, fast, medium)
        "-crf", "23",              # Constant Rate Factor (quality: 0=lossless, 51=worst)
        "-pix_fmt", "yuv420p",     # Pixel format for broader compatibility
        "-c:a", "aac",             # Audio codec
        "-b:a", "192k",            # Audio bitrate
        "-map", final_video_output_stream,
        "-map", final_audio_output_stream,
        output_path
    ])
    
    ffmpeg_command_str = shlex.join(ffmpeg_command) # Join for logging

    logger.info(f"Running FFmpeg concat command:\n{ffmpeg_command_str}")
    stdout, stderr, returncode = run_shell_command(ffmpeg_command, timeout=300) # Added timeout

    if returncode == 0:
        logger.info(f"Successfully concatenated videos to: {output_path}. Final duration: {get_video_duration(output_path):.3f}s")
        return output_path
    else:
        logger.error(f"FFmpeg concatenation failed. Stderr: {stderr}")
        return None


def create_video_from_images_with_ken_burns(
    image_paths: List[str],
    output_path: str,
    target_duration: float,
    aspect_ratio: VideoAspect
) -> Optional[str]:
    """
    Creates a video from a list of images with a Ken Burns effect.
    The video will be generated to match the target duration.
    """
    if not image_paths:
        logger.error("No image paths provided for video creation.")
        return None

    # Calculate duration per image
    duration_per_image = target_duration / len(image_paths) if len(image_paths) > 0 else 0
    if duration_per_image == 0:
        logger.error("Cannot create video from images: no images or zero target duration.")
        return None

    filter_complex = []
    inputs = []
    
    # Determine target resolution for scaling
    target_width, target_height = 1080, 1920
    if aspect_ratio == VideoAspect.LANDSCAPE_16_9:
        target_width, target_height = 1920, 1080
    elif aspect_ratio == VideoAspect.SQUARE_1_1:
        target_width, target_height = 1080, 1080

    # Build filter for each image with zoompan (Ken Burns)
    for i, img_path in enumerate(image_paths):
        inputs.extend(["-loop", "1", "-i", shlex.quote(img_path)])
        
        # Ken Burns effect: pan and zoom
        # Example: zoom in from 1x to 1.2x over the duration, panning from top-left to bottom-right
        zoom_start = 1.0
        zoom_end = 1.2
        pan_start_x = 0
        pan_start_y = 0
        pan_end_x = f'iw*(1-{zoom_end})/2' # center
        pan_end_y = f'ih*(1-{zoom_end})/2' # center

        # Randomize zoom/pan direction for variety
        if random.random() > 0.5: # Randomly invert zoom direction
            zoom_start, zoom_end = zoom_end, zoom_start
        
        # Randomize pan direction (e.g., top-left to bottom-right or vice-versa)
        if random.random() > 0.5:
            pan_end_x = f'iw*(1-{zoom_end})' if pan_end_x == f'iw*(1-{zoom_end})/2' else f'iw*(1-{zoom_end})/2'
            pan_end_y = f'ih*(1-{zoom_end})' if pan_end_y == f'ih*(1-{zoom_end})/2' else f'ih*(1-{zoom_end})/2'

        # Zoompan filter details
        # s= target resolution, d=duration_per_image*fps, z=zoom, x=pan_x, y=pan_y
        # fps=25 ensures consistent frame rate
        filter_complex.append(
            f"[{i}:v]zoompan=z='min(zoom+{zoom_end-zoom_start}/{duration_per_image*25}*on, {zoom_end})':" # Animate zoom over time
            f"x='{pan_start_x}+({pan_end_x}-{pan_start_x})/{duration_per_image*25}*on':" # Animate pan X
            f"y='{pan_start_y}+({pan_end_y}-{pan_start_y})/{duration_per_image*25}*on':" # Animate pan Y
            f"d={int(duration_per_image * 25)}:s={target_width}x{target_height}:fps=25[v{i}]"
        )
    
    # Concatenate all zoomed/panned image streams
    filter_complex.append(
        f"{''.join([f'[v{j}]' for j in range(len(image_paths))])}concat=n={len(image_paths)}:v=1:a=0[v_out]"
    )

    # Build FFmpeg command
    ffmpeg_command = [
        "ffmpeg", "-y", # Overwrite output file if it exists
    ]
    ffmpeg_command.extend(inputs) # Add all image inputs

    ffmpeg_command.extend([
        "-filter_complex",
        ";".join(filter_complex),
        "-map", "[v_out]",
        "-t", str(target_duration), # Trim video to exact target duration
        "-c:v", "libx264",
        "-preset", "medium",
        "-crf", "23",
        "-pix_fmt", "yuv420p",
        output_path
    ])

    ffmpeg_command_str = shlex.join(ffmpeg_command) # Join for logging

    logger.info(f"Running FFmpeg image-to-video command:\n{ffmpeg_command_str}")
    stdout, stderr, returncode = run_shell_command(ffmpeg_command, timeout=300) # Added timeout

    if returncode == 0:
        logger.info(f"Successfully created video from images: {output_path}")
        return output_path
    else:
        logger.error(f"FFmpeg image-to-video conversion failed. Stderr: {stderr}")
        return None


def re_encode_video_for_gemini(input_path: str, output_path: str, max_size_mb: int) -> Optional[str]:
    """
    Re-encodes a video to ensure compatibility with Gemini's upload limits and formats.
    Attempts to reduce size by adjusting bitrate if necessary.
    """
    logger.info(f"Re-encoding video for Gemini: {input_path}")
    
    # Get current video size
    current_size_bytes = os.path.getsize(input_path)
    current_size_mb = current_size_bytes / (1024 * 1024)

    # If already within limits, just return the original path
    if current_size_mb <= max_size_mb:
        logger.info(f"Video {input_path} is already within Gemini's max size ({current_size_mb:.2f}MB / {max_size_mb}MB). No re-encoding needed.")
        return input_path

    logger.info(f"Video size {current_size_mb:.2f}MB exceeds {max_size_mb}MB. Attempting re-encode to reduce size.")

    # Calculate target bitrate to meet max_size_mb
    duration = get_video_duration(input_path)
    if not duration or duration == 0:
        logger.error(f"Could not get duration for video {input_path}, cannot re-encode for size.")
        return None

    # Target bitrate in bits per second (bps)
    # Target size in bits = max_size_mb * 1024 * 1024 * 8
    # Target bitrate = Target size / duration
    target_bitrate_bps = (max_size_mb * 1024 * 1024 * 8) / duration
    target_bitrate_kbps = target_bitrate_bps / 1000

    logger.info(f"Target bitrate for re-encode: {target_bitrate_kbps:.2f} kbps.")

    command = [
        "ffmpeg", "-y",
        "-i", shlex.quote(input_path),
        "-c:v", "libx264",
        "-preset", "fast", # Fast preset for quicker re-encoding
        "-b:v", f"{int(target_bitrate_kbps)}k", # Set video bitrate
        "-c:a", "aac",
        "-b:a", "128k", # Keep audio bitrate reasonable
        "-pix_fmt", "yuv420p", # Ensure compatible pixel format
        output_path
    ]

    stdout, stderr, returncode = run_shell_command(command, timeout=600) # Longer timeout for re-encoding

    if returncode == 0:
        new_size_mb = os.path.getsize(output_path) / (1024 * 1024)
        logger.info(f"Successfully re-encoded video to {output_path}. New size: {new_size_mb:.2f}MB.")
        if new_size_mb > max_size_mb * 1.05: # Allow a small tolerance
            logger.warning(f"Re-encoded video still slightly larger than target ({new_size_mb:.2f}MB vs {max_size_mb}MB). May still fail upload.")
        return output_path
    else:
        logger.error(f"Failed to re-encode video {input_path}. Stderr: {stderr}")
        return None
