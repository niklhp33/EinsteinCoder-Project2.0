# __init__.py for media_processing package
# This file makes media_processing a Python package
# It can also be used to import common functions or define package-level settings

from .video_ops import (
    get_video_duration,
    download_multiple_videos,
    concatenate_videos_with_transitions_ffmpeg,
    create_video_from_images_with_ken_burns,
    re_encode_video_for_gemini
)
from .audio_ops import (
    search_and_download_background_music,
    generate_narration_audio,
    get_tts_client,
    mix_audio_with_ffmpeg
)
from .overlay_ops import add_overlays_and_combine

__all__ = [
    "get_video_duration",
    "download_multiple_videos",
    "concatenate_videos_with_transitions_ffmpeg",
    "create_video_from_images_with_ken_burns",
    "re_encode_video_for_gemini",
    "search_and_download_background_music",
    "generate_narration_audio",
    "get_tts_client",
    "mix_audio_with_ffmpeg",
    "add_overlays_and_combine"
]
