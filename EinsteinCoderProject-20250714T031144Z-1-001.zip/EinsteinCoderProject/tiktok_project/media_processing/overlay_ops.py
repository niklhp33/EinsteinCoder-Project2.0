import os
import subprocess
import logging
import shlex
from typing import List, Dict, Any, Optional

from config import GLOBAL_CONFIG
from utils.shell_utils import run_shell_command
from utils.cleanup import TEMP_FILES_DIR # Import directories defined in cleanup
from models import SubtitleFont, SubtitlePosition, VideoAspect

# Initialize logging
logger = logging.getLogger(__name__)

# Base directory for runtime files (e.g., temp files)
BASE_DIR = GLOBAL_CONFIG['paths']['base_dir']

def add_overlays_and_combine(
    video_path: str,
    audio_path: str,
    output_path: str,
    subtitles_data: Optional[List[Dict[str, Any]]] = None,
    subtitle_font: SubtitleFont = SubtitleFont.ROBOTO,
    subtitle_position: SubtitlePosition = SubtitlePosition.BOTTOM_CENTER,
    subtitle_font_size: int = 50,
    subtitle_color: str = "white",
    subtitle_outline_color: str = "black",
    subtitle_outline_width: int = 2,
    aspect_ratio: VideoAspect = VideoAspect.PORTRAIT_9_16
) -> Optional[str]:
    """
    Adds narration audio and optional subtitles as text overlays to the video,
    and combines them into a final output file using FFmpeg.
    """
    logger.info(f"Adding audio and overlays to video: {video_path}")

    if not os.path.exists(video_path):
        logger.error(f"Video file not found for overlay: {video_path}")
        return None
    if not os.path.exists(audio_path):
        logger.error(f"Audio file not found for overlay: {audio_path}")
        return None

    # Determine resolution based on aspect ratio for subtitle positioning
    target_width, target_height = 1080, 1920 # Default to Portrait
    if aspect_ratio == VideoAspect.LANDSCAPE_16_9:
        target_width, target_height = 1920, 1080
    elif aspect_ratio == VideoAspect.SQUARE_1_1:
        target_width, target_height = 1080, 1080

    filters = []
    
    # Text overlay (subtitles)
    if subtitles_data:
        logger.info("Adding subtitles to video.")
        font_name = subtitle_font.value # e.g., "Roboto"

        # Calculate position based on aspect ratio
        y_pos = ""
        if subtitle_position == SubtitlePosition.TOP_CENTER:
            y_pos = f"y='h*{0.1}'"
        elif subtitle_position == SubtitlePosition.MIDDLE_CENTER:
            y_pos = f"y='h*(1-text_h)/2'"
        elif subtitle_position == SubtitlePosition.BOTTOM_CENTER:
            y_pos = f"y='h*{0.85}'" # 85% down from top
        elif subtitle_position == SubtitlePosition.BOTTOM_LEFT:
            y_pos = f"y='h*{0.85}':x='w*{0.05}'" # 85% down, 5% from left
        elif subtitle_position == SubtitlePosition.BOTTOM_RIGHT:
            y_pos = f"y='h*{0.85}':x='w*{0.95}-tw'" # 85% down, 5% from right (adjusted for text width)

        # Drawtext filter parameters
        # Corrected: Removed trailing colon after .ttf, ensured proper colon separation between params
        # Using a fallback font path that should exist in Colab
        font_path = "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"
        if not os.path.exists(font_path):
            logger.warning(f"Font file not found at {font_path}. Using generic sans-serif. Subtitles might not render as expected.")
            font_path = "sans-serif" # Fallback to a generic font name FFmpeg might find

        current_video_stream = "0:v" # Start with the input video stream

        for i, entry in enumerate(subtitles_data):
            start_time = entry['start'] / 1000.0 # Convert ms to seconds
            end_time = entry['end'] / 1000.0     # Convert ms to seconds
            text = entry['text'].replace("'", "\\'").replace('"', '\\"') # Escape quotes for FFmpeg
            
            # Combine common params, add text and enable dynamically
            drawtext_params = (
                f"fontfile={shlex.quote(font_path)}:fontcolor={subtitle_color}:"
                f"fontsize={subtitle_font_size}:x=(w-text_w)/2:{y_pos}:"
                f"borderw={subtitle_outline_width}:bordercolor={subtitle_outline_color}:"
                f"text='{text}':enable='between(t,{start_time},{end_time})'"
            )
            
            # Apply filter to current stream, output to a new stream
            filters.append(f"[{current_video_stream}]drawtext={drawtext_params}[v{i+1}]")
            current_video_stream = f"v{i+1}" # Next filter will use this as input
        
        # After all subtitles, the final video stream is current_video_stream
        final_video_stream_map = current_video_stream
    else:
        logger.info("No subtitles to add.")
        final_video_stream_map = "0:v" # If no subtitles, just use input video stream


    # FFmpeg command to combine video and audio, and apply filters
    ffmpeg_command = [
        "ffmpeg", "-y",
        "-i", shlex.quote(video_path),  # Input video (base_video.mp4)
        "-i", shlex.quote(audio_path),  # Input audio (mixed_audio.mp3)
        "-map", f"[{final_video_stream_map}]", # Map the final video stream (with subtitles if applied)
        "-map", "1:a",                  # Map the input audio stream (from audio_path, which is input #1)
        "-c:v", "libx264",              # Video codec
        "-preset", "medium",            # Encoding preset
        "-crf", "23",                   # Constant Rate Factor (quality)
        "-pix_fmt", "yuv420p",          # Pixel format for broad compatibility
        "-c:a", "aac",                  # Audio codec
        "-b:a", "192k",                 # Audio bitrate
        "-shortest",                    # End video when shortest input stream ends (audio or video)
    ]

    if filters:
        ffmpeg_command.extend(["-filter_complex", ";".join(filters)])
    
    ffmpeg_command.append(shlex.quote(output_path)) # Output file

    logger.info(f"Running FFmpeg combine command:\n{' '.join(ffmpeg_command)}")
    stdout, stderr, returncode = run_shell_command(ffmpeg_command)

    if returncode == 0:
        logger.info(f"Successfully combined video, audio, and overlays to: {output_path}")
        return output_path
    else:
        logger.error(f"Failed to combine video, audio, and overlays. Stderr: {stderr}")
        return None
