import os
import requests
import logging
import uuid
from typing import Optional, Tuple
from google.cloud import texttospeech
import google.auth.credentials
import azure.cognitiveservices.speech as speechsdk
import random # Ensure random is imported for search_and_download_background_music

from config import GLOBAL_CONFIG
from utils.shell_utils import run_shell_command # Import run_shell_command

logger = logging.getLogger(__name__)

# Base directory for runtime files
BASE_DIR = GLOBAL_CONFIG['paths']['base_dir']
AUDIO_DIR = GLOBAL_CONFIG['paths']['audio_dir'] # Get from config/cleanup


# Initialize Google Text-to-Speech client globally
# This assumes GOOGLE_APPLICATION_CREDENTIALS env var or default auth is set up
# The client should be initialized once.
_google_tts_client = None
def _get_google_tts_client():
    global _google_tts_client
    if _google_tts_client is None:
        sa_key_path = GLOBAL_CONFIG['gcp']['service_account_key_path']
        if os.path.exists(sa_key_path):
            try:
                # Explicitly load credentials from the service account key file
                credentials, project = google.auth.load_credentials_from_file(sa_key_path)
                _google_tts_client = texttospeech.TextToSpeechClient(credentials=credentials)
                logger.info("Google Text-to-Speech client initialized using service account key.")
            except Exception as e:
                logger.error(f"FATAL: Failed to initialize Google TTS client with service account key {sa_key_path}: {e}")
                _google_tts_client = None # Ensure it's None if init fails
        else:
            logger.error(f"FATAL: Google TTS: Service account key not found at {sa_key_path}. Cannot authenticate.")
            _google_tts_client = None
    return _google_tts_client

def get_tts_client(tts_voice: str):
    """
    Returns the appropriate TTS client (Google or Azure) based on the voice selected.
    """
    if "Azure" in tts_voice:
        azure_key = GLOBAL_CONFIG['api_keys'].get('azure_speech_key')
        azure_region = GLOBAL_CONFIG['api_keys'].get('azure_speech_region')
        if not azure_key or not azure_region:
            logger.error("Azure Speech API key or region not configured in config.py or Colab secrets.")
            return None
        
        try:
            speech_config = speechsdk.SpeechConfig(subscription=azure_key, region=azure_region)
            # Example: speech_config.speech_synthesis_voice_name='en-US-SaraNeural'
            return speech_config
        except Exception as e:
            logger.error(f"Error initializing Azure Speech client: {e}")
            return None
    else:
        return _get_google_tts_client()


def generate_narration_audio(text: str, output_filepath: str, tts_voice: str) -> Optional[str]:
    """
    Generates speech audio from text using Google Text-to-Speech or Azure TTS.
    """
    logger.info(f"Generating narration audio with voice '{tts_voice}' for text: '{text[:50]}...'")
    audio_output_dir = os.path.join(BASE_DIR, AUDIO_DIR)
    os.makedirs(audio_output_dir, exist_ok=True)
    
    if "Azure" in tts_voice:
        speech_config = get_tts_client(tts_voice)
        if not speech_config:
            return None
        
        # Remove "(Azure)" from voice name for actual API call
        azure_voice_name = tts_voice.replace(" (Azure)", "")
        speech_config.speech_synthesis_voice_name = azure_voice_name
        
        audio_config = speechsdk.AudioConfig(filename=output_filepath)
        speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
        
        try:
            result = speech_synthesizer.speak_text_async(text).get()
            if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                logger.info(f"Azure TTS: Speech synthesis completed successfully for {output_filepath}")
                return output_filepath
            else:
                logger.error(f"Azure TTS: Speech synthesis failed. Result: {result.reason}")
                if result.cancellation_details:
                    logger.error(f"Azure TTS Cancellation details: Reason={result.cancellation_details.reason} ErrorDetails={result.cancellation_details.error_details}")
                return None
        except Exception as e:
            logger.error(f"Azure TTS: An error occurred during speech synthesis: {e}")
            return None

    else: # Google Cloud TTS
        client = get_tts_client(tts_voice)
        if not client:
            return None

        synthesis_input = texttospeech.SynthesisInput(text=text)
        voice_selection_params = texttospeech.VoiceSelectionParams(
            language_code="en-US", # Assuming English for now, can be dynamic
            name=tts_voice
        )
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3
        )

        try:
            response = client.synthesize_speech(
                input=synthesis_input, voice=voice_selection_params, audio_config=audio_config
            )

            with open(output_filepath, "wb") as out:
                out.write(response.audio_content)
            logger.info(f"Google TTS: Audio content written to file: {output_filepath}")
            return output_filepath
        except Exception as e:
            logger.error(f"Google TTS: Error synthesizing speech: {e}")
            return None


def search_and_download_background_music(query: str, target_duration_s: float, output_filepath: str) -> Optional[str]:
    """
    Searches for and downloads a royalty-free background music track from Pixabay.
    Attempts to find music near the target duration.
    """
    logger.info(f"Searching for background music: '{query}' for {target_duration_s}s...")
    pixabay_api_key = GLOBAL_CONFIG['api_keys'].get('pixabay_api_key')
    if not pixabay_api_key:
        logger.warning("Pixabay API key not found in config. Cannot download background music.")
        return None

    audio_output_dir = os.path.join(BASE_DIR, AUDIO_DIR)
    os.makedirs(audio_output_dir, exist_ok=True)

    search_url = "https://pixabay.com/api/videos/" # Pixabay lumps music under videos API
    params = {
        "key": pixabay_api_key,
        "q": query,
        "video_type": "animation", # Often yields suitable music too
        "min_duration": int(target_duration_s * 0.8), # Look for music around target duration
        "max_duration": int(target_duration_s * 1.5),
        "per_page": 20 # Get a few options
    }

    try:
        response = requests.get(search_url, params=params)
        response.raise_for_status()
        data = response.json()

        hits = data.get("hits", [])
        if not hits:
            logger.warning(f"No music found on Pixabay for query '{query}'.")
            return None

        # Pixabay videos API sometimes has a 'videos' -> 'tiny/small/medium/large' -> 'url' structure for audio
        # We need to explicitly check for 'audios' or a suitable audio stream in 'videos'
        # Pixabay's main API for music is different: https://pixabay.com/api/audios/
        # Let's switch to the dedicated audio API for better results.

        audio_search_url = "https://pixabay.com/api/audios/"
        audio_params = {
            "key": pixabay_api_key,
            "q": query,
            "min_duration": int(target_duration_s * 0.8),
            "max_duration": int(target_duration_s * 1.5),
            "per_page": 20,
            "category": "cinematic" # Or other suitable categories
        }
        
        audio_response = requests.get(audio_search_url, params=audio_params)
        audio_response.raise_for_status()
        audio_data = audio_response.json()
        audio_hits = audio_data.get("hits", [])

        if not audio_hits:
            logger.warning(f"No audio tracks found on Pixabay for query '{query}'.")
            return None

        # Sort by proximity to target duration, or just pick a random one
        # For simplicity, pick a random track that fits criteria
        suitable_tracks = [
            track for track in audio_hits
            if target_duration_s * 0.5 <= track.get('duration', 0) <= target_duration_s * 2.0
            and track.get('preview_url') # Ensure it has a downloadable URL
        ]
        
        if not suitable_tracks:
            logger.warning(f"No suitable music tracks found within duration range for query '{query}'.")
            return None

        selected_track = random.choice(suitable_tracks)
        music_url = selected_track.get('preview_url') # Use preview_url as it's often direct mp3
        
        if not music_url:
            logger.error(f"Selected music track has no preview_url: {selected_track}")
            return None

        logger.info(f"Downloading background music from {music_url} (duration: {selected_track.get('duration')}s)...")
        response = requests.get(music_url, stream=True)
        response.raise_for_status()

        with open(output_filepath, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        logger.info(f"Successfully downloaded background music to: {output_filepath}")
        return output_filepath

    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching background music from Pixabay: {e}")
        return None
    except Exception as e:
        logger.error(f"An unexpected error occurred during music download: {e}")
        return None


def mix_audio_with_ffmpeg(narration_path: str, music_path: str, output_path: str, music_volume_db: float = -15.0) -> Optional[str]:
    """
    Mixes narration audio with background music using FFmpeg.
    Adjusts music volume relative to narration.
    """
    logger.info(f"Mixing narration '{narration_path}' with music '{music_path}' (music volume: {music_volume_db}dB).")

    if not os.path.exists(narration_path):
        logger.error(f"Narration audio file not found: {narration_path}")
        return None
    if not os.path.exists(music_path):
        logger.error(f"Music audio file not found: {music_path}")
        return None

    # Get duration of narration to loop/trim music
    narration_duration = None
    try:
        # Use ffprobe to get duration, as moviepy can be problematic in Colab
        narration_duration_cmd = [
            "ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", narration_path
        ]
        stdout, stderr, returncode = run_shell_command(narration_duration_cmd, check_error=False)
        if returncode == 0 and stdout:
            narration_duration = float(stdout.strip())
        else:
            logger.warning(f"Could not get narration duration via ffprobe: {stderr}. Proceeding without duration check.")
    except Exception as e:
        logger.warning(f"Error probing narration duration: {e}")

    # Audio filter to adjust music volume and mix
    # [0:a] is narration, [1:a] is music
    # To loop music: -stream_loop -1 (on input)
    # To trim music to narration length: -t <duration_of_narration>
    
    # We want to loop the music (input 1) for the duration of the narration (input 0),
    # then adjust music volume, and finally mix them.
    
    # If narration_duration is known, we can trim/loop music
    music_input_args = [
        "-i", shlex.quote(music_path)
    ]
    if narration_duration is not None:
        # Loop music for 100 times, then trim to narration duration
        # This prevents music from cutting off too early if narration is long
        music_input_args = [
            "-stream_loop", "9999", # Loop practically indefinitely
            "-i", shlex.quote(music_path),
            "-t", str(narration_duration) # Trim the looped music to narration duration
        ]
        logger.info(f"Music will be looped and trimmed to {narration_duration:.2f}s.")
    else:
        logger.warning("Narration duration unknown, music will not be trimmed/looped to match.")

    command = [
        "ffmpeg", "-y",
        "-i", shlex.quote(narration_path), # Input 0: Narration
        *music_input_args,                   # Input 1: Music (potentially looped/trimmed)
        "-filter_complex",
        f"[1:a]volume={music_volume_db}dB[music_vol];" # Adjust music volume
        f"[0:a][music_vol]amix=inputs=2:duration=first:dropout_transition=2[aout]" # Mix both, duration=first (narration)
        # Using amix, duration=first will cut the output when the first input (narration) ends.
        # dropout_transition=2 means 2-second transition if one input ends
    ]
    
    command.extend([
        "-map", "0:v?", # Include video stream from narration input if present (optional)
        "-map", "[aout]", # Map the mixed audio stream
        "-c:a", "aac",
        "-b:a", "192k",
        shlex.quote(output_path)
    ])

    command_str = " ".join(command)
    logger.info(f"Running FFmpeg audio mix command:\n{command_str}")
    stdout, stderr, returncode = run_shell_command(command)

    if returncode == 0:
        logger.info(f"Successfully mixed audio to: {output_path}")
        return output_path
    else:
        logger.error(f"Failed to mix audio files. Stderr: {stderr}")
        return None
