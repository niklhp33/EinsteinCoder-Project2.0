import os
import logging
import datetime
import shutil # Import shutil for copying files
from typing import Optional, List

# Import google.colab.files for auto-download
try:
    from google.colab import files as colab_files
except ImportError:
    colab_files = None # Handle case where not in Colab environment

# Set up logging at the very beginning
LOG_FILE_PATH = None # Path to the temporary log file

def setup_logging(base_dir: str):
    """Sets up logging to console and a file within the specified base directory."""
    global LOG_FILE_PATH
    log_dir_temp = os.path.join(base_dir, GLOBAL_CONFIG['paths']['logs_dir']) # Temporary log directory
    os.makedirs(log_dir_temp, exist_ok=True)
    
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    LOG_FILE_PATH = os.path.join(log_dir_temp, f"pipeline_log_FULL_{timestamp}.txt")

    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
        
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(LOG_FILE_PATH),
            logging.StreamHandler()
        ]
    )
    logging.getLogger('google.api_core').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('moviepy').setLevel(logging.INFO)
    logging.getLogger('PIL').setLevel(logging.WARNING)

    logger = logging.getLogger(__name__)
    logger.info(f"Logging configured to console AND temporary file: {LOG_FILE_PATH}")
    return logger

# --- ABSOLUTE IMPORTS ---
# All imports now assume PROJECT_ROOT_DIR is on sys.path
from config import GLOBAL_CONFIG # Changed from .config
from models import VideoParams, VideoSourceType, SpeechSynthesisVoice, SubtitleEntry # Changed from .models
# Import FINAL_OUTPUT_SUBDIR_NAME from cleanup, as it defines the name of the final output subfolder on Drive
from utils.cleanup import clean_up_temp_files, setup_directories as setup_runtime_dirs_config, OUTPUT_DIR as FINAL_OUTPUT_SUBDIR_NAME # Changed from .utils.cleanup
from utils.gcs_utils import upload_to_gcs, check_gcs_access # Changed from .utils.gcs_utils
from media_processing.video_editor import VideoEditor, generate_unique_filename # Changed from .media_processing.video_editor
from ai_integration.gemini_integration import generate_video_script, analyze_video_content, generate_text_content # Changed from .ai_integration.gemini_integration
from ai_integration.speech_synthesis import synthesize_speech_google, synthesize_speech_azure, get_audio_duration_ffprobe # Changed from .ai_integration.speech_synthesis


logger = logging.getLogger(__name__)


class VideoGenerationPipeline:
    def __init__(self, params: VideoParams, project_root_drive_dir: str):
        self.params = params
        self.project_root_drive_dir = project_root_drive_dir # The root of your project on Google Drive
        self.runtime_base_dir = GLOBAL_CONFIG['paths']['base_dir'] # Local /tmp runtime base
        
        # Define the absolute path to the final output directory on Google Drive
        self.final_output_drive_dir = os.path.join(self.project_root_drive_dir, FINAL_OUTPUT_SUBDIR_NAME)
        # Define the absolute path to the logs directory on Google Drive
        self.final_logs_drive_dir = os.path.join(self.project_root_drive_dir, GLOBAL_CONFIG['paths']['logs_dir'])

        global logger
        logger = setup_logging(self.runtime_base_dir) # Initialize logger with the local runtime base directory

        logger.info(f"--- Starting Video Generation Pipeline for subject: '{self.params.video_subject}' ---")
        logger.info(f"Pipeline Parameters: {self.params.model_dump_json(indent=2)}")

        # VideoEditor now only needs to know its local runtime paths.
        # The finalization path will be passed to its method.
        self.video_editor = VideoEditor() 

    def run(self) -> Optional[str]:
        """
        Executes the full video generation pipeline.
        Returns:
            Path to the final generated video on Google Drive on success, None otherwise.
        """
        final_output_video_path_on_drive = None # Initialize to None

        try:
            # Ensure the local runtime directories are set up
            logger.info(f"Setting up local runtime directories under base: {self.runtime_base_dir}")
            self.video_editor.setup_local_runtime_directories() # Call the setup method on VideoEditor
            # Also ensure the Google Drive output and logs directories exist
            os.makedirs(self.final_output_drive_dir, exist_ok=True)
            os.makedirs(self.final_logs_drive_dir, exist_ok=True)

            logger.info("Step 1/9: Runtime directories set up (local /tmp and Google Drive).")

            # Step 2: Generate video script
            logger.info(f"Step 2/9: Generating video script from Gemini for subject '{self.params.video_subject}'...")
            script_segments = generate_video_script(
                subject=self.params.video_subject,
                language=self.params.video_language.value,
                duration_s=self.params.final_video_duration_s
            )
            if not script_segments:
                logger.error("Failed to generate video script. Aborting.")
                return None
            logger.info(f"Script generated with {len(script_segments)} segments.")
            full_script_text = " ".join(script_segments)

            # Step 3: Generate narration audio
            logger.info(f"Step 3/9: Generating narration audio using {self.params.speech_synthesis_voice.value} voice...")
            narration_output_path = generate_unique_filename("narration", "mp3", self.video_editor.audio_dir)
            
            narration_audio_path: Optional[str] = None
            subtitle_entries: List[SubtitleEntry] = []

            if "Azure" in self.params.speech_synthesis_voice.value:
                narration_audio_path = synthesize_speech_azure(full_script_text, self.params.speech_synthesis_voice.value, narration_output_path)
                logger.warning("Azure TTS does not provide word-level timestamps directly. Subtitles will be generated based on sentence timing approximations if enabled.")
            else: # Assume Google TTS
                narration_result = synthesize_speech_google(
                    full_script_text,
                    self.params.speech_synthesis_voice.value,
                    narration_output_path,
                    return_timestamps=self.params.enable_subtitles
                )
                if narration_result:
                    narration_audio_path, subtitle_entries = narration_result
                
            if not narration_audio_path:
                logger.error("Failed to generate narration audio. Aborting.")
                return None
            
            narration_duration = get_audio_duration_ffprobe(narration_audio_path)
            if narration_duration is None:
                logger.error("Could not determine narration audio duration. Aborting.")
                return None
            logger.info(f"Narration audio generated with duration: {narration_duration:.2f}s")
            
            if self.params.enable_subtitles and not subtitle_entries:
                logger.warning("No precise word-level timestamps obtained. Approximating subtitle timings for each script segment.")
                subtitle_entries = self._approximate_subtitle_timings(script_segments, narration_duration)


            # Step 4: Sourcing visual assets
            logger.info(f"Step 4/9: Sourcing {self.params.num_videos_to_source_or_generate} visual assets for '{self.params.video_subject}'...")
            sourced_visual_assets = self.video_editor.source_visual_assets(
                query=self.params.video_subject,
                video_source_type=self.params.video_source_type,
                num_assets=self.params.num_videos_to_source_or_generate,
                max_clip_duration_s=self.params.max_clip_duration_s,
                target_aspect_ratio=self.params.video_aspect_ratio,
                image_prompt_suffix=self.params.image_prompt_suffix
            )
            if not sourced_visual_assets:
                logger.error("Failed to source any visual assets. Aborting.")
                return None
            logger.info(f"Successfully sourced/generated {len(sourced_visual_assets)} visual assets.")

            # Step 5: Assemble base video
            logger.info("Step 5/9: Concatenating video clips with transitions...")
            base_video_path = self.video_editor.assemble_base_video(
                video_clip_paths=sourced_visual_assets,
                final_video_duration_s=self.params.final_video_duration_s,
                target_aspect_ratio=self.params.video_aspect_ratio,
                concat_mode=self.params.video_concat_mode,
                transition_mode=self.params.video_transition_mode
            )
            if not base_video_path:
                logger.error("Failed to assemble base video. Aborting.")
                return None
            logger.info(f"Base video assembled at: {base_video_path}")
            
            # Step 6: Add narration and background music
            logger.info("Step 6/9: Adding narration and background music...")
            video_with_audio_path = self.video_editor.add_narration_and_music(
                base_video_path=base_video_path,
                narration_audio_path=narration_audio_path,
                background_music_query=GLOBAL_CONFIG['audio_settings']['default_background_music_query'],
                background_music_volume_db=GLOBAL_CONFIG['audio_settings']['default_background_music_volume']
            )
            if not video_with_audio_path:
                logger.error("Failed to add narration and music to video. Aborting.")
                return None
            logger.info(f"Narration and music added. Video with audio at: {video_with_audio_path}")

            # Step 7: Add subtitles (if enabled)
            final_video_path_intermediate = video_with_audio_path
            if self.params.enable_subtitles and subtitle_entries:
                logger.info("Step 7/9: Adding subtitles to video...")
                
                font_path_to_use = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
                if self.params.subtitle_font == "Roboto":
                    if os.path.exists('/usr/share/fonts/truetype/roboto/Roboto-Regular.ttf'):
                        font_path_to_use = '/usr/share/fonts/truetype/roboto/Roboto-Regular.ttf'
                    elif os.path.exists('/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'):
                        font_path_to_use = '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
                    else:
                        logger.warning(f"Requested font '{self.params.subtitle_font.value}' not found at common paths. Using default: {font_path_to_use}")

                elif self.params.subtitle_font == "Arial":
                    if os.path.exists('/usr/share/fonts/truetype/msttcorefonts/Arial.ttf'):
                        font_path_to_use = '/usr/share/fonts/truetype/msttcorefonts/Arial.ttf'
                    else:
                         logger.warning(f"Requested font '{self.params.subtitle_font.value}' not found at common paths. Using default: {font_path_to_use}")
                
                final_video_path_intermediate = self.video_editor.add_subtitles(
                    video_path=video_with_audio_path,
                    subtitle_entries=subtitle_entries,
                    font_path=font_path_to_use,
                    font_size=self.params.subtitle_font_size,
                    font_color=self.params.subtitle_color,
                    outline_color=self.params.subtitle_outline_color,
                    outline_width=self.params.subtitle_outline_width,
                    position=self.params.subtitle_position
                )
                if not final_video_path_intermediate:
                    logger.error("Failed to add subtitles. Proceeding without them.")
                    final_video_path_intermediate = video_with_audio_path
            else:
                logger.info("Step 7/9: Subtitles disabled or no entries. Skipping subtitle addition.")

            # Step 8: Finalize video (copy to Google Drive output directory)
            logger.info("Step 8/9: Finalizing video...")
            output_filename_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            final_output_video_name = f"einstein_coder_tiktok_video_{output_filename_timestamp}.mp4"
            
            final_output_video_path_on_drive = self.video_editor.finalize_video(
                input_video_path=final_video_path_intermediate,
                output_filename=final_output_video_name,
                google_drive_output_dir=self.final_output_drive_dir # Pass the Drive path here
            )
            if not final_output_video_path_on_drive:
                logger.error("Failed to finalize video to Google Drive. Aborting.")
                return None
            logger.info(f"Final video saved to Google Drive at: {final_output_video_path_on_drive}")
            
            # --- AUTO-DOWNLOAD FEATURE ---
            if colab_files and final_output_video_path_on_drive and os.path.exists(final_output_video_path_on_drive):
                logger.info(f"Attempting to auto-download final video: {final_output_video_path_on_drive}")
                try:
                    colab_files.download(final_output_video_path_on_drive)
                    logger.info("Final video auto-download initiated.")
                except Exception as e:
                    logger.warning(f"Failed to auto-download video: {e}")
            else:
                logger.info("Skipping auto-download (not in Colab, or video not found).")
            # --- END AUTO-DOWNLOAD FEATURE ---

            # List contents of the final output directory on Google Drive for verification
            logger.info(f"Contents of final output directory on Google Drive ({self.final_output_drive_dir}):")
            if os.path.exists(self.final_output_drive_dir):
                for item in os.listdir(self.final_output_drive_dir):
                    logger.info(f"  - {item}")
            else:
                logger.warning(f"Final output directory on Google Drive {self.final_output_drive_dir} does not exist after run.")


            # Step 9: Upload to GCS (optional)
            logger.info("Step 9/9: Attempting to upload final video to GCS...")
            gcs_bucket_name = GLOBAL_CONFIG['gcp']['gcs_bucket_name']
            service_account_path = GLOBAL_CONFIG['gcp']['service_account_key_path']

            if check_gcs_access(gcs_bucket_name, service_account_path):
                destination_blob_name = f"video_production/{os.path.basename(final_output_video_path_on_drive)}"
                if upload_to_gcs(gcs_bucket_name, final_output_video_path_on_drive, destination_blob_name, service_account_path):
                    logger.info(f"Final video uploaded to GCS: gs://{gcs_bucket_name}/{destination_blob_name}")
                else:
                    logger.warning("Failed to upload video to GCS.")
            else:
                logger.warning("GCS access check failed. Skipping video upload to GCS.")
            
            logger.info("--- Video Generation Pipeline Completed ---")
            return final_output_video_path_on_drive # Return the path on Google Drive

        except Exception as e:
            logger.critical(f"An unhandled error occurred during the pipeline execution: {e}", exc_info=True)
            return None
        finally:
            logger.info("Cleaning up temporary runtime files...")
            # --- Copy log file to Google Drive for persistence ---
            if LOG_FILE_PATH and os.path.exists(LOG_FILE_PATH):
                final_log_path_gd = os.path.join(self.final_logs_drive_dir, os.path.basename(LOG_FILE_PATH))
                try:
                    shutil.copyfile(LOG_FILE_PATH, final_log_path_gd)
                    logger.info(f"Pipeline log copied to Google Drive: {final_log_path_gd}")
                except Exception as e:
                    logger.error(f"Failed to copy log {LOG_FILE_PATH} to Google Drive {final_log_path_gd}: {e}")
            else:
                logger.warning("Temporary pipeline log file not found for copying to Google Drive.")
            # --- End log file copy ---

            clean_up_temp_files() # Cleans up /tmp runtime directories
            logger.info("Temporary files cleaned.")

    def _approximate_subtitle_timings(self, script_segments: List[str], total_duration: float) -> List[SubtitleEntry]:
        """
        Approximates start/end times for subtitles if precise word-level timestamps
        are not available (e.g., for Azure TTS).
        Divides the total duration proportionally by segment length.
        """
        if not script_segments:
            return []

        total_chars = sum(len(s) for s in script_segments)
        if total_chars == 0:
            return []

        approx_entries: List[SubtitleEntry] = []
        current_time = 0.0
        for segment in script_segments:
            segment_duration = (len(segment) / total_chars) * total_duration
            end_time = current_time + segment_duration
            approx_entries.append(SubtitleEntry(text=segment, start_time=current_time, end_time=end_time))
            current_time = end_time
        
        if approx_entries:
            approx_entries[-1].end_time = total_duration

        logger.info(f"Approximated {len(approx_entries)} subtitle timings based on script segments.")
        return approx_entries
