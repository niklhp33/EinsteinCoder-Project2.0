import os

# --- GLOBAL CONFIGURATION DICTIONARY ---
# This dictionary holds all configurable parameters for the pipeline.
# It's accessed throughout different modules.

GLOBAL_CONFIG = {
    # Base directory for temporary runtime files within the Colab environment.
    # This should typically point to a location within /tmp or /content, NOT Google Drive.
    # Files in this directory will be cleared after each run or runtime restart.
    'paths': {
        'base_dir': '/tmp/tiktok_project_runtime',
        'video_downloads_dir': 'video_downloads',
        'audio_dir': 'audio',
        'images_dir': 'images',
        'output_dir': 'output',
        'temp_files_dir': 'temp_files',
        'logs_dir': 'logs' # Directory for runtime logs
    },

    # API Keys - IMPORTANT: Store these securely (e.g., Colab Secrets)
    # TEMPORARY: For debugging, we are directly putting the key here.
    # NORMALLY, THIS SHOULD BE: os.environ.get('GOOGLE_API_KEY', 'YOUR_GOOGLE_API_KEY')
    'api_keys': {
        'google_api_key': 'AIzaSyAHvm5piK9ehz4f15TiHBTr7NHeTi-_BpA', # <--- ENSURE YOUR REAL KEY IS HERE!
        'pexels_api_key': os.environ.get('PEXELS_API_KEY', 'oxc0uJQQhTGe3PscUEN5lUDFeSPlC8aWlQ5vUANPQGIdwBidQXxkvzrl'), # For stock videos/images
        'pixabay_api_key': os.environ.get('PIXABAY_API_KEY', '51095600-2f628ce3bfc8cb4bee3b93d93'), # For stock videos/images
        'azure_speech_key': os.environ.get('AZURE_SPEECH_KEY', 'DDvzcYarUFHcDhwfk5IIrFerzOlRzf8ymBgqMsdikbKiOzdQvKf0JQQJ99BFACYeBjFXJ3w3AAAYACOGBUBH'), # Optional: For Azure TTS
        'azure_speech_region': os.environ.get('AZURE_SPEECH_REGION', 'eastus'), # Optional: For Azure TTS
    },

    # Google Cloud Platform (GCP) Settings
    'gcp': {
        # Path to your GCP service account key JSON file.
        # This file should be securely stored (e.g., in your Google Drive, but not publicly shared)
        # and its path provided here. Example: '/content/drive/MyDrive/service_account.json'
        'service_account_key_path': os.environ.get('GOOGLE_APPLICATION_CREDENTIALS', '/content/drive/MyDrive/EinsteinCoderProject/service_account.json'),
        'gcs_bucket_name': 'video_downloads', # Your Google Cloud Storage bucket name
    },

    # Video Generation Specific Settings (can be overridden by UI)
    'video_settings': {
        'default_aspect_ratio': '9:16', # e.g., '9:16' for portrait, '16:9' for landscape
        'default_max_clip_duration_s': 10, # Max duration for individual source clips
        'default_num_videos_to_source': 5, # Number of videos to look for/generate
        'default_final_video_duration_s': 60, # Target length of the final video
        'default_video_source_type': 'Stock Footage (Pexels/Pixabay)', # This setting determines the default in the UI
        'default_concat_mode': 'Random Concatenation (Recommended)',
        'default_transition_mode': 'Fade'
    },

    # Audio Settings
    'audio_settings': {
        'default_narration_voice': 'en-US-Wavenet-C', # Default Google TTS voice
        'default_background_music_query': 'upbeat cinematic', # Search query for background music
        'default_background_music_volume': -15 # Volume in dB relative to narration (e.g., -10 means 10dB quieter)
    },

    # Subtitle Settings
    'subtitle_settings': {
        'default_enable_subtitles': True,
        'default_font': 'Roboto',
        'default_position': 'Bottom Center',
        'default_font_size': 50,
        'default_color': 'white',
        'default_outline_color': 'black',
        'default_outline_width': 2
    },

    # Gemini API specific settings
    'gemini_settings': {
        'video_analysis_model': 'gemini-1.5-pro-latest',
        'text_generation_model': 'gemini-1.5-pro-latest',
        'video_analysis_max_file_size_mb': 200 # Max file size for video uploads to Gemini
    }
}

# --- Runtime Directory Setup ---
# This part ensures that the base directory and its subdirectories exist
# It's typically called once at the start of the main pipeline execution.
def setup_runtime_directories():
    """Ensures all necessary runtime directories are created."""
    for key, path in GLOBAL_CONFIG['paths'].items():
        if key != 'base_dir': # Base dir is handled separately
            full_path = os.path.join(GLOBAL_CONFIG['paths']['base_dir'], path)
            os.makedirs(full_path, exist_ok=True)
