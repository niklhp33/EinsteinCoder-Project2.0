import os
import requests
import logging
import random
import shlex
from typing import Optional, Tuple, List, Any
import subprocess

from moviepy.editor import AudioFileClip # Used for getting audio duration (though ffprobe is preferred)
from google.cloud import texttospeech
import azure.cognitiveservices.speech as speechsdk
from gtts import gTTS

from config import GLOBAL_CONFIG
from utils.shell_utils import run_shell_command

logger = logging.getLogger(__name__)

# --- Google Text-to-Speech Setup ---
def get_google_tts_client():
    google_api_key = GLOBAL_CONFIG['api_keys']['google_api_key']
    if not google_api_key or google_api_key == 'YOUR_GOOGLE_API_KEY_PLACEHOLDER':
        logging.getLogger(__name__).error("Google API key (GOOGLE_API_KEY) is not configured in Colab Secrets. Google TTS calls will fail.")
        return None
    
    service_account_path = GLOBAL_CONFIG['gcp']['service_account_key_path']
    if os.path.exists(service_account_path) and os.path.isfile(service_account_path):
        os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = service_account_path
        logging.getLogger(__name__).info(f"Google Text-to-Speech client initialized using service account key: {service_account_path}.")
        return texttospeech.TextToSpeechClient()
    else:
        logging.getLogger(__name__).warning(f"Service account key not found at {service_account_path}. Google Text-to-Speech client may default to environment variable API key.")
        return texttospeech.TextToSpeechClient()


# --- Azure Text-to-Speech Setup ---
def get_azure_tts_client_config():
    speech_key = GLOBAL_CONFIG['api_keys']['azure_speech_key']
    service_region = GLOBAL_CONFIG['api_keys']['azure_speech_region']
    
    if not speech_key or speech_key == 'YOUR_AZURE_SPEECH_KEY_PLACEHOLDER':
        logging.getLogger(__name__).error("Azure Speech Key is not configured. Azure TTS calls will fail.")
        return None
    if not service_region or service_region == 'YOUR_AZURE_SPEECH_REGION_PLACEHOLDER':
        logging.getLogger(__name__).error("Azure Speech Region is not configured. Azure TTS calls will fail.")
        return None
        
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Riff16Khz16BitMonoMp3)
    logging.getLogger(__name__).info(f"Azure Speech client configured for region: {service_region}.")
    return speech_config


def get_audio_duration_ffprobe(audio_path: str) -> Optional[float]:
    """
    Gets the duration of an audio file using ffprobe.
    """
    if not os.path.exists(audio_path):
        logging.getLogger(__name__).warning(f"Audio file not found for duration check: {audio_path}")
        return None
    
    cmd = ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', shlex.quote(audio_path)]
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False)
    
    if returncode != 0:
        logging.getLogger(__name__).warning(f"ffprobe failed to get audio duration for {audio_path}: {stderr}")
        return None
    
    try:
        duration = float(stdout.strip())
        return duration
    except ValueError:
        logging.getLogger(__name__).warning(f"Could not parse duration from ffprobe output for {audio_path}: {stdout}")
        return None

def synthesize_speech_google(text: str, voice_name: str, output_filepath: str) -> Optional[str]:
    """
    Synthesizes speech from text using Google Text-to-Speech.
    """
    client = get_google_tts_client()
    if not client:
        return None

    try:
        synthesis_input = texttospeech.SynthesisInput(text=text)
        
        if '-' in voice_name:
            lang_code = "-".join(voice_name.split('-')[:2])
        else:
            lang_code = "en-US"

        voice_selection = texttospeech.VoiceSelectionParams(
            language_code=lang_code,
            name=voice_name
        )
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3
        )

        logging.getLogger(__name__).info(f"Google TTS: Synthesizing speech with voice '{voice_name}'...")
        response = client.synthesize_speech(
            input=synthesis_input,
            voice=voice_selection,
            audio_config=audio_config,
        )

        with open(output_filepath, "wb") as out:
            out.write(response.audio_content)
        logging.getLogger(__name__).info(f"Google TTS: Audio content written to file: {output_filepath}")
        return output_filepath
    except Exception as e:
        logging.getLogger(__name__).error(f"Google Text-to-Speech synthesis failed: {e}", exc_info=True)
        return None


def synthesize_speech_azure(text: str, voice_name: str, output_filepath: str) -> Optional[str]:
    """
    Synthesizes speech from text using Azure Text-to-Speech.
    """
    speech_config = get_azure_tts_client_config()
    if not speech_config:
        return None

    try:
        actual_voice = voice_name.split('(')[0].strip()
        speech_config.speech_synthesis_voice_name = actual_voice

        audio_config = speechsdk.audio.AudioOutputConfig(filename=output_filepath)
        speech_synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)

        logging.getLogger(__name__).info(f"Azure TTS: Synthesizing speech with voice '{actual_voice}'...")
        result = speech_synthesizer.speak_text_async(text).get()

        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            logging.getLogger(__name__).info(f"Azure TTS: Speech synthesized for text and saved to {output_filepath}")
            return output_filepath
        elif result.reason == speechsdk.ResultReason.Canceled:
            cancellation_details = result.cancellation_details
            logging.getLogger(__name__).error(f"Azure TTS: Speech synthesis canceled: {cancellation_details.reason}")
            if cancellation_details.reason == speechsdk.CancellationReason.Error:
                logging.getLogger(__name__).error(f"Azure TTS: Cancellation error details: {cancellation_details.error_details}")
                logging.getLogger(__name__).error("Azure TTS: Did you set the speech resource key and region?")
            return None
    except Exception as e:
        logging.getLogger(__name__).error(f"Azure Text-to-Speech synthesis failed: {e}", exc_info=True)
        return None

def synthesize_speech_gtts(text: str, lang: str, output_filepath: str) -> Optional[str]:
    """
    Synthesizes speech from text using gTTS (Google Text-to-Speech free API).
    Less natural voices but good for quick tests.
    """
    try:
        tts = gTTS(text=text, lang=lang, slow=False)
        tts.save(output_filepath)
        logging.getLogger(__name__).info(f"gTTS: Audio content written to file: {output_filepath}")
        return output_filepath
    except Exception as e:
        logging.getLogger(__name__).error(f"gTTS synthesis failed: {e}", exc_info=True)
        return None


def download_background_music(query: str, output_dir: str, duration_s: int) -> Optional[str]:
    """
    Downloads a royalty-free background music track using yt-dlp based on a query.
    Attempts to find music of a suitable duration.
    """
    audio_filename = f"background_music_{random.randint(1000, 9999)}.mp3"
    output_filepath = os.path.join(output_dir, audio_filename)

    search_query = f"royalty free {query} music"
    logging.getLogger(__name__).info(f"Searching and downloading background music for query: '{search_query}'...")

    cmd = [
        "yt-dlp",
        "--extract-audio",
        "--audio-format", "mp3",
        "--default-search", "ytsearch",
        "--match-filter", f"duration <= {duration_s + 120}",
        "--max-downloads", "1",
        "--output", output_filepath,
        "--",
        search_query
    ]

    try:
        stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=300)
        
        if returncode != 0:
            logging.getLogger(__name__).error(f"yt-dlp failed to download background music: {stderr}")
            return None
        
        if not os.path.exists(output_filepath) or os.path.getsize(output_filepath) == 0:
            logging.getLogger(__name__).error(f"yt-dlp reported success but no file or empty file found at: {output_filepath}")
            return None

        downloaded_duration = get_audio_duration_ffprobe(output_filepath)
        if downloaded_duration is None or downloaded_duration < 5:
            logging.getLogger(__name__).warning(f"Downloaded music track is too short or duration could not be determined: {downloaded_duration}s. Attempting another download if available, otherwise returning None.")
            if os.path.exists(output_filepath):
                os.remove(output_filepath)
            return None
            
        logging.getLogger(__name__).info(f"Successfully downloaded background music: {output_filepath} ({downloaded_duration:.2f}s)")
        return output_filepath

    except Exception as e:
        logging.getLogger(__name__).error(f"An unexpected error occurred during background music download: {e}", exc_info=True)
        if os.path.exists(output_filepath):
            os.remove(output_filepath)
        return None

def adjust_audio_volume(input_audio_path: str, output_audio_path: str, volume_db: int) -> bool:
    """
    Adjusts the volume of an audio file using FFmpeg.
    """
    logging.getLogger(__name__).info(f"Adjusting volume of {input_audio_path} to {volume_db}dB.")
    cmd = [
        'ffmpeg', '-y',
        '-i', shlex.quote(input_audio_path),
        '-filter:a', f'volume={volume_db}dB',
        '-c:a', 'libmp3lame',
        shlex.quote(output_audio_path)
    ]
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=60)
    if returncode != 0:
        logging.getLogger(__name__).error(f"Failed to adjust volume for {input_audio_path}: {stderr}")
        return False
    logging.getLogger(__name__).info(f"Volume adjusted for {input_audio_path} to {output_path}.")
    return True

def combine_audio_tracks(
    narration_path: str,
    background_music_path: Optional[str],
    output_path: str,
    background_music_volume_db: int = -15
) -> bool:
    """
    Combines narration audio with optional background music.
    """
    logging.getLogger(__name__).info(f"Combining narration '{narration_path}' with background music '{background_music_path}' to '{output_path}'.")

    if not os.path.exists(narration_path):
        logging.getLogger(__name__).error(f"Narration file not found: {narration_path}")
        return False

    narration_duration = get_audio_duration_ffprobe(narration_path)
    if narration_duration is None:
        logging.getLogger(__name__).error(f"Could not determine duration of narration audio: {narration_path}")
        return False
        
    cmd_args = []
    filter_complex = ""
    map_audio = ""

    if background_music_path and os.path.exists(background_music_path):
        cmd_args.extend(['-i', shlex.quote(narration_path), '-i', shlex.quote(background_music_path)])
        
        filter_complex = (
            f"[1:a]volume={background_music_volume_db}dB,aloop=loop=-1:size=2e9[bg_loop];"
            f"[bg_loop][0:a]amix=inputs=2:duration=first:dropout_transition=2[aout]"
        )
        map_audio = '-map [aout]'
    else:
        logging.getLogger(__name__).info("No valid background music path provided or music file not found. Combining only narration.")
        cmd_args.extend(['-i', shlex.quote(narration_path)])
        filter_complex = "[0:a]anull[aout]"
        map_audio = '-map [aout]'

    cmd = ['ffmpeg', '-y'] + cmd_args + [
        '-filter_complex', filter_complex,
        map_audio,
        '-c:a', 'libmp3lame',
        '-b:a', '192k',
        '-shortest',
        shlex.quote(output_path)
    ]
    
    logging.getLogger(__name__).info(f"FFmpeg Combine Audio Command: {' '.join(shlex.quote(arg) for arg in cmd)}")
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=180)

    if returncode != 0:
        logging.getLogger(__name__).error(f"Failed to combine audio tracks: {stderr}")
        return False
    logging.getLogger(__name__).info(f"Audio tracks combined to {output_path}.")
    return True
