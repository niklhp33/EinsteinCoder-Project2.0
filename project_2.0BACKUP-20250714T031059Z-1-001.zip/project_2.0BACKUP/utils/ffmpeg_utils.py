import logging
import subprocess
import os
import shlex
import math
from typing import List, Tuple, Optional, Any

from utils.shell_utils import run_shell_command # Absolute import
from utils.video_utils import get_video_duration # Absolute import

logger = logging.getLogger(__name__)

def get_video_dimensions(video_path: str) -> Optional[Tuple[int, int]]:
    """
    Gets the width and height of a video file using ffprobe.
    """
    cmd = ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
           '-show_entries', 'stream=width,height', '-of', 'csv=p=0:s=x',
           shlex.quote(video_path)]
    
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False)
    
    if returncode != 0:
        logger.warning(f"ffprobe failed to get dimensions for {video_path}: {stderr}")
        return None
    
    try:
        dimensions_str = stdout.strip()
        width, height = map(int, dimensions_str.split('x'))
        return width, height
    except ValueError:
        logger.warning(f"Could not parse dimensions from ffprobe output for {video_path}: {stdout}")
        return None

def concatenate_videos(
    video_paths: List[str],
    output_path: str,
    target_width: int,
    target_height: int,
    target_duration: float,
    transition: str = 'fade',
    transition_duration: float = 0.5,
    randomize_order: bool = True
) -> bool:
    """
    Concatenates a list of video clips with or without transitions using FFmpeg.
    Each clip is scaled/cropped to fit target_width/height.
    The total duration of the concatenated video is adjusted to be close to target_duration.
    """
    if not video_paths:
        logger.error("No video paths provided for concatenation.")
        return False

    logger.info(f"Concatenating {len(video_paths)} videos with {transition} transitions to {output_path}")

    # Determine target resolution for scaling
    scale_crop_filter = (
        f"scale={target_width}:{target_height}:force_original_aspect_ratio=increase,"
        f"crop={target_width}:{target_height},setsar=1,fps=25" # Standardize FPS here
    )

    # If no transition, use simple concat demuxer or a basic concat filter
    if transition.lower() == 'none' or len(video_paths) == 1:
        logger.info("Performing simple concatenation without transitions.")
        
        list_file_path = os.path.join(os.path.dirname(output_path), f"concat_list_{uuid.uuid4().hex}.txt")
        with open(list_file_path, "w") as f:
            for path in video_paths:
                f.write(f"file '{os.path.abspath(path)}'\n") # Absolute path
        
        cmd = ['ffmpeg', '-y', '-f', 'concat', '-safe', '0', '-i', shlex.quote(list_file_path),
               '-vf', scale_crop_filter, # Apply scaling/cropping during concat
               '-c:v', 'libx264', '-preset', 'medium', '-crf', '23',
               '-pix_fmt', 'yuv420p',
               '-c:a', 'aac', '-b:a', '192k',
               '-t', str(target_duration), # Enforce target duration
               shlex.quote(output_path)]
        
        stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=600)
        os.remove(list_file_path) # Clean up temp list file
        
        if returncode != 0:
            logger.error(f"FFmpeg simple concatenation failed: {stderr}")
            return False
        logger.info(f"Videos concatenated successfully (no transitions) to {output_path}.")
        return True

    # --- Complex filtergraph for transitions (if transition is not 'none' and multiple videos) ---
    filter_complex = []
    input_streams = []
    
    effective_clip_durations = []
    total_raw_duration = 0.0
    for path in video_paths:
        duration = get_video_duration(path)
        if duration is None:
            logger.error(f"Could not get duration for video clip: {path}. Cannot concatenate.")
            return False
        effective_clip_durations.append(duration)
        total_raw_duration += duration

    # Scale and crop each input video to target dimensions and then assign labels
    for i, video_path in enumerate(video_paths):
        filter_complex.append(
            f"[{i}:v]{scale_crop_filter}[v{i}]" # Apply scaling/cropping here
        )
        filter_complex.append(f"[{i}:a]aresample=async=1[a{i}]") # Resample audio
        input_streams.extend(['-i', shlex.quote(video_path)]) # Add video input

    video_concat_filters = []
    audio_concat_filters = []
    current_total_effective_duration = 0.0
    
    # Track the actual combined duration including transitions
    # This loop calculates cumulative offsets for xfade
    for i in range(len(video_paths)):
        if i == 0:
            # First clip, just pass through to initial labeled streams
            current_video_stream = f"[v0]"
            current_audio_stream = f"[a0]"
            current_total_effective_duration += effective_clip_durations[i]
        else:
            xfade_offset = current_total_effective_duration - transition_duration
            
            # CRITICAL FIX: Ensure the transition name is robustly quoted for FFmpeg.
            # Using shlex.quote around the f-string that contains the single-quoted transition name.
            # This handles any internal special characters if the transition name itself contained them.
            # The actual ffmpeg error often comes from an unquoted 'Fade'.
            video_concat_filters.append(
                f"{current_video_stream}[v{i}]xfade=transition={shlex.quote(transition)}:duration={transition_duration}:offset={xfade_offset}[v_out{i}]"
            )
            audio_concat_filters.append(
                f"{current_audio_stream}[a{i}]acrossfade=d={transition_duration}[a_out{i}]"
            )
            current_video_stream = f"[v_out{i}]"
            current_audio_stream = f"[a_out{i}]"
            current_total_effective_duration += effective_clip_durations[i] - transition_duration

    final_video_stream = current_video_stream
    final_audio_stream = current_audio_stream

    # Combine all parts into the filter_complex string
    filter_complex_str = ";".join(filter_complex + video_concat_filters + audio_concat_filters)

    output_options = [
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '23', # Constant Rate Factor, 0-51, lower is better quality/larger file
        '-pix_fmt', 'yuv420p', # For wider compatibility
        '-c:a', 'aac',
        '-b:a', '192k',
        '-map', final_video_stream,
        '-map', final_audio_stream
    ]
    
    # If target_duration is specified and we want to enforce it strictly
    if target_duration > 0:
        # Using -t to specify output duration. This will cut the video short if it's too long.
        output_options.extend(['-t', str(target_duration)])


    cmd = ['ffmpeg', '-y'] + input_streams + [
        '-filter_complex', filter_complex_str
    ] + output_options + [shlex.quote(output_path)]

    logger.info(f"Running FFmpeg concat command: {' '.join(cmd)}")
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=600) # Increased timeout for long videos

    if returncode != 0:
        logger.error(f"FFmpeg video concatenation failed: {stderr}")
        return False
    
    logger.info(f"Videos concatenated successfully to {output_path}.")
    return True

def add_audio_to_video(video_path: str, audio_path: str, output_path: str) -> bool:
    """
    Adds an audio track to a video file. If video has audio, it's replaced.
    """
    logger.info(f"Adding audio {audio_path} to video {video_path}...")
    cmd = [
        'ffmpeg', '-y',
        '-i', shlex.quote(video_path),
        '-i', shlex.quote(audio_path),
        '-c:v', 'copy',
        '-c:a', 'aac',
        '-b:a', '192k',
        '-map', '0:v:0', # Map video stream from first input
        '-map', '1:a:0', # Map audio stream from second input
        '-shortest', # End video when shortest stream ends
        shlex.quote(output_path)
    ]
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=300)
    if returncode != 0:
        logger.error(f"Failed to add audio to {video_path}: {stderr}")
        return False
    logger.info(f"Audio added to video. Output: {output_path}.")
    return True

def add_subtitles_to_video(
    video_path: str,
    subtitle_file_path: str,
    output_path: str,
    font_path: str,
    font_size: int,
    font_color: str,
    outline_color: str,
    outline_width: int,
    position: str # 'Top', 'Bottom', 'Center'
) -> bool:
    """
    Adds burnt-in subtitles to a video using FFmpeg and a .ass subtitle file.
    """
    logger.info(f"Adding subtitles from {subtitle_file_path} to {video_path}...")

    quoted_font_path = shlex.quote(font_path)
    
    cmd = [
        'ffmpeg', '-y',
        '-i', shlex.quote(video_path),
        '-vf', f"subtitles={shlex.quote(subtitle_file_path)}:fontsdir={os.path.dirname(quoted_font_path)}", # Specify fontsdir explicitly
        '-c:a', 'copy', # Copy audio to avoid re-encoding
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '23',
        '-pix_fmt', 'yuv420p',
        shlex.quote(output_path)
    ]
    logger.info(f"Running FFmpeg subtitles command: {' '.join(cmd)}")
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=300)

    if returncode != 0:
        logger.error(f"FFmpeg failed to add subtitles: {stderr}")
        return False
    
    logger.info(f"Subtitles added to video. Output: {output_path}.")
    return True

def escape_ffmpeg_text(text: str) -> str:
    """
    Escapes special characters in text for FFmpeg's drawtext filter.
    """
    text = text.replace("'", "\\'")
    text = text.replace("\\", "\\\\")
    text = text.replace(":", "\\:")
    text = text.replace(",", "\\,")
    text = text.replace(";", "\\;")
    text = text.replace("[", "\\[")
    text = text.replace("]", "\\]")
    return text
