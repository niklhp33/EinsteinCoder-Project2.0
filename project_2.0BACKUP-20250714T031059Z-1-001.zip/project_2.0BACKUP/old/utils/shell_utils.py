import subprocess
import logging
import shlex # For shell-safe quoting

logger = logging.getLogger(__name__)

def run_shell_command(command: list, check_error: bool = True, timeout: int = 120) -> tuple[str, str, int]:
    """
    Executes a shell command and returns its stdout, stderr, and return code.
    Optionally raises an exception if the command fails.

    Args:
        command (list): A list of strings representing the command and its arguments.
                        Example: ['ffmpeg', '-i', 'input.mp4', 'output.mp4']
        check_error (bool): If True, raises a RuntimeError if the command returns a non-zero exit code.
        timeout (int): The maximum time in seconds to wait for the command to complete.

    Returns:
        tuple[str, str, int]: A tuple containing stdout, stderr, and the return code.

    Raises:
        RuntimeError: If check_error is True and the command fails.
        subprocess.TimeoutExpired: If the command exceeds the specified timeout.
    """
    # Use shlex.join to create a string for logging, ensuring proper quoting
    command_str = shlex.join(command)
    logger.info(f"Executing command: {command_str}")
    
    try:
        # Using subprocess.run with shell=False is safer to prevent shell injection.
        # shlex.quote() should be used on individual arguments when building `command` list.
        result = subprocess.run(
            command,
            capture_output=True,
            text=True, # Decode stdout/stderr as text
            check=False, # We'll handle checking the return code manually
            timeout=timeout
        )
        
        stdout = result.stdout.strip()
        stderr = result.stderr.strip()
        returncode = result.returncode

        if returncode != 0:
            logger.error(f"Command failed with exit code {returncode}: {command_str}\nSTDOUT: {stdout}\nSTDERR: {stderr}")
            if check_error:
                raise RuntimeError(f"Command failed with exit code {returncode}: {command_str}\nSTDOUT: {stdout}\nSTDERR: {stderr}")
        else:
            logger.info(f"Command executed successfully (exit code {returncode}): {command_str}")
            if stdout:
                logger.info(f"STDOUT: {stdout}")
            if stderr:
                logger.warning(f"STDERR: {stderr}") # Log stderr as warning for non-critical messages
        
        return stdout, stderr, returncode

    except FileNotFoundError:
        logger.critical(f"Command not found. Make sure the executable is in your PATH: {command[0]}")
        raise RuntimeError(f"Command not found: {command[0]}")
    except subprocess.TimeoutExpired:
        logger.error(f"Command timed out after {timeout} seconds: {command_str}")
        result.kill()
        result.wait()
        raise
    except Exception as e:
        logger.critical(f"An unexpected error occurred while running command {command_str}: {e}", exc_info=True)
        raise
