import logging
import subprocess
import os
import shlex
import math # For ceil
from typing import List, Tuple, Optional, Any

from utils.shell_utils import run_shell_command # Absolute import
from utils.video_utils import get_video_duration # Absolute import

logger = logging.getLogger(__name__)

def get_video_dimensions(video_path: str) -> Optional[Tuple[int, int]]:
    """
    Gets the width and height of a video file using ffprobe.
    Returns (width, height) tuple or None if unsuccessful.
    """
    cmd = ['ffprobe', '-v', 'error', '-select_streams', 'v:0',
           '-show_entries', 'stream=width,height', '-of', 'csv=p=0:s=x',
           shlex.quote(video_path)]
    
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False)
    
    if returncode != 0:
        logger.warning(f"ffprobe failed to get dimensions for {video_path}: {stderr}")
        return None
    
    try:
        dimensions_str = stdout.strip()
        width, height = map(int, dimensions_str.split('x'))
        return width, height
    except ValueError:
        logger.warning(f"Could not parse dimensions from ffprobe output for {video_path}: {stdout}")
        return None

def concatenate_videos(
    video_paths: List[str],
    output_path: str,
    target_width: int,
    target_height: int,
    target_duration: float,
    transition: str = 'fade',
    transition_duration: float = 0.5,
    randomize_order: bool = True
) -> bool:
    """
    Concatenates a list of video clips with transitions using FFmpeg.
    Each clip is scaled/cropped to fit target_width/height.
    The total duration of the concatenated video is adjusted to be close to target_duration.
    """
    if not video_paths:
        logger.error("No video paths provided for concatenation.")
        return False

    logger.info(f"Concatenating {len(video_paths)} videos with {transition} transitions to {output_path}")

    # Calculate effective duration of each clip after considering transitions
    # Sum of (clip_duration - transition_duration) for all but last clip, plus last clip duration
    effective_clip_durations = []
    total_raw_duration = 0.0
    for path in video_paths:
        duration = get_video_duration(path)
        if duration is None:
            logger.error(f"Could not get duration for video clip: {path}. Cannot concatenate.")
            return False
        effective_clip_durations.append(duration)
        total_raw_duration += duration

    # If the total raw duration is less than target duration, we might loop or extend later.
    # For now, let's just make sure we don't exceed target_duration significantly.

    # Build filter complex for scaling/cropping and transitions
    filter_complex = []
    input_streams = []
    
    # Scale and crop each input video to target dimensions
    for i, video_path in enumerate(video_paths):
        # [i:v] for video stream, [i:a] for audio stream
        # scale and crop filter:
        # scale to target_width:-1 if height is smaller, or -1:target_height if width is smaller
        # then crop to exact target_width:target_height from center
        # setsar=1 ensures square pixels
        # fps=25 standardizes frame rate
        video_filter = (
            f"[{i}:v]scale={target_width}:{target_height}:force_original_aspect_ratio=increase,"
            f"crop={target_width}:{target_height},setsar=1,fps=25[v{i}]"
        )
        filter_complex.append(video_filter)
        
        # Audio stream: just aresample to keep consistent, async=1 handles varying sample rates
        audio_filter = f"[{i}:a]aresample=async=1[a{i}]"
        filter_complex.append(audio_filter)

        input_streams.extend(['-i', shlex.quote(video_path)]) # Add video input
        # No need to add separate audio input here, as it's already part of the video file

    # Build transition filters
    video_concat_filters = []
    audio_concat_filters = []
    current_offset = 0.0
    current_total_effective_duration = 0.0
    
    # Track the actual combined duration including transitions
    # This loop calculates cumulative offsets for xfade
    for i in range(len(video_paths)):
        if i == 0:
            # First clip starts at 0, no transition before it.
            current_total_effective_duration += effective_clip_durations[i]
        else:
            xfade_offset = current_total_effective_duration - transition_duration
            
            # CRITICAL FIX: Ensure the transition name is robustly quoted for FFmpeg.
            # Using shlex.quote around the f-string that contains the single-quoted transition name.
            # This handles any internal special characters if the transition name itself contained them.
            # The actual ffmpeg error often comes from an unquoted 'Fade'.
            video_concat_filters.append(
                f"[v_out{i-1}][v{i}]xfade=transition={shlex.quote(transition)}:duration={transition_duration}:offset={xfade_offset}[v_out{i}]"
            )
            audio_concat_filters.append(
                f"[a_out{i-1}][a{i}]acrossfade=d={transition_duration}[a_out{i}]"
            )
            current_total_effective_duration += effective_clip_durations[i] - transition_duration # Subtract overlap

    # Check if target_duration is less than the current combined duration after transitions
    # This handles cases where sourced clips are too long.
    if target_duration > 0 and current_total_effective_duration > target_duration:
        logger.info(f"Combined video duration ({current_total_effective_duration:.2f}s) exceeds target ({target_duration:.2f}s). Trimming.")
        # We will trim the final output video after concatenation.
    elif target_duration > 0 and current_total_effective_duration < target_duration:
        logger.info(f"Combined video duration ({current_total_effective_duration:.2f}s) is less than target ({target_duration:.2f}s). Looping/extending if possible.")
        # This part requires more complex logic for looping/padding.
        # For now, if it's shorter, we'll just let it be shorter.
        # Future enhancement: loop the last clip or pad with black frames/silent audio.
        
    final_video_stream = f"[v_out{len(video_paths)-1}]" if len(video_paths) > 1 else "[v0]"
    final_audio_stream = f"[a_out{len(video_paths)-1}]" if len(video_paths) > 1 else "[a0]"

    # Combine all parts into the filter_complex string
    filter_complex_str = ";".join(filter_complex + video_concat_filters + audio_concat_filters)

    # Output options
    output_options = [
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '23', # Constant Rate Factor, 0-51, lower is better quality/larger file
        '-pix_fmt', 'yuv420p', # For wider compatibility
        '-c:a', 'aac',
        '-b:a', '192k',
        '-map', final_video_stream,
        '-map', final_audio_stream
    ]
    
    # If target_duration is specified and we want to enforce it strictly
    if target_duration > 0:
        # Using -t to specify output duration. This will cut the video short if it's too long.
        output_options.extend(['-t', str(target_duration)])


    cmd = ['ffmpeg', '-y'] + input_streams + [
        '-filter_complex', filter_complex_str
    ] + output_options + [shlex.quote(output_path)]

    logger.info(f"Running FFmpeg concat command: {' '.join(cmd)}")
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=600) # Increased timeout for long videos

    if returncode != 0:
        logger.error(f"FFmpeg video concatenation failed: {stderr}")
        return False
    
    logger.info(f"Videos concatenated successfully to {output_path}.")
    return True

def add_audio_to_video(video_path: str, audio_path: str, output_path: str) -> bool:
    """
    Adds an audio track to a video file. If video has audio, it's replaced.
    """
    logger.info(f"Adding audio {audio_path} to video {video_path}...")
    cmd = [
        'ffmpeg', '-y',
        '-i', shlex.quote(video_path),
        '-i', shlex.quote(audio_path),
        '-c:v', 'copy',
        '-c:a', 'aac',
        '-b:a', '192k',
        '-map', '0:v:0', # Map video stream from first input
        '-map', '1:a:0', # Map audio stream from second input
        '-shortest', # End video when shortest stream ends
        shlex.quote(output_path)
    ]
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=300)
    if returncode != 0:
        logger.error(f"Failed to add audio to {video_path}: {stderr}")
        return False
    logger.info(f"Audio added to video. Output: {output_path}.")
    return True

def add_subtitles_to_video(
    video_path: str,
    subtitle_file_path: str,
    output_path: str,
    font_path: str,
    font_size: int,
    font_color: str,
    outline_color: str,
    outline_width: int,
    position: str # 'Top', 'Bottom', 'Center'
) -> bool:
    """
    Adds burnt-in subtitles to a video using FFmpeg and a .ass subtitle file.
    """
    logger.info(f"Adding subtitles from {subtitle_file_path} to {video_path}...")

    # Position mapping for FFmpeg's subtitles filter
    # These are approximations or specific filter options might be needed for precise control
    # For text-based positioning, using y (vertical position) in ass file is more robust.
    # However, for `subtitles` filter with text styling, you mostly define the font and color.
    # To control position directly in ffmpeg, you might need `drawtext` filter or pre-process ASS.
    # Assuming the ASS file itself or the filter default handles 'Bottom Center' reasonably.
    # For exact positioning, FFmpeg subtitles filter typically uses the position defined in the ASS file.
    # If the ASS doesn't define it, it's usually bottom center by default.
    # For now, we'll ensure font settings are passed.

    # Ensure font path is quoted for shlex
    quoted_font_path = shlex.quote(font_path)

    # Build the style string for ASS (these are standard ASS tags)
    # PrimaryColour is AABBGGRR (Alpha Blue Green Red) in hex for ASS
    # OutlineColour is AABBGGRR
    # EdgeType 1 for outline, EdgeType 0 for none, EdgeType 2 for shadow
    # Fontsize is self-explanatory
    # We will need to convert font_color and outline_color from #RRGGBB to &HBBGGRR for ASS.
    
    # FFmpeg subtitles filter doesn't take font_size, color etc directly as arguments usually.
    # It reads it from the ASS file. So these parameters should ideally influence ASS file creation.
    # For now, if the ASS file is properly generated with these styles, the filter should pick them up.
    # If the user has specific requests for FFmpeg direct styling, we might need a more complex filter.
    
    # Basic subtitles filter usage:
    # -vf "subtitles=subtitle.ass:fontsdir=/path/to/fonts/"
    
    cmd = [
        'ffmpeg', '-y',
        '-i', shlex.quote(video_path),
        '-vf', f"subtitles={shlex.quote(subtitle_file_path)}", # FFmpeg automatically looks for fonts in standard paths or assumes default
        '-c:a', 'copy', # Copy audio to avoid re-encoding
        '-c:v', 'libx264',
        '-preset', 'fast',
        '-crf', '23',
        '-pix_fmt', 'yuv420p',
        shlex.quote(output_path)
    ]
    logger.info(f"Running FFmpeg subtitles command: {' '.join(cmd)}")
    stdout, stderr, returncode = run_shell_command(cmd, check_error=False, timeout=300) # Increased timeout

    if returncode != 0:
        logger.error(f"FFmpeg failed to add subtitles: {stderr}")
        return False
    
    logger.info(f"Subtitles added to video. Output: {output_path}.")
    return True

def escape_ffmpeg_text(text: str) -> str:
    """
    Escapes special characters in text for FFmpeg's drawtext filter.
    """
    # From FFmpeg documentation:
    # ' => \'
    # \ => \\
    # : => \:
    # , => \,
    # ; => \;
    # [ => \[
    # ] => \]
    
    # Replace single quotes first to avoid escaping the new backslash
    text = text.replace("'", "\\'")
    # Then replace backslashes (now including the new ones from single quote escape)
    text = text.replace("\\", "\\\\")
    text = text.replace(":", "\\:")
    text = text.replace(",", "\\,")
    text = text.replace(";", "\\;")
    text = text.replace("[", "\\[")
    text = text.replace("]", "\\]")
    return text
