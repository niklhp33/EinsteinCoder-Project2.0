# This file makes media_processing a Python package.
# No specific imports needed here, unless you want to expose certain modules.
# Avoid importing internal components from other modules directly in __init__.py to prevent circular dependencies.
