from enum import Enum
from dataclasses import dataclass
from typing import Optional, List, Dict, Any # Added Dict, Any for clarity

# Enums for Video Parameters
class VideoLanguage(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    ENGLISH = "English"
    SPANISH = "Spanish"
    FRENCH = "French"
    GERMAN = "German"
    PORTUGUESE = "Portuguese"
    CHINESE = "Chinese"
    JAPANESE = "Japanese"
    KOREAN = "Korean"

class VideoSourceType(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    STOCK_FOOTAGE_PEXELS_PIXABAY = "Stock Footage (Pexels/Pixabay)"
    STOCK_FOOTAGE_PEXELS_ONLY = "Stock Footage (Pexels Only)"
    STOCK_FOOTAGE_PIXABAY_ONLY = "Stock Footage (Pixabay Only)"
    AI_GENERATED_IMAGES = "AI-Generated Images (DALL-E 3, Stable Diffusion)"
    AI_GENERATED_VIDEOS = "AI-Generated Videos (Google Text-to-Video)" # Added AI Generated Videos option

class VideoConcatMode(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    RANDOM_CONCATENATION = "Random Concatenation (Recommended)"
    SEQUENTIAL_CONCATENATION = "Sequential Concatenation"

class VideoTransitionMode(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    FADE = "Fade"
    CROSSFADE = "Crossfade"
    SLIDE = "Slide" # Placeholder, needs FFmpeg filter
    NONE = "None"

class VideoAspect(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    PORTRAIT_9_16 = "Portrait 9:16 (TikTok/Reels)"
    LANDSCAPE_16_9 = "Landscape 16:9 (YouTube)"
    SQUARE_1_1 = "Square 1:1 (Instagram)"

class SpeechSynthesisVoice(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    # Google Wavenet Voices (high quality, but requires Google Cloud TTS API)
    EN_US_WAVENET_A = "en-US-Wavenet-A"
    EN_US_WAVENET_C = "en-US-Wavenet-C"
    EN_US_WAVENET_D = "en-US-WAVENET-D"
    EN_US_WAVENET_E = "en-US-WAVENET-E"
    EN_US_WAVENET_F = "en-US-WAVENET-F"
    EN_US_WAVENET_G = "en-US-WAVENET-G"
    EN_US_WAVENET_H = "en-US-WAVENET-H"
    EN_US_WAVENET_I = "en-US-WAVENET-I"
    EN_US_WAVENET_J = "en-US-WAVENET-J"
    EN_US_WAVENET_K = "en-US-WAVENET-K"
    EN_US_WAVENET_L = "en-US-WAVENET-L"
    EN_US_WAVENET_M = "en-US-WAVENET-M"

    # Google Standard Voices (lower quality, but generally free/lower cost)
    EN_US_STANDARD_A = "en-US-Standard-A"
    EN_US_STANDARD_B = "en-US-Standard-B"

    # Azure Voices (if Azure TTS is integrated) - Example, you'd list actual voice names
    EN_US_AZURE_CHRISTOPHER = "en-US-ChristopherNeural (Azure)"
    EN_US_AZURE_ANA = "en-US-AnaNeural (Azure)"
    
    # gTTS (free, simpler Google TTS API, less natural voices)
    GTTS_EN = "en (gTTS)"
    GTTS_ES = "es (gTTS)"


class SubtitleFont(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    ROBOTO = "Roboto"
    ARIAL = "Arial"
    VERDANA = "Verdana"
    IMPACT = "Impact"

class SubtitlePosition(str, Enum): # Changed to str, Enum for Gradio dropdown compatibility
    TOP_CENTER = "Top Center"
    BOTTOM_CENTER = "Bottom Center"
    CENTER = "Center"
    TOP_LEFT = "Top Left"
    TOP_RIGHT = "Top Right"
    BOTTOM_LEFT = "Bottom Left"
    BOTTOM_RIGHT = "Bottom Right"

    def to_ass_alignment(self) -> int:
        """Converts to ASS alignment codes (1-9 on numpad)."""
        if self == SubtitlePosition.BOTTOM_LEFT: return 1
        if self == SubtitlePosition.BOTTOM_CENTER: return 2
        if self == SubtitlePosition.BOTTOM_RIGHT: return 3
        if self == SubtitlePosition.CENTER: return 5 # Middle center
        if self == SubtitlePosition.TOP_LEFT: return 7
        if self == SubtitlePosition.TOP_CENTER: return 8
        if self == SubtitlePosition.TOP_RIGHT: return 9
        return 2 # Default to bottom center

@dataclass
class VideoParams:
    video_subject: str
    video_language: VideoLanguage = VideoLanguage.ENGLISH
    video_source_type: VideoSourceType = VideoSourceType.STOCK_FOOTAGE_PEXELS_PIXABAY
    image_prompt_suffix: Optional[str] = None # Suffix for AI image generation prompts
    video_concat_mode: VideoConcatMode = VideoConcatMode.RANDOM_CONCATENATION
    video_transition_mode: VideoTransitionMode = VideoTransitionMode.FADE
    video_aspect_ratio: VideoAspect = VideoAspect.PORTRAIT_9_16
    max_clip_duration_s: int = 25 # Max duration for individual sourced/generated clips
    num_videos_to_source_or_generate: int = 5 # Number of video clips or images to get
    final_video_duration_s: int = 60 # Desired final video duration
    
    # Audio/Narration Settings
    speech_synthesis_voice: SpeechSynthesisVoice = SpeechSynthesisVoice.EN_US_WAVENET_C

    # Subtitle Settings
    enable_subtitles: bool = True
    subtitle_font: SubtitleFont = SubtitleFont.ROBOTO
    subtitle_position: SubtitlePosition = SubtitlePosition.BOTTOM_CENTER
    subtitle_font_size: int = 50
    subtitle_color: str = "white" # Hex color code, e.g., "#FFFFFF"
    subtitle_outline_color: str = "black" # Hex color code, e.g., "#000000"
    subtitle_outline_width: int = 2

    def dict(self):
        """Returns a dictionary representation, handling Enum values."""
        return {k: v.value if isinstance(v, Enum) else v for k, v in self.__dict__.items()}


@dataclass
class SubtitleEntry:
    text: str
    start_time: float # in seconds
    end_time: float # in seconds

@dataclass
class ImagePrompt:
    text_prompt: str
    image_path: Optional[str] = None # Path to saved image if generated/downloaded
    model_name: Optional[str] = None # e.g., "dall-e-3", "stable-diffusion"
